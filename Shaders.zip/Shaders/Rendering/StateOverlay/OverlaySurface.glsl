/**
 * @file OverlaySurface.glsl
 * @brief Heat, Lava, WaterFilm, Mud overlay fragment shader들이 공유하는 coverage 기반 조명 경로다.
 */
#ifndef MDSS_OVERLAY_SURFACE
#define MDSS_OVERLAY_SURFACE
#include "Rendering/Surface/MaterialParameters.glsl"
#include "Rendering/Surface/Lighting.glsl"
#include "Rendering/Surface/Effects/Lava.glsl"
#ifdef OVERLAY_COMBINED
#define SURFACE_DEBUG_SET 1
#define RENDER_STATE_TEXTURE_SET 4
#include "Rendering/Surface/RenderStateSampling.glsl"
#endif

layout(location = 0) in vec3 FragNormal;

layout(location = 1) in vec2 FragUV;

layout(location = 2) flat in uint FragSurfaceIndex;

layout(location = 3) in vec3 FragWorldPosition;

layout(location = 4) in float FragCoverage;

layout(location = 0) out vec4 OutColor;

// Diagnostic: expose coverage and depth gaps without material lighting.
const bool DiagnosticUnlitOverlay = true;

float MudNoiseHash(vec3 P)
{
    P = fract(P * 0.1031);
    P += dot(P, P.yzx + 33.33);
    return fract((P.x + P.y) * P.z);
}

float MudValueNoise(vec3 P)
{
    vec3 Cell = floor(P);
    vec3 F = fract(P);
    F = F * F * (3.0 - 2.0 * F);

    float C000 = MudNoiseHash(Cell + vec3(0.0, 0.0, 0.0));
    float C100 = MudNoiseHash(Cell + vec3(1.0, 0.0, 0.0));
    float C010 = MudNoiseHash(Cell + vec3(0.0, 1.0, 0.0));
    float C110 = MudNoiseHash(Cell + vec3(1.0, 1.0, 0.0));
    float C001 = MudNoiseHash(Cell + vec3(0.0, 0.0, 1.0));
    float C101 = MudNoiseHash(Cell + vec3(1.0, 0.0, 1.0));
    float C011 = MudNoiseHash(Cell + vec3(0.0, 1.0, 1.0));
    float C111 = MudNoiseHash(Cell + vec3(1.0, 1.0, 1.0));

    float Z0 = mix(mix(C000, C100, F.x), mix(C010, C110, F.x), F.y);
    float Z1 = mix(mix(C001, C101, F.x), mix(C011, C111, F.x), F.y);
    return mix(Z0, Z1, F.z);
}

vec3 ApplyMudMicroBump(vec3 N, vec3 P, float Amount)
{
    if (Amount <= 0.0)
        return N;

    float Height = MudValueNoise(P * 8.0);
    vec3 dPdx = dFdx(P);
    vec3 dPdy = dFdy(P);
    vec3 R1 = cross(dPdy, N);
    vec3 R2 = cross(N, dPdx);
    float Det = dot(dPdx, R1);
    vec3 Gradient = sign(Det) * (dFdx(Height) * R1 + dFdy(Height) * R2);
    return normalize(abs(Det) * N - (0.025 * Amount) * Gradient);
}

vec4 ShadeWaterFilmLayer(vec3 N, vec3 V, float Coverage)
{
    // 화면의 바탕색은 이미 그려져 있다. 정면에서는 대부분 비치고,
    // 비스듬히 볼수록 물 표면의 반사가 커지도록 source-over 색과 alpha를 만든다.
    float Amount = clamp(Coverage, 0.0, 1.0);
    float NoV = max(dot(N, V), 0.0);
    float Fresnel = 0.02 + 0.98 * pow(1.0 - NoV, 5.0);
    float Absorption = 0.04 + 0.24 * Amount;
    float OpticalAlpha = Fresnel + (1.0 - Fresnel) * Absorption;
    float CoverageFade = smoothstep(0.02, 0.25, Amount);
    float Alpha = clamp(Material.DemoEffectOptions.z * CoverageFade * OpticalAlpha, 0.0, 0.98);

    vec3 L = normalize(vec3(0.35, 0.55, 1.0));
    vec3 Sum = V + L;
    vec3 H = Sum * inversesqrt(max(dot(Sum, Sum), 1e-12));
    float Highlight = EvaluateSpecularLobe(max(NoV, 1e-4), max(dot(N, L), 0.0),
                                           max(dot(N, H), 0.0), max(dot(V, H), 0.0),
                                           Material.DemoEffectOptions.w, 0.02);
    vec3 Reflection = EvaluateWaterFilmEnvironment(reflect(-V, N), Material.DemoEffectOptions.w) +
                      vec3(Highlight);
    vec3 Tint = MapEffectColor(2u, Amount);
    vec3 Color = (Fresnel * Reflection + (1.0 - Fresnel) * Absorption * Tint) /
                 max(OpticalAlpha, 1e-5);
    return vec4(min(Color, vec3(1.0)), Alpha);
}

void main()
{
    // 아주 낮은 coverage는 버리고 재질별 branch에서 색, 조명, 투명도를 정한다.
    const float Cutoff = 0.02;
    if (FragCoverage <= Cutoff) discard;
    if (DiagnosticUnlitOverlay)
    {
        OutColor = vec4(0.1, 0.8, 0.25, 1.0);
        return;
    }
    vec3 N = normalize(FragNormal);
    if (!gl_FrontFacing) N = -N;
    vec3 V = normalize(Material.CameraPosition.xyz - FragWorldPosition);
#ifdef OVERLAY_COMBINED
    uint EnabledEffects = Material.DemoExtraStateChannels.w;
    uint PerformanceFlags = Material.DemoExtraStateChannels.z;
    bool CoverageSmoothing = (PerformanceFlags & 1u) != 0u;
#if defined(MDSS_FRAGMENT_MODE)
    const bool PrecomputedSmoothing = MDSS_FRAGMENT_MODE == 2;
    const bool UseRenderTexture = MDSS_FRAGMENT_MODE != 0;
#else
    bool PrecomputedSmoothing = (PerformanceFlags & 2u) != 0u;
    bool UseRenderTexture = (PerformanceFlags & 4u) != 0u || PrecomputedSmoothing;
#endif
    vec4 States = UseRenderTexture
        ? SampleRenderStates(FragSurfaceIndex, FragUV,
                             uvec4(Material.DemoStateChannels.xyz, Material.DemoExtraStateChannels.x),
                             Material.StateChannelCount)
        : SampleStateSaturations(FragSurfaceIndex, FragUV,
                                 uvec4(Material.DemoStateChannels.xyz, Material.DemoExtraStateChannels.x),
                                 Material.StateChannelCount);
    if (CoverageSmoothing && !PrecomputedSmoothing)
    {
        if ((EnabledEffects & 2u) != 0u)
            States.y = SampleSmoothedStateSaturation(FragSurfaceIndex, FragUV,
                                                     Material.DemoStateChannels.y, Material.StateChannelCount);
        if ((EnabledEffects & 4u) != 0u)
            States.z = SampleSmoothedStateSaturation(FragSurfaceIndex, FragUV,
                                                     Material.DemoStateChannels.z, Material.StateChannelCount);
        if ((EnabledEffects & 8u) != 0u)
            States.w = SampleSmoothedStateSaturation(FragSurfaceIndex, FragUV,
                                                     Material.DemoExtraStateChannels.x, Material.StateChannelCount);
    }
    // The base surface has already been drawn. Emit one straight-alpha color
    // for this shared accumulation surface; water is composited over mud here.
    float MudCoverage = (EnabledEffects & 2u) != 0u ? clamp(States.y, 0.0, 1.0) : 0.0;
    float MudAlpha = smoothstep(Cutoff, 0.10, MudCoverage);
    vec3 MudNormal = ApplyMudMicroBump(N, FragWorldPosition, Material.DemoEffectOptions.y);
    vec3 MudColor = ShadeSurface(MapEffectColor(1u, MudCoverage), MudNormal, V,
                                 Material.DemoOptions.z, Material.AmbientLight);
    vec3 PremultipliedColor = MudColor * MudAlpha;
    float SurfaceAlpha = MudAlpha;

    float WaterCoverage = (EnabledEffects & 4u) != 0u ? clamp(States.z, 0.0, 1.0) : 0.0;
    if (WaterCoverage > 0.0)
    {
        vec4 Water = ShadeWaterFilmLayer(N, V, WaterCoverage);
        PremultipliedColor = Water.rgb * Water.a + PremultipliedColor * (1.0 - Water.a);
        SurfaceAlpha = Water.a + SurfaceAlpha * (1.0 - Water.a);
    }

    // Lava keeps its existing highest material priority and remains opaque.
    if ((EnabledEffects & 8u) != 0u && States.w > Material.DemoOptions.y)
    {
        float LavaCoverage = clamp(States.w, 0.0, 1.0);
        vec3 LavaLit = ShadeSurface(LavaColor(LavaCoverage), N, V, 0.34, Material.AmbientLight);
        PremultipliedColor = min(LavaLit + LavaEmission(LavaCoverage, Material.DemoOptions.y), vec3(1.0));
        SurfaceAlpha = 1.0;
    }

    if (SurfaceAlpha <= 1e-5) discard;
    OutColor = vec4(min(PremultipliedColor / SurfaceAlpha, vec3(1.0)), SurfaceAlpha);
#elif defined(OVERLAY_LAVA)
    if (FragCoverage <= Material.DemoOptions.y) discard;
    vec3 Color = ShadeSurface(LavaColor(FragCoverage), N, V, 0.34, Material.AmbientLight);
    OutColor = vec4(min(Color + LavaEmission(FragCoverage, Material.DemoOptions.y), vec3(1.0)), 1.0);
#elif defined(OVERLAY_WATER)
    OutColor = ShadeWaterFilmLayer(N, V, FragCoverage);
#else
    vec3 Color = ShadeSurface(MapEffectColor(1u, FragCoverage), N, V, Material.DemoOptions.z,
                              Material.AmbientLight, 0.0);
    OutColor = vec4(Color, 1.0);
#endif
}
#endif
