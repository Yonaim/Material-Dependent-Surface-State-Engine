/**
 * @file SurfaceGPUResources.cpp
 * @brief 패킹된 Surface 데이터를 업로드하고 솔버 디스크립터 세트를 생성한다.
 */

#include "SurfaceState/GPU/SurfaceGPUResources.h"
#include "SurfaceState/GPU/SurfaceGPUBufferPool.h"

#include <glm/gtc/packing.hpp>

#include <algorithm>
#include <cmath>
#include <limits>
#include <stdexcept>
#include <string>
#include <utility>

namespace MDSS::SurfaceState
{
    namespace
    {
        constexpr VkBufferUsageFlags    StorageUsage = VK_BUFFER_USAGE_STORAGE_BUFFER_BIT;
        constexpr VkMemoryPropertyFlags UploadMemory =
            VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT;
        constexpr std::uint32_t DescriptorBindingCount =
            static_cast<std::uint32_t>(TSurfaceGPUDescriptorBinding::Count);

        constexpr std::uint32_t BindingIndex(TSurfaceGPUDescriptorBinding Binding)
        {
            return static_cast<std::uint32_t>(Binding);
        }

        std::size_t GetMaximumStorageBufferRange(VkPhysicalDevice PhysicalDevice)
        {
            VkPhysicalDeviceProperties Properties{};
            vkGetPhysicalDeviceProperties(PhysicalDevice, &Properties);
            return Properties.limits.maxStorageBufferRange;
        }

        std::unique_ptr<GPU::TGPUBuffer> AcquireOrCreateBuffer(
            VkPhysicalDevice PhysicalDevice,
            VkDevice Device,
            VkDeviceSize Size,
            VkBufferUsageFlags Usage,
            GPU::TGPUBufferMemoryCategory Category,
            TSurfaceGPUBufferPool* Pool)
        {
            if (Pool)
            {
                if (auto Buffer = Pool->Acquire(Size, Usage, UploadMemory, Category))
                    return Buffer;
            }
            try
            {
                return std::make_unique<GPU::TGPUBuffer>(
                    PhysicalDevice, Device, Size, Usage, UploadMemory, Category);
            }
            catch (const std::runtime_error&)
            {
                // Retained buffers must not prevent a Scene with new buffer sizes from loading.
                if (!Pool || Pool->GetRetainedBytes() == 0)
                    throw;
                Pool->Clear();
                return std::make_unique<GPU::TGPUBuffer>(
                    PhysicalDevice, Device, Size, Usage, UploadMemory, Category);
            }
        }

        std::unique_ptr<GPU::TGPUBuffer> CreateUploadedBuffer(VkPhysicalDevice PhysicalDevice,
                                                              VkDevice         Device,
                                                              const void*      Data,
                                                              std::size_t      ElementCount,
                                                              std::size_t      ElementStride,
                                                              std::size_t      MaxStorageBufferRange,
                                                              GPU::TGPUBufferMemoryCategory Category =
                                                                  GPU::TGPUBufferMemoryCategory::SurfaceGeometry,
                                                              TSurfaceGPUBufferPool* Pool = nullptr)
        {
            const std::size_t ByteSize =
                GetSurfaceGPUBufferByteSize(ElementCount, ElementStride, MaxStorageBufferRange);
            auto Buffer = AcquireOrCreateBuffer(
                PhysicalDevice, Device, static_cast<VkDeviceSize>(ByteSize), StorageUsage, Category, Pool);
            Buffer->Upload(Data, static_cast<VkDeviceSize>(ByteSize));
            return Buffer;
        }

        std::unique_ptr<GPU::TGPUBuffer> CreateZeroedScalarBuffer(VkPhysicalDevice   PhysicalDevice,
                                                                  VkDevice           Device,
                                                                  std::size_t        ScalarCount,
                                                                  std::size_t        MaxStorageBufferRange,
                                                                  VkBufferUsageFlags Usage = StorageUsage,
                                                                  GPU::TGPUBufferMemoryCategory Category =
                                                                      GPU::TGPUBufferMemoryCategory::SurfaceState,
                                                                  TSurfaceGPUBufferPool* Pool = nullptr)
        {
            const std::size_t ByteSize = GetSurfaceGPUBufferByteSize(ScalarCount, sizeof(float), MaxStorageBufferRange);
            std::vector<float> Zeros(ScalarCount, 0.0F);
            auto Buffer = AcquireOrCreateBuffer(
                PhysicalDevice, Device, static_cast<VkDeviceSize>(ByteSize), Usage, Category, Pool);
            Buffer->Upload(Zeros.data(), static_cast<VkDeviceSize>(ByteSize));
            return Buffer;
        }

    } // 내부 네임스페이스

#pragma region Shared_Geometry_Resources

    void TSurfaceTexelMeshGPUVariant::RetireBuffers(TSurfaceGPUBufferPool& Pool) noexcept
    {
        Pool.Release(std::move(IndexBuffer));
        Pool.Release(std::move(VertexBuffer));
        Pool.Release(std::move(BoundaryBuffer));
    }

    TSurfaceSharedGeometryGPUResources::TSurfaceSharedGeometryGPUResources(
        VkPhysicalDevice                            PhysicalDevice,
        VkDevice                                    Device,
        const TSharedSurfaceGeometryData&           Geometry,
        std::span<const TSurfaceProfileIndex>       ProfileIndexRemap,
        std::span<const Asset::TVertex>             SourceVertices,
        std::span<const Asset::TMeshTriangleSource> SourceTriangles,
        TSurfaceGPUBufferPool*                      Pool)
        : TexelCount(Geometry.GetTexelCount())
    {
        const std::size_t                     MaxRange = GetMaximumStorageBufferRange(PhysicalDevice);
        const TSurfaceGPUSharedGeometryUpload Upload = PackSharedSurfaceGeometry(Geometry, ProfileIndexRemap);
        SurfaceRanges = Upload.SurfaceRanges;
        TexelSurfaceIndexBuffer = CreateUploadedBuffer(PhysicalDevice,
                                                       Device,
                                                       Upload.TexelSurfaceIndices.data(),
                                                       Upload.TexelSurfaceIndices.size(),
                                                       sizeof(std::uint32_t),
                                                       MaxRange, GPU::TGPUBufferMemoryCategory::SurfaceGeometry, Pool);
        TexelProfileIndexBuffer = CreateUploadedBuffer(PhysicalDevice,
                                                       Device,
                                                       Upload.TexelProfileIndices.data(),
                                                       Upload.TexelProfileIndices.size(),
                                                       sizeof(std::uint32_t),
                                                       MaxRange, GPU::TGPUBufferMemoryCategory::SurfaceGeometry, Pool);
        PositionBuffer = CreateUploadedBuffer(PhysicalDevice,
                                              Device,
                                              Upload.Positions.data(),
                                              Upload.Positions.size(),
                                              sizeof(TSurfaceGPUVec4),
                                              MaxRange, GPU::TGPUBufferMemoryCategory::SurfaceGeometry, Pool);
        NormalBuffer = CreateUploadedBuffer(
            PhysicalDevice, Device, Upload.Normals.data(), Upload.Normals.size(), sizeof(TSurfaceGPUVec4), MaxRange,
            GPU::TGPUBufferMemoryCategory::SurfaceGeometry, Pool);
        // 렌더링과 디버그 뷰가 복원 노멀을 GPU에서 텍셀별로 조회한다.
        MesoNormalBuffer = CreateUploadedBuffer(PhysicalDevice,
                                                Device,
                                                Upload.MesoNormals.data(),
                                                Upload.MesoNormals.size(),
                                                sizeof(TSurfaceGPUVec4),
                                                MaxRange, GPU::TGPUBufferMemoryCategory::SurfaceGeometry, Pool);
        GeometryScalarBuffer = CreateUploadedBuffer(PhysicalDevice,
                                                    Device,
                                                    Upload.GeometryScalars.data(),
                                                    Upload.GeometryScalars.size(),
                                                    sizeof(TSurfaceGPUGeometryScalar),
                                                    MaxRange, GPU::TGPUBufferMemoryCategory::SurfaceGeometry, Pool);
        NeighborIndexBuffer = CreateUploadedBuffer(PhysicalDevice,
                                                   Device,
                                                   Upload.NeighborIndices.data(),
                                                   Upload.NeighborIndices.size(),
                                                   sizeof(TSurfaceGPUNeighborIndices),
                                                   MaxRange, GPU::TGPUBufferMemoryCategory::SurfaceGeometry, Pool);
        ReverseNeighborDirectionIndexBuffer = CreateUploadedBuffer(PhysicalDevice,
                                                         Device,
                                                         Upload.ReverseNeighborDirectionIndices.data(),
                                                         Upload.ReverseNeighborDirectionIndices.size(),
                                                         sizeof(std::uint32_t),
                                                         MaxRange, GPU::TGPUBufferMemoryCategory::SurfaceGeometry, Pool);
        SurfaceRangeBuffer = CreateUploadedBuffer(PhysicalDevice,
                                                  Device,
                                                  Upload.SurfaceRanges.data(),
                                                  Upload.SurfaceRanges.size(),
                                                  sizeof(TSurfaceGPUSurfaceRange),
                                                  MaxRange, GPU::TGPUBufferMemoryCategory::SurfaceGeometry, Pool);
        TexelChartIndexBuffer = CreateUploadedBuffer(PhysicalDevice,
                                                     Device,
                                                     Upload.TexelChartIndices.data(),
                                                     Upload.TexelChartIndices.size(),
                                                     sizeof(std::uint32_t),
                                                     MaxRange, GPU::TGPUBufferMemoryCategory::SurfaceGeometry, Pool);
        std::vector<std::uint32_t> BoundaryFlags(TexelCount, 0U);
        for (std::uint32_t Surface = 0; Surface < SurfaceRanges.size(); ++Surface)
        {
            const auto& Range = SurfaceRanges[Surface];
            for (std::uint32_t Y = 0; Y < Range.Height; ++Y)
                for (std::uint32_t X = 0; X < Range.Width; ++X)
                {
                    const std::size_t Center = Range.FirstTexel + std::size_t(Y) * Range.Width + X;
                    const auto Profile = Upload.TexelProfileIndices[Center];
                    const auto Chart = Upload.TexelChartIndices[Center];
                    if (Upload.TexelSurfaceIndices[Center] != Surface)
                    {
                        BoundaryFlags[Center] = 1U;
                        continue;
                    }
                    for (int OffsetY = -1; OffsetY <= 1; ++OffsetY)
                        for (int OffsetX = -1; OffsetX <= 1; ++OffsetX)
                        {
                            const auto NeighborX = static_cast<std::uint32_t>(
                                std::clamp<int>(static_cast<int>(X) + OffsetX, 0, static_cast<int>(Range.Width) - 1));
                            const auto NeighborY = static_cast<std::uint32_t>(
                                std::clamp<int>(static_cast<int>(Y) + OffsetY, 0, static_cast<int>(Range.Height) - 1));
                            const std::size_t Neighbor =
                                Range.FirstTexel + std::size_t(NeighborY) * Range.Width + NeighborX;
                            if (Upload.TexelSurfaceIndices[Neighbor] != Surface ||
                                Upload.TexelProfileIndices[Neighbor] != Profile ||
                                Upload.TexelChartIndices[Neighbor] != Chart)
                                BoundaryFlags[Center] = 1U;
                        }
                }
        }
        RenderSamplingBoundaryFlagBuffer = CreateUploadedBuffer(PhysicalDevice, Device,
                                                                 BoundaryFlags.data(), BoundaryFlags.size(),
                                                                 sizeof(std::uint32_t), MaxRange,
                                                                 GPU::TGPUBufferMemoryCategory::SurfaceGeometry, Pool);
        SimulationResolution = Geometry.GetSurfaces().empty() ? 0U : Geometry.GetSurfaces().front().Resolution.Width;
        const auto MeshMemoryCategory = [](std::uint32_t Resolution)
        {
            switch (Resolution)
            {
                case 64:
                    return GPU::TGPUBufferMemoryCategory::RenderMesh64;
                case 128:
                    return GPU::TGPUBufferMemoryCategory::RenderMesh128;
                case 256:
                    return GPU::TGPUBufferMemoryCategory::RenderMesh256;
                case 512:
                    return GPU::TGPUBufferMemoryCategory::RenderMesh512;
                default:
                    throw std::invalid_argument("Unsupported render mesh resolution for memory tracking.");
            }
        };
        const auto UploadTexelMesh = [&](TSurfaceTexelMesh Mesh,
                                         TSurfaceTexelMeshGPUVariant& Output,
                                         GPU::TGPUBufferMemoryCategory Category)
        {
            Output.Ranges = std::move(Mesh.Surfaces);
            Output.VertexCount = static_cast<std::uint32_t>(Mesh.Vertices.size());
            Output.BoundaryCount = static_cast<std::uint32_t>(Mesh.BoundaryEdges.size());
            if (Mesh.Indices.empty())
                return;
            if (Mesh.SideAdjacency.size() != Mesh.Indices.size() / 3U + Mesh.BoundaryEdges.size())
                throw std::logic_error("Overlay side adjacency does not match render mesh topology.");
            const auto Bytes = static_cast<VkDeviceSize>(Mesh.Indices.size() * sizeof(std::uint32_t));
            Output.IndexBuffer = AcquireOrCreateBuffer(
                PhysicalDevice, Device, Bytes,
                VK_BUFFER_USAGE_INDEX_BUFFER_BIT | VK_BUFFER_USAGE_STORAGE_BUFFER_BIT, Category, Pool);
            Output.IndexBuffer->Upload(Mesh.Indices.data(), Bytes);
            const auto VertexBytes = static_cast<VkDeviceSize>(Mesh.Vertices.size() * sizeof(TSurfaceTexelMeshVertex));
            Output.VertexBuffer = AcquireOrCreateBuffer(
                PhysicalDevice, Device, VertexBytes,
                VK_BUFFER_USAGE_VERTEX_BUFFER_BIT | VK_BUFFER_USAGE_STORAGE_BUFFER_BIT, Category, Pool);
            Output.VertexBuffer->Upload(Mesh.Vertices.data(), VertexBytes);
            // One immutable CSR vertex list per render tile size. Geometry shares these lists;
            // coverage and its history remain owned by each Scene instance.
            for (const std::uint32_t TileSize : {8U, 16U, 32U})
            {
                std::vector<std::uint32_t> SurfaceTileBases(SurfaceRanges.size() + 1U, 0U);
                for (std::size_t Surface = 0; Surface < SurfaceRanges.size(); ++Surface)
                {
                    const auto& Range = SurfaceRanges[Surface];
                    const std::size_t Tiles =
                        ((static_cast<std::size_t>(Range.Width) + TileSize - 1U) / TileSize) *
                        ((static_cast<std::size_t>(Range.Height) + TileSize - 1U) / TileSize);
                    if (Tiles > std::numeric_limits<std::uint32_t>::max() - SurfaceTileBases[Surface])
                        throw std::overflow_error("Overlay tile count exceeds uint32 range.");
                    SurfaceTileBases[Surface + 1U] = SurfaceTileBases[Surface] + static_cast<std::uint32_t>(Tiles);
                }
                const std::uint32_t TileCount = SurfaceTileBases.back();
                std::vector<std::vector<std::uint32_t>> TileVertices(TileCount);
                for (std::uint32_t Vertex = 0; Vertex < Mesh.Vertices.size(); ++Vertex)
                {
                    const auto& UVSurface = Mesh.Vertices[Vertex].UVSurface;
                    if (!std::isfinite(UVSurface.x) || !std::isfinite(UVSurface.y) ||
                        !std::isfinite(UVSurface.w) || UVSurface.w < 0.0F ||
                        UVSurface.w >= static_cast<float>(SurfaceRanges.size()))
                        throw std::runtime_error("Overlay vertex has an invalid surface or UV.");
                    const auto Surface = static_cast<std::uint32_t>(UVSurface.w);
                    const auto& Range = SurfaceRanges[Surface];
                    if (Range.Width == 0U || Range.Height == 0U)
                        throw std::runtime_error("Overlay vertex belongs to an empty surface range.");
                    const auto X = std::min(static_cast<std::uint32_t>(
                        std::clamp(UVSurface.x, 0.0F, 1.0F) * Range.Width), Range.Width - 1U);
                    const auto Y = std::min(static_cast<std::uint32_t>(
                        std::clamp(UVSurface.y, 0.0F, 1.0F) * Range.Height), Range.Height - 1U);
                    const auto TilesX = (Range.Width + TileSize - 1U) / TileSize;
                    const auto Candidate = SurfaceTileBases[Surface] + (Y / TileSize) * TilesX + X / TileSize;
                    TileVertices[Candidate].push_back(Vertex);
                }
                std::vector<std::uint32_t> Packed(TileCount + 1U, 0U);
                for (std::uint32_t Tile = 0; Tile < TileCount; ++Tile)
                {
                    Packed[Tile] = static_cast<std::uint32_t>(Packed.size());
                    Packed.insert(Packed.end(), TileVertices[Tile].begin(), TileVertices[Tile].end());
                }
                Packed[TileCount] = static_cast<std::uint32_t>(Packed.size());
                TSurfaceTexelMeshGPUVariant::TTileVertexList List;
                List.TileCount = TileCount;
                List.Words = std::move(Packed);
                Output.TileVertexLists.emplace(TileSize, std::move(List));
            }
            // The boundary shader reads immutable side neighbors after the boundary edge range.
            // Packing both into one buffer keeps the overlay descriptor count unchanged.
            std::vector<glm::uvec4> PackedBoundaries;
            PackedBoundaries.reserve(Mesh.BoundaryEdges.size() + Mesh.SideAdjacency.size());
            PackedBoundaries.insert(PackedBoundaries.end(), Mesh.BoundaryEdges.begin(), Mesh.BoundaryEdges.end());
            PackedBoundaries.insert(PackedBoundaries.end(), Mesh.SideAdjacency.begin(), Mesh.SideAdjacency.end());
            const auto BoundaryBytes = static_cast<VkDeviceSize>(PackedBoundaries.size() * sizeof(glm::uvec4));
            if (BoundaryBytes == 0 || BoundaryBytes > MaxRange)
                throw std::length_error("Overlay boundary and side adjacency exceed maxStorageBufferRange.");
            Output.BoundaryBuffer = AcquireOrCreateBuffer(
                PhysicalDevice, Device, BoundaryBytes, VK_BUFFER_USAGE_STORAGE_BUFFER_BIT, Category, Pool);
            Output.BoundaryBuffer->Upload(PackedBoundaries.data(), BoundaryBytes);
        };
        UploadTexelMesh(BuildSurfaceTexelMesh(Geometry, SourceVertices, SourceTriangles),
                        FullTexelMesh,
                        MeshMemoryCategory(SimulationResolution));
        for (const auto& Preset : SurfaceRenderMeshResolutionPresets)
        {
            if (Preset.Resolution == SimulationResolution)
                continue;
            TSurfaceTexelMeshGPUVariant Variant;
            UploadTexelMesh(BuildSurfaceTexelMesh(Geometry, SourceVertices, SourceTriangles, Preset.Resolution),
                            Variant,
                            MeshMemoryCategory(Preset.Resolution));
            TexelMeshVariants.emplace(Preset.Resolution, std::move(Variant));
        }
    }

    const GPU::TGPUBuffer& TSurfaceSharedGeometryGPUResources::GetTexelSurfaceIndexBuffer() const noexcept
    {
        return *TexelSurfaceIndexBuffer;
    }

    const GPU::TGPUBuffer& TSurfaceSharedGeometryGPUResources::GetTexelProfileIndexBuffer() const noexcept
    {
        return *TexelProfileIndexBuffer;
    }

    const GPU::TGPUBuffer& TSurfaceSharedGeometryGPUResources::GetPositionBuffer() const noexcept
    {
        return *PositionBuffer;
    }

    const GPU::TGPUBuffer& TSurfaceSharedGeometryGPUResources::GetNormalBuffer() const noexcept
    {
        return *NormalBuffer;
    }

    const GPU::TGPUBuffer& TSurfaceSharedGeometryGPUResources::GetMesoNormalBuffer() const noexcept
    {
        return *MesoNormalBuffer;
    }

    const GPU::TGPUBuffer& TSurfaceSharedGeometryGPUResources::GetGeometryScalarBuffer() const noexcept
    {
        return *GeometryScalarBuffer;
    }

    const GPU::TGPUBuffer& TSurfaceSharedGeometryGPUResources::GetNeighborIndexBuffer() const noexcept
    {
        return *NeighborIndexBuffer;
    }

    const GPU::TGPUBuffer& TSurfaceSharedGeometryGPUResources::GetReverseNeighborDirectionIndexBuffer() const noexcept
    {
        return *ReverseNeighborDirectionIndexBuffer;
    }

    const GPU::TGPUBuffer& TSurfaceSharedGeometryGPUResources::GetSurfaceRangeBuffer() const noexcept
    {
        return *SurfaceRangeBuffer;
    }

    const std::vector<TSurfaceGPUSurfaceRange>& TSurfaceSharedGeometryGPUResources::GetSurfaceRanges() const noexcept
    {
        return SurfaceRanges;
    }

    const GPU::TGPUBuffer& TSurfaceSharedGeometryGPUResources::GetTexelChartIndexBuffer() const noexcept
    {
        return *TexelChartIndexBuffer;
    }

    const GPU::TGPUBuffer& TSurfaceSharedGeometryGPUResources::GetRenderSamplingBoundaryFlagBuffer() const noexcept
    {
        return *RenderSamplingBoundaryFlagBuffer;
    }

    std::size_t TSurfaceSharedGeometryGPUResources::GetTexelCount() const noexcept
    {
        return TexelCount;
    }

    void TSurfaceSharedGeometryGPUResources::RetireBuffers(TSurfaceGPUBufferPool& Pool) noexcept
    {
        Pool.Release(std::move(TexelSurfaceIndexBuffer));
        Pool.Release(std::move(TexelProfileIndexBuffer));
        Pool.Release(std::move(PositionBuffer));
        Pool.Release(std::move(NormalBuffer));
        Pool.Release(std::move(MesoNormalBuffer));
        Pool.Release(std::move(GeometryScalarBuffer));
        Pool.Release(std::move(NeighborIndexBuffer));
        Pool.Release(std::move(ReverseNeighborDirectionIndexBuffer));
        Pool.Release(std::move(SurfaceRangeBuffer));
        Pool.Release(std::move(TexelChartIndexBuffer));
        Pool.Release(std::move(RenderSamplingBoundaryFlagBuffer));
        FullTexelMesh.RetireBuffers(Pool);
        for (auto& [Resolution, Variant] : TexelMeshVariants)
            Variant.RetireBuffers(Pool);
    }

#pragma endregion

#pragma region Profile_Resources

    TSurfaceProfileGPUResources::TSurfaceProfileGPUResources(VkPhysicalDevice PhysicalDevice,
                                                             VkDevice         Device,
                                                             const std::vector<TSurfaceResponseProfileData>& Profiles,
                                                             const TSurfaceStateRegistry&                    Registry,
                                                             TSurfaceGPUBufferPool*                          Pool)
        : ProfileCount(Profiles.size()), ChannelCount(Registry.GetStateCount())
    {
        const std::size_t              MaxRange = GetMaximumStorageBufferRange(PhysicalDevice);
        const TSurfaceGPUProfileUpload Upload = PackSurfaceProfiles(Profiles, Registry);
        SupportedChannels = Upload.Supported;

        // GPU hot path uses a 3-plane vec4 SoA layout instead of 48-byte AoS records:
        // [Capacity/Input/Transfer records][Decay/Geometry records][Accumulation/Thickness records].
        // This keeps the descriptor count unchanged while allowing shaders that only need capacity or
        // accumulation fields to fetch one 16-byte vector instead of touching the whole logical record.
        std::vector<TSurfaceGPUVec4> ParameterPlanes(Upload.Parameters.size() * 3U);
        const std::size_t RecordCount = Upload.Parameters.size();
        for (std::size_t Record = 0; Record < RecordCount; ++Record)
        {
            const auto& P = Upload.Parameters[Record];
            ParameterPlanes[Record] = {P.CapacityInputAndTransfer[0], P.CapacityInputAndTransfer[1],
                                       P.CapacityInputAndTransfer[2], P.CapacityInputAndTransfer[3]};
            ParameterPlanes[RecordCount + Record] = {P.DecayAndGeometry[0], P.DecayAndGeometry[1],
                                                     P.DecayAndGeometry[2], P.DecayAndGeometry[3]};
            ParameterPlanes[RecordCount * 2U + Record] = {P.AccumulationThickness[0], P.AccumulationThickness[1],
                                                          P.AccumulationThickness[2], P.AccumulationThickness[3]};
        }
        ParametersBuffer = CreateUploadedBuffer(PhysicalDevice,
                                                Device,
                                                ParameterPlanes.data(),
                                                ParameterPlanes.size(),
                                                sizeof(TSurfaceGPUVec4),
                                                MaxRange,
                                                GPU::TGPUBufferMemoryCategory::SurfaceProfile, Pool);
        SupportedBuffer = CreateUploadedBuffer(
            PhysicalDevice,
            Device,
            Upload.Supported.data(),
            Upload.Supported.size(),
            sizeof(std::uint32_t),
            MaxRange,
            GPU::TGPUBufferMemoryCategory::SurfaceProfile, Pool);
    }

    const GPU::TGPUBuffer& TSurfaceProfileGPUResources::GetParametersBuffer() const noexcept
    {
        return *ParametersBuffer;
    }

    void TSurfaceProfileGPUResources::RetireBuffers(TSurfaceGPUBufferPool& Pool) noexcept
    {
        Pool.Release(std::move(ParametersBuffer));
        Pool.Release(std::move(SupportedBuffer));
    }

    const GPU::TGPUBuffer& TSurfaceProfileGPUResources::GetSupportedBuffer() const noexcept
    {
        return *SupportedBuffer;
    }

    std::size_t TSurfaceProfileGPUResources::GetProfileCount() const noexcept
    {
        return ProfileCount;
    }

    std::size_t TSurfaceProfileGPUResources::GetChannelCount() const noexcept
    {
        return ChannelCount;
    }

    bool TSurfaceProfileGPUResources::IsSupported(std::size_t ProfileIndex, std::size_t ChannelIndex) const noexcept
    {
        return ProfileIndex < ProfileCount && ChannelIndex < ChannelCount &&
               SupportedChannels[ProfileIndex * ChannelCount + ChannelIndex] != 0U;
    }

    void TSurfaceProfileGPUResources::UpdateParameters(std::size_t                    ProfileIndex,
                                                       std::size_t                    ChannelIndex,
                                                       const TSurfaceStateParameters& Parameters)
    {
        if (ProfileIndex >= ProfileCount || ChannelIndex >= ChannelCount)
        {
            throw std::out_of_range("Surface Profile parameter index is outside the GPU table.");
        }

        const std::size_t RecordIndex = GetSurfaceGPUProfileRecordIndex(ProfileIndex, ChannelIndex, ChannelCount);
        if (RecordIndex >= SupportedChannels.size() || SupportedChannels[RecordIndex] == 0U)
        {
            throw std::invalid_argument("Cannot override a State that this Profile does not support.");
        }

        const std::array<TSurfaceGPUVec4, 3> Packed{
            TSurfaceGPUVec4{Parameters.StateCapacity,
                            Parameters.InputFactor,
                            Parameters.SaturationTransferFactor,
                            Parameters.GeometryTransferFactor},
            TSurfaceGPUVec4{Parameters.DecayRate,
                            Parameters.CavityRetentionFactor,
                            Parameters.AccumulationFactor,
                            Parameters.CavityFillFactor},
            TSurfaceGPUVec4{Parameters.ThicknessPerAmount, Parameters.CavityTransportRetentionFactor, 0.0F, 0.0F}};
        const VkDeviceSize PlaneStride = static_cast<VkDeviceSize>(ProfileCount * ChannelCount * sizeof(TSurfaceGPUVec4));
        const VkDeviceSize RecordOffset = static_cast<VkDeviceSize>(RecordIndex * sizeof(TSurfaceGPUVec4));
        for (std::size_t Plane = 0; Plane < Packed.size(); ++Plane)
            ParametersBuffer->Upload(&Packed[Plane], sizeof(TSurfaceGPUVec4),
                                     static_cast<VkDeviceSize>(Plane) * PlaneStride + RecordOffset);
    }

#pragma endregion

#pragma region Instance_State_Resources

    TSurfaceInstanceGPUResources::TSurfaceInstanceGPUResources(
        VkPhysicalDevice                    PhysicalDevice,
        VkDevice                            Device,
        std::size_t                         TexelCount,
        std::size_t                         ChannelCount,
        const std::vector<float>&           TransferWeights,
        const std::vector<TSurfaceGPUVec4>& TransferWeightDebugAverages,
        const std::vector<float>&           WorldTexelAreas,
        TSurfaceGPUBufferPool*             Pool)
        : TexelCount(TexelCount), ChannelCount(ChannelCount)
    {
        if (TexelCount == 0 || ChannelCount == 0)
        {
            throw std::invalid_argument("Surface Instance GPU resources require texels and State channels.");
        }
        if (TexelCount > std::numeric_limits<std::size_t>::max() / ChannelCount)
        {
            throw std::overflow_error("Surface Instance GPU scalar count overflowed.");
        }
        if (TexelCount > std::numeric_limits<std::size_t>::max() / SurfaceNeighborCount ||
            TransferWeights.size() != TexelCount * SurfaceNeighborCount)
        {
            throw std::invalid_argument("TransferWeight cache size must be texel count × neighbor count.");
        }
        const std::vector<float> Areas =
            WorldTexelAreas.empty() ? std::vector<float>(TexelCount, SurfaceStateReferenceArea) : WorldTexelAreas;
        if (Areas.size() != TexelCount ||
            std::any_of(Areas.begin(), Areas.end(), [](float A) { return !std::isfinite(A) || A < 0.0F; }))
            throw std::invalid_argument("World texel areas must be finite, nonnegative and match texel count.");
        ScalarCount = TexelCount * ChannelCount;
        const std::size_t MaxRange = GetMaximumStorageBufferRange(PhysicalDevice);
        WorldTexelAreaBuffer =
            CreateUploadedBuffer(PhysicalDevice,
                                 Device,
                                 Areas.data(),
                                 Areas.size(),
                                 sizeof(float),
                                 MaxRange,
                                 GPU::TGPUBufferMemoryCategory::SurfaceState, Pool);
        std::vector<TSurfaceGPUVec4> ZeroDynamicGeometry(TexelCount * 2U);
        DynamicGeometryBuffer = CreateUploadedBuffer(PhysicalDevice,
                                                     Device,
                                                     ZeroDynamicGeometry.data(),
                                                     ZeroDynamicGeometry.size(),
                                                     sizeof(TSurfaceGPUVec4),
                                                     MaxRange,
                                                     GPU::TGPUBufferMemoryCategory::SurfaceState, Pool);
        DynamicConcavityWeightBuffer =
            CreateZeroedScalarBuffer(PhysicalDevice, Device, TexelCount, MaxRange, StorageUsage,
                                     GPU::TGPUBufferMemoryCategory::SurfaceState, Pool);
        const TSurfaceSparseMetadataLayout SparseLayout = GetSurfaceSparseMetadataLayout(TexelCount);
        // 3 texel planes + persistent solver A/B sets + CPU-input activation list + accumulation/geometry schedules.
        // The two solver sets ping-pong with State A/B so Pass2 can directly build the next step's active set.
        const std::size_t AccumulationWordCount = SparseLayout.TotalWordCount;
        AccumulationHeightBuffer = CreateZeroedScalarBuffer(PhysicalDevice,
                                                            Device,
                                                            AccumulationWordCount,
                                                            MaxRange,
                                                            StorageUsage | VK_BUFFER_USAGE_INDIRECT_BUFFER_BIT |
                                                                VK_BUFFER_USAGE_TRANSFER_SRC_BIT,
                                                            GPU::TGPUBufferMemoryCategory::SurfaceState, Pool);
        StateABuffer = CreateZeroedScalarBuffer(PhysicalDevice, Device, ScalarCount, MaxRange, StorageUsage,
                                                GPU::TGPUBufferMemoryCategory::SurfaceState, Pool);
        StateBBuffer = CreateZeroedScalarBuffer(PhysicalDevice, Device, ScalarCount, MaxRange, StorageUsage,
                                                GPU::TGPUBufferMemoryCategory::SurfaceState, Pool);
        OutgoingFluxScaleBuffer = CreateZeroedScalarBuffer(PhysicalDevice, Device, ScalarCount, MaxRange, StorageUsage,
                                                           GPU::TGPUBufferMemoryCategory::SurfaceState, Pool);
        InputDeltaBuffer = CreateZeroedScalarBuffer(PhysicalDevice, Device, ScalarCount, MaxRange, StorageUsage,
                                                    GPU::TGPUBufferMemoryCategory::SurfaceState, Pool);
        TransferWeightBuffer = CreateUploadedBuffer(
            PhysicalDevice,
            Device,
            TransferWeights.data(),
            TransferWeights.size(),
            sizeof(float),
            MaxRange,
            GPU::TGPUBufferMemoryCategory::SurfaceState, Pool);
        std::vector<TSurfaceGPUVec4>        ZeroDebugAverages;
        const std::vector<TSurfaceGPUVec4>* DebugAverages = &TransferWeightDebugAverages;
        if (DebugAverages->empty())
        {
            ZeroDebugAverages.resize(TexelCount);
            DebugAverages = &ZeroDebugAverages;
        }
        if (DebugAverages->size() != TexelCount)
        {
            throw std::invalid_argument("TransferWeight debug averages must match the texel count.");
        }
        TransferWeightDebugAverageBuffer = CreateUploadedBuffer(
            PhysicalDevice,
            Device,
            DebugAverages->data(),
            DebugAverages->size(),
            sizeof(TSurfaceGPUVec4),
            MaxRange,
            GPU::TGPUBufferMemoryCategory::SurfaceState, Pool);
        // 첫 ScalarCount는 기존 RawOutgoing 합, 뒤 8*ScalarCount는 선택적 방향별 RawEdgeFlux cache다.
        // 같은 descriptor를 확장해 storage-buffer binding 수를 늘리지 않는다.
        if (ScalarCount > std::numeric_limits<std::size_t>::max() / (SurfaceNeighborCount + 1U))
            throw std::overflow_error("Surface raw-flux cache size overflowed.");
        RawOutgoingBuffer = CreateZeroedScalarBuffer(
            PhysicalDevice, Device, ScalarCount * (SurfaceNeighborCount + 1U), MaxRange, StorageUsage,
            GPU::TGPUBufferMemoryCategory::SurfaceState, Pool);
    }

    const GPU::TGPUBuffer& TSurfaceInstanceGPUResources::GetStateABuffer() const noexcept
    {
        return *StateABuffer;
    }

    void TSurfaceInstanceGPUResources::RetireBuffers(TSurfaceGPUBufferPool& Pool) noexcept
    {
        Pool.Release(std::move(StateABuffer));
        Pool.Release(std::move(StateBBuffer));
        Pool.Release(std::move(OutgoingFluxScaleBuffer));
        Pool.Release(std::move(InputDeltaBuffer));
        Pool.Release(std::move(TransferWeightBuffer));
        Pool.Release(std::move(TransferWeightDebugAverageBuffer));
        Pool.Release(std::move(RawOutgoingBuffer));
        Pool.Release(std::move(WorldTexelAreaBuffer));
        Pool.Release(std::move(DynamicGeometryBuffer));
        Pool.Release(std::move(DynamicConcavityWeightBuffer));
        Pool.Release(std::move(AccumulationHeightBuffer));
    }

    const GPU::TGPUBuffer& TSurfaceInstanceGPUResources::GetStateBBuffer() const noexcept
    {
        return *StateBBuffer;
    }

    const GPU::TGPUBuffer& TSurfaceInstanceGPUResources::GetOutgoingFluxScaleBuffer() const noexcept
    {
        return *OutgoingFluxScaleBuffer;
    }

    const GPU::TGPUBuffer& TSurfaceInstanceGPUResources::GetInputDeltaBuffer() const noexcept
    {
        return *InputDeltaBuffer;
    }

    const GPU::TGPUBuffer& TSurfaceInstanceGPUResources::GetTransferWeightBuffer() const noexcept
    {
        return *TransferWeightBuffer;
    }

    const GPU::TGPUBuffer& TSurfaceInstanceGPUResources::GetTransferWeightDebugAverageBuffer() const noexcept
    {
        return *TransferWeightDebugAverageBuffer;
    }

    const GPU::TGPUBuffer& TSurfaceInstanceGPUResources::GetRawOutgoingBuffer() const noexcept
    {
        return *RawOutgoingBuffer;
    }

    const GPU::TGPUBuffer& TSurfaceInstanceGPUResources::GetWorldTexelAreaBuffer() const noexcept
    {
        return *WorldTexelAreaBuffer;
    }

    const GPU::TGPUBuffer& TSurfaceInstanceGPUResources::GetDynamicGeometryBuffer() const noexcept
    {
        return *DynamicGeometryBuffer;
    }

    const GPU::TGPUBuffer& TSurfaceInstanceGPUResources::GetDynamicConcavityWeightBuffer() const noexcept
    {
        return *DynamicConcavityWeightBuffer;
    }

    const GPU::TGPUBuffer& TSurfaceInstanceGPUResources::GetAccumulationHeightBuffer() const noexcept
    {
        return *AccumulationHeightBuffer;
    }

    void TSurfaceInstanceGPUResources::UpdateWorldTexelAreas(const std::vector<float>& Areas)
    {
        if (Areas.size() != TexelCount ||
            std::any_of(Areas.begin(), Areas.end(), [](float A) { return !std::isfinite(A) || A < 0.0F; }))
            throw std::invalid_argument("Invalid updated world texel areas.");
        WorldTexelAreaBuffer->Upload(Areas.data(), WorldTexelAreaBuffer->GetSize());
    }

    void
    TSurfaceInstanceGPUResources::UpdateTransferWeights(const std::vector<float>&           TransferWeights,
                                                        const std::vector<TSurfaceGPUVec4>& TransferWeightDebugAverages,
                                                        bool                                bHalfPrecision)
    {
        if (TransferWeights.size() != TexelCount * SurfaceNeighborCount)
        {
            throw std::invalid_argument("Updated TransferWeight cache has an incompatible size.");
        }
        if (bHalfPrecision)
        {
            // Runtime A/B keeps the original allocation. FP16 mode uses only the first 4 uint words/texel.
            std::vector<std::uint32_t> Packed(TexelCount * (SurfaceNeighborCount / 2U), 0U);
            for (std::size_t Texel = 0; Texel < TexelCount; ++Texel)
            {
                for (std::size_t Pair = 0; Pair < SurfaceNeighborCount / 2U; ++Pair)
                {
                    const std::size_t D0 = Pair * 2U;
                    const std::size_t D1 = D0 + 1U;
                    Packed[Texel * (SurfaceNeighborCount / 2U) + Pair] = glm::packHalf2x16(
                        glm::vec2(std::clamp(TransferWeights[Texel * SurfaceNeighborCount + D0], 0.0F, 1.0F),
                                  std::clamp(TransferWeights[Texel * SurfaceNeighborCount + D1], 0.0F, 1.0F)));
                }
            }
            TransferWeightBuffer->Upload(Packed.data(),
                static_cast<VkDeviceSize>(Packed.size() * sizeof(std::uint32_t)));
        }
        else
        {
            // Buffer is uint-addressed in GLSL, but IEEE-754 float bytes are intentionally uploaded verbatim.
            TransferWeightBuffer->Upload(TransferWeights.data(), TransferWeightBuffer->GetSize());
        }
        if (!TransferWeightDebugAverages.empty())
        {
            if (TransferWeightDebugAverages.size() != TexelCount)
            {
                throw std::invalid_argument("Updated TransferWeight debug averages have an incompatible size.");
            }
            TransferWeightDebugAverageBuffer->Upload(TransferWeightDebugAverages.data(),
                                                     TransferWeightDebugAverageBuffer->GetSize());
        }
    }

    std::size_t TSurfaceInstanceGPUResources::GetTexelCount() const noexcept
    {
        return TexelCount;
    }

    std::size_t TSurfaceInstanceGPUResources::GetChannelCount() const noexcept
    {
        return ChannelCount;
    }

    void TSurfaceInstanceGPUResources::ResetState(const std::vector<float>& ResetOutgoingFluxScale)
    {
        if (ResetOutgoingFluxScale.size() != ScalarCount)
        {
            throw std::invalid_argument("Reset OutgoingFluxScale must match the instance scalar count.");
        }
        const std::vector<float> Zeros(ScalarCount, 0.0F);
        const VkDeviceSize       ByteSize = static_cast<VkDeviceSize>(ScalarCount * sizeof(float));
        StateABuffer->Upload(Zeros.data(), ByteSize);
        StateBBuffer->Upload(Zeros.data(), ByteSize);
        InputDeltaBuffer->Upload(Zeros.data(), ByteSize);
        RawOutgoingBuffer->Upload(Zeros.data(), ByteSize);
        OutgoingFluxScaleBuffer->Upload(ResetOutgoingFluxScale.data(), ByteSize);

        // Rendering now consumes the solver-produced accumulation height directly.  Reset it together
        // with State so a paused/reset frame cannot display stale derived height before the next step.
        const std::size_t AccumulationWordCount =
            static_cast<std::size_t>(AccumulationHeightBuffer->GetSize() / sizeof(std::uint32_t));
        const std::vector<std::uint32_t> ZeroAccumulation(AccumulationWordCount, 0U);
        AccumulationHeightBuffer->Upload(ZeroAccumulation.data(), AccumulationHeightBuffer->GetSize());
    }

#pragma endregion

#pragma region Descriptor_Resources

    TSurfaceStateDescriptorResources::TSurfaceStateDescriptorResources(
        VkDevice                                  Device,
        const TSurfaceSharedGeometryGPUResources& SharedGeometry,
        const TSurfaceProfileGPUResources&        Profiles,
        const TSurfaceInstanceGPUResources&       Instance)
        : Device(Device), SharedGeometryResources(&SharedGeometry), ProfileResources(&Profiles)
    {
        if (SharedGeometry.GetTexelCount() != Instance.GetTexelCount() ||
            Profiles.GetChannelCount() != Instance.GetChannelCount())
        {
            throw std::invalid_argument("Surface descriptor resources have incompatible texel or channel counts.");
        }

        std::array<VkDescriptorSetLayoutBinding, DescriptorBindingCount> Bindings{};
        for (std::uint32_t Binding = 0; Binding < DescriptorBindingCount; ++Binding)
        {
            Bindings[Binding].binding = Binding;
            Bindings[Binding].descriptorType = VK_DESCRIPTOR_TYPE_STORAGE_BUFFER;
            Bindings[Binding].descriptorCount = 1;
            Bindings[Binding].stageFlags =
                Binding == static_cast<std::uint32_t>(TSurfaceGPUDescriptorBinding::TransferWeightDebugAverages)
                    ? VK_SHADER_STAGE_FRAGMENT_BIT
                    : VK_SHADER_STAGE_COMPUTE_BIT | VK_SHADER_STAGE_FRAGMENT_BIT | VK_SHADER_STAGE_VERTEX_BIT;
        }

        VkDescriptorSetLayoutCreateInfo LayoutInfo{};
        LayoutInfo.sType = VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO;
        LayoutInfo.bindingCount = static_cast<std::uint32_t>(Bindings.size());
        LayoutInfo.pBindings = Bindings.data();
        if (vkCreateDescriptorSetLayout(Device, &LayoutInfo, nullptr, &Layout) != VK_SUCCESS)
        {
            throw std::runtime_error("Failed to create Surface solver descriptor set layout.");
        }

        VkDescriptorPoolSize PoolSize{};
        PoolSize.type = VK_DESCRIPTOR_TYPE_STORAGE_BUFFER;
        PoolSize.descriptorCount = DescriptorBindingCount * static_cast<std::uint32_t>(Sets.size());

        VkDescriptorPoolCreateInfo PoolInfo{};
        PoolInfo.sType = VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO;
        PoolInfo.maxSets = static_cast<std::uint32_t>(Sets.size());
        PoolInfo.poolSizeCount = 1;
        PoolInfo.pPoolSizes = &PoolSize;
        if (vkCreateDescriptorPool(Device, &PoolInfo, nullptr, &Pool) != VK_SUCCESS)
        {
            vkDestroyDescriptorSetLayout(Device, Layout, nullptr);
            Layout = VK_NULL_HANDLE;
            throw std::runtime_error("Failed to create Surface solver descriptor pool.");
        }

        const std::array<VkDescriptorSetLayout, 2> Layouts{Layout, Layout};
        VkDescriptorSetAllocateInfo                AllocateInfo{};
        AllocateInfo.sType = VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO;
        AllocateInfo.descriptorPool = Pool;
        AllocateInfo.descriptorSetCount = static_cast<std::uint32_t>(Layouts.size());
        AllocateInfo.pSetLayouts = Layouts.data();
        if (vkAllocateDescriptorSets(Device, &AllocateInfo, Sets.data()) != VK_SUCCESS)
        {
            vkDestroyDescriptorPool(Device, Pool, nullptr);
            Pool = VK_NULL_HANDLE;
            vkDestroyDescriptorSetLayout(Device, Layout, nullptr);
            Layout = VK_NULL_HANDLE;
            throw std::runtime_error("Failed to allocate Surface solver descriptor sets.");
        }

        const std::array<const GPU::TGPUBuffer*, DescriptorBindingCount> SharedAndProfileBuffers{
            &SharedGeometry.GetTexelSurfaceIndexBuffer(),
            &SharedGeometry.GetTexelProfileIndexBuffer(),
            &SharedGeometry.GetPositionBuffer(),
            &SharedGeometry.GetNormalBuffer(),
            &SharedGeometry.GetGeometryScalarBuffer(),
            &SharedGeometry.GetNeighborIndexBuffer(),
            &Profiles.GetParametersBuffer(),
            &Profiles.GetSupportedBuffer(),
            nullptr,
            nullptr,
            &Instance.GetOutgoingFluxScaleBuffer(),
            &Instance.GetInputDeltaBuffer(),
            &SharedGeometry.GetSurfaceRangeBuffer(),
            &SharedGeometry.GetTexelChartIndexBuffer(),
            &Instance.GetTransferWeightBuffer(),
            &Instance.GetRawOutgoingBuffer(),
            &Instance.GetTransferWeightDebugAverageBuffer(),
            // 바인딩 17에는 공유 Meso 노멀 버퍼를 연결한다.
            &SharedGeometry.GetMesoNormalBuffer(),
            &SharedGeometry.GetReverseNeighborDirectionIndexBuffer(),
            &Instance.GetWorldTexelAreaBuffer(),
            &Instance.GetDynamicGeometryBuffer(),
            &Instance.GetAccumulationHeightBuffer(),
            &Instance.GetDynamicConcavityWeightBuffer()};

        for (std::size_t SetIndex = 0; SetIndex < Sets.size(); ++SetIndex)
        {
            const bool             bAB = SetIndex == 0;
            const GPU::TGPUBuffer* StateCurrent = bAB ? &Instance.GetStateABuffer() : &Instance.GetStateBBuffer();
            const GPU::TGPUBuffer* StateNext = bAB ? &Instance.GetStateBBuffer() : &Instance.GetStateABuffer();
            std::array<VkDescriptorBufferInfo, DescriptorBindingCount> BufferInfos{};
            std::array<VkWriteDescriptorSet, DescriptorBindingCount>   Writes{};
            for (std::uint32_t BindingNumber = 0; BindingNumber < DescriptorBindingCount; ++BindingNumber)
            {
                const TSurfaceGPUDescriptorBinding Binding = static_cast<TSurfaceGPUDescriptorBinding>(BindingNumber);
                const GPU::TGPUBuffer*             Buffer = SharedAndProfileBuffers[BindingNumber];
                if (Binding == TSurfaceGPUDescriptorBinding::CurrentState)
                {
                    Buffer = StateCurrent;
                }
                else if (Binding == TSurfaceGPUDescriptorBinding::NextState)
                {
                    Buffer = StateNext;
                }
                BufferInfos[BindingNumber] = {Buffer->GetHandle(), 0, Buffer->GetSize()};
                BoundBufferHandles[SetIndex][BindingNumber] = Buffer->GetHandle();

                VkWriteDescriptorSet& Write = Writes[BindingNumber];
                Write.sType = VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET;
                Write.dstSet = Sets[SetIndex];
                Write.dstBinding = BindingIndex(Binding);
                Write.descriptorCount = 1;
                Write.descriptorType = VK_DESCRIPTOR_TYPE_STORAGE_BUFFER;
                Write.pBufferInfo = &BufferInfos[BindingNumber];
            }
            vkUpdateDescriptorSets(Device, static_cast<std::uint32_t>(Writes.size()), Writes.data(), 0, nullptr);
        }
    }

    TSurfaceStateDescriptorResources::~TSurfaceStateDescriptorResources()
    {
        if (Pool != VK_NULL_HANDLE)
        {
            vkDestroyDescriptorPool(Device, Pool, nullptr);
            Pool = VK_NULL_HANDLE;
        }
        if (Layout != VK_NULL_HANDLE)
        {
            vkDestroyDescriptorSetLayout(Device, Layout, nullptr);
            Layout = VK_NULL_HANDLE;
        }
    }

    VkDescriptorSetLayout TSurfaceStateDescriptorResources::GetLayout() const noexcept
    {
        return Layout;
    }

    VkDescriptorSet TSurfaceStateDescriptorResources::GetABSet() const noexcept
    {
        return Sets[0];
    }

    VkDescriptorSet TSurfaceStateDescriptorResources::GetBASet() const noexcept
    {
        return Sets[1];
    }

    VkBuffer TSurfaceStateDescriptorResources::GetBoundBufferHandle(TSurfaceGPUDescriptorBinding Binding,
                                                                    bool                         bAB) const
    {
        const std::size_t BindingNumber = static_cast<std::size_t>(Binding);
        if (BindingNumber >= static_cast<std::size_t>(TSurfaceGPUDescriptorBinding::Count))
        {
            throw std::out_of_range("Surface descriptor binding is outside the declared layout.");
        }
        return BoundBufferHandles[bAB ? 0U : 1U][BindingNumber];
    }

    std::array<std::uint64_t, 6> TSurfaceStateDescriptorResources::GetGeometryInputRevisions() const noexcept
    {
        return {SharedGeometryResources->GetTexelSurfaceIndexBuffer().GetUploadRevision(),
                SharedGeometryResources->GetPositionBuffer().GetUploadRevision(),
                SharedGeometryResources->GetNormalBuffer().GetUploadRevision(),
                SharedGeometryResources->GetGeometryScalarBuffer().GetUploadRevision(),
                SharedGeometryResources->GetNeighborIndexBuffer().GetUploadRevision(),
                SharedGeometryResources->GetMesoNormalBuffer().GetUploadRevision()};
    }

#pragma endregion
} // MDSS 네임스페이스
