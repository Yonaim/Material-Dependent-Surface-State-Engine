/**
 * @file SurfaceStateRegistry.cpp
 * @brief 로드된 SRProfile에서 결정적인 Runtime State ID를 구성한다.
 */

#include "SurfaceState/Types/SurfaceStateRegistry.h"

#include <algorithm>
#include <limits>
#include <set>
#include <stdexcept>

namespace MDSS::SurfaceState
{
#pragma region State_Registry_Construction

    TSurfaceStateRegistry::TSurfaceStateRegistry(const std::vector<TSurfaceResponseProfileData>& Profiles)
    {
        std::set<std::string> StateNames;
        for (const TSurfaceResponseProfileData& Profile : Profiles)
        {
            ValidateSurfaceResponseProfileData(Profile);
            for (const auto& Entry : Profile.States)
            {
                StateNames.insert(Entry.first);
            }
        }

        if (StateNames.size() >= static_cast<std::size_t>(InvalidStateId))
        {
            throw std::overflow_error("TSurfaceStateRegistry exhausted the TStateId range.");
        }

        Names.assign(StateNames.begin(), StateNames.end());
        const auto Lava = std::find(Names.begin(), Names.end(), "lava");
        if (Lava != Names.end() && Lava != Names.begin())
        {
            std::rotate(Names.begin(), Lava, Lava + 1);
        }
        IDs.reserve(Names.size());
        for (std::size_t Index = 0; Index < Names.size(); ++Index)
        {
            IDs.emplace(Names[Index], static_cast<TStateId>(Index));
        }

        for (const TSurfaceResponseProfileData& Profile : Profiles)
        {
            for (const TSurfaceStateTransition& Transition : Profile.Transitions)
            {
                if (!IDs.contains(Transition.Source))
                {
                    throw std::invalid_argument("Transition references unknown source State '" + Transition.Source +
                                                "'.");
                }
                if (!IDs.contains(Transition.Target))
                {
                    throw std::invalid_argument("Transition references unknown target State '" + Transition.Target +
                                                "'.");
                }
            }
        }
    }
#pragma endregion

#pragma region State_Lookup_and_Profile_Resolution

    std::size_t TSurfaceStateRegistry::GetStateCount() const noexcept
    {
        return Names.size();
    }

    TStateId TSurfaceStateRegistry::GetStateId(std::string_view Name) const
    {
        const std::string CanonicalName = NormalizeSurfaceStateName(Name);
        const auto        Found = IDs.find(CanonicalName);
        if (Found == IDs.end())
        {
            throw std::out_of_range("Unknown State name: '" + CanonicalName + "'.");
        }
        return Found->second;
    }

    const std::string& TSurfaceStateRegistry::GetStateName(TStateId ID) const
    {
        if (ID >= Names.size())
        {
            throw std::out_of_range("Invalid TStateId.");
        }
        return Names[ID];
    }

    TRegisteredSurfaceResponseProfileData
    TSurfaceStateRegistry::ResolveProfile(const TSurfaceResponseProfileData& Profile) const
    {
        ValidateSurfaceResponseProfileData(Profile);

        TRegisteredSurfaceResponseProfileData Result;
        Result.States.resize(Names.size());
        for (const auto& [Name, Parameters] : Profile.States)
        {
            const auto Found = IDs.find(Name);
            if (Found == IDs.end())
            {
                throw std::invalid_argument("Profile contains State not registered in this registry: '" + Name + "'.");
            }
            Result.States[Found->second] = Parameters;
        }

        Result.Transitions.reserve(Profile.Transitions.size());
        for (const TSurfaceStateTransition& Transition : Profile.Transitions)
        {
            const auto Source = IDs.find(Transition.Source);
            const auto Target = IDs.find(Transition.Target);
            if (Source == IDs.end() || Target == IDs.end())
            {
                throw std::invalid_argument("Profile transition references a State absent from this registry.");
            }
            Result.Transitions.push_back(
                {Source->second, Target->second, Transition.Threshold, Transition.TransitionRate});
        }
        return Result;
    }
#pragma endregion
} // namespace MDSS::SurfaceState
