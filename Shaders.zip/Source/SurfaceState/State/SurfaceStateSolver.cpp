/**
 * @file SurfaceStateSolver.cpp
 * @brief 선택적 동적 형상 갱신과 2-pass GPU Surface State solver를 기록한다.
 */

#include "SurfaceState/State/SurfaceStateSolver.h"

#include "SurfaceState/Types/SurfaceSolverRates.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <fstream>
#include <limits>
#include <stdexcept>
#include <string>
#include <vector>

#ifndef MDSS_SHADER_DIR
#define MDSS_SHADER_DIR "Shaders"
#endif

namespace MDSS::SurfaceState
{
#pragma region Solver_Command_Helpers

    namespace
    {
        std::vector<std::uint32_t> ReadSpirvFile(const char* Path)
        {
            std::ifstream File(Path, std::ios::ate | std::ios::binary);
            if (!File.is_open())
            {
                throw std::runtime_error(std::string("Failed to open compute shader: ") + Path);
            }

            const std::streamsize Size = File.tellg();
            if (Size <= 0 || (Size % static_cast<std::streamsize>(sizeof(std::uint32_t))) != 0)
            {
                throw std::runtime_error(std::string("Invalid SPIR-V file size: ") + Path);
            }

            std::vector<std::uint32_t> Code(static_cast<std::size_t>(Size) / sizeof(std::uint32_t));
            File.seekg(0);
            File.read(reinterpret_cast<char*>(Code.data()), Size);
            if (!File)
            {
                throw std::runtime_error(std::string("Failed to read compute shader: ") + Path);
            }
            return Code;
        }

        std::size_t RawModeFromFlags(std::uint32_t Flags)
        {
            if ((Flags & SurfaceSolverRawFluxCacheFlag) == 0U) return 0U;
            const bool Coalesced = (Flags & SurfaceSolverCoalescedRawFluxLayoutFlag) != 0U;
            const bool Half = (Flags & SurfaceSolverHalfRawFluxCacheFlag) != 0U;
            return Half ? (Coalesced ? 4U : 3U) : (Coalesced ? 2U : 1U);
        }

        std::size_t WeightModeFromFlags(std::uint32_t Flags)
        {
            return (Flags & SurfaceSolverHalfDynamicWeightsFlag) != 0U ? 1U : 0U;
        }

        VkBufferMemoryBarrier MakeComputeBufferBarrier(VkBuffer      Buffer,
                                                       VkAccessFlags DestinationAccess,
                                                       VkAccessFlags SourceAccess = VK_ACCESS_SHADER_WRITE_BIT)
        {
            VkBufferMemoryBarrier Barrier{};
            Barrier.sType = VK_STRUCTURE_TYPE_BUFFER_MEMORY_BARRIER;
            Barrier.srcAccessMask = SourceAccess;
            Barrier.dstAccessMask = DestinationAccess;
            Barrier.srcQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
            Barrier.dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
            Barrier.buffer = Buffer;
            Barrier.offset = 0;
            Barrier.size = VK_WHOLE_SIZE;
            return Barrier;
        }

        TSurfaceSolverPushConstants MakePushConstants(const TSurfaceSolverInstanceStep& Step)
        {
            TSurfaceSolverPushConstants Constants{};
            Constants.DeltaTime = Step.DeltaTime;
            Constants.StateChannelCount = static_cast<std::uint32_t>(Step.ChannelCount);
            Constants.LocalTexelCount = static_cast<std::uint32_t>(Step.TexelCount);
            Constants.Flags = Step.SolverFlags;
            Constants.GravityWorld = {Step.GravityWorld.x, Step.GravityWorld.y, Step.GravityWorld.z, 0.0F};

            constexpr float GeometryEpsilon = 1.0e-6F;
            const glm::mat3  ModelLinear(Step.ModelMatrix);
            glm::mat3        NormalMatrix(0.0F);
            glm::vec3        Up(0.0F);
            const float      Determinant = glm::determinant(ModelLinear);
            if (std::isfinite(Determinant) && std::abs(Determinant) > GeometryEpsilon)
                NormalMatrix = glm::transpose(glm::inverse(ModelLinear));
            const float GravityLength = glm::length(Step.GravityWorld);
            if ((Step.SolverFlags & 1U) == 0U && std::isfinite(GravityLength) && GravityLength > GeometryEpsilon)
                Up = -Step.GravityWorld / GravityLength;

            for (std::size_t Column = 0; Column < 3; ++Column)
            {
                for (std::size_t Row = 0; Row < 3; ++Row)
                {
                    Constants.ModelLinearColumns[Column][Row] =
                        ModelLinear[static_cast<glm::length_t>(Column)][static_cast<glm::length_t>(Row)];
                    Constants.NormalMatrixAndUpColumns[Column][Row] =
                        NormalMatrix[static_cast<glm::length_t>(Column)][static_cast<glm::length_t>(Row)];
                }
                Constants.NormalMatrixAndUpColumns[Column][3] = Up[static_cast<glm::length_t>(Column)];
            }
            return Constants;
        }

        void RecordBufferBarriers(VkCommandBuffer CommandBuffer,
                                  VkPipelineStageFlags SourceStages,
                                  VkPipelineStageFlags DestinationStages,
                                  const std::vector<VkBufferMemoryBarrier>& Barriers)
        {
            if (Barriers.empty())
                return;
            vkCmdPipelineBarrier(CommandBuffer,
                                 SourceStages,
                                 DestinationStages,
                                 0,
                                 0,
                                 nullptr,
                                 static_cast<std::uint32_t>(Barriers.size()),
                                 Barriers.data(),
                                 0,
                                 nullptr);
        }
    } // namespace
#pragma endregion

#pragma region Solver_Lifecycle

    TSurfaceStateSolver::TSurfaceStateSolver(VkDevice Device, VkDescriptorSetLayout DescriptorSetLayout)
        : Device(Device)
    {
        if (Device == VK_NULL_HANDLE || DescriptorSetLayout == VK_NULL_HANDLE)
        {
            throw std::invalid_argument("Surface State solver requires a device and descriptor set layout.");
        }

        VkPushConstantRange PushConstants{};
        PushConstants.stageFlags = VK_SHADER_STAGE_COMPUTE_BIT;
        PushConstants.offset = 0;
        PushConstants.size = sizeof(TSurfaceSolverPushConstants);

        VkPipelineLayoutCreateInfo LayoutInfo{};
        LayoutInfo.sType = VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO;
        LayoutInfo.setLayoutCount = 1;
        LayoutInfo.pSetLayouts = &DescriptorSetLayout;
        LayoutInfo.pushConstantRangeCount = 1;
        LayoutInfo.pPushConstantRanges = &PushConstants;
        if (vkCreatePipelineLayout(Device, &LayoutInfo, nullptr, &PipelineLayout) != VK_SUCCESS)
        {
            throw std::runtime_error("Failed to create Surface State compute pipeline layout.");
        }

        try
        {
            const std::string ShaderRoot = MDSS_SHADER_DIR;
            AccumulationHeightPipeline = CreateComputePipeline(
                Device, PipelineLayout, (ShaderRoot + "/Simulation/SurfaceAccumulationHeight.comp.spv").c_str());
            SparseScheduleResetPipeline = CreateComputePipeline(
                Device,
                PipelineLayout,
                (ShaderRoot + "/Simulation/SurfaceSparseScheduleReset.comp.spv").c_str());
            AccumulationGeometryPipeline = CreateComputePipeline(
                Device,
                PipelineLayout,
                (ShaderRoot + "/Simulation/SurfaceDynamicGeometryUpdate.comp.spv").c_str());
            for (std::size_t Weight = 0; Weight < DynamicTransferWeightPipelines.size(); ++Weight)
                DynamicTransferWeightPipelines[Weight] = CreateComputePipeline(
                    Device, PipelineLayout,
                    (ShaderRoot + "/Simulation/SurfaceDynamicWeightsUpdate.comp.w" + std::to_string(Weight) + ".spv").c_str());
            for (std::size_t Raw = 0; Raw < 5; ++Raw)
                for (std::size_t Weight = 0; Weight < 2; ++Weight)
                {
                    const std::size_t Index = Raw * 2U + Weight;
                    const std::string Variant = ".comp.r" + std::to_string(Raw) + "w" + std::to_string(Weight) + ".spv";
                    Pass1Pipelines[Index] = CreateComputePipeline(
                        Device, PipelineLayout,
                        (ShaderRoot + "/Simulation/SurfaceSolver/SurfaceSolverPass1" + Variant).c_str());
                    Pass2Pipelines[Index] = CreateComputePipeline(
                        Device, PipelineLayout,
                        (ShaderRoot + "/Simulation/SurfaceSolver/SurfaceSolverPass2" + Variant).c_str());
                }
        }
        catch (...)
        {
            if (AccumulationHeightPipeline != VK_NULL_HANDLE)
                vkDestroyPipeline(Device, AccumulationHeightPipeline, nullptr);
            if (SparseScheduleResetPipeline != VK_NULL_HANDLE)
                vkDestroyPipeline(Device, SparseScheduleResetPipeline, nullptr);
            if (AccumulationGeometryPipeline != VK_NULL_HANDLE)
                vkDestroyPipeline(Device, AccumulationGeometryPipeline, nullptr);
            for (VkPipeline Pipeline : DynamicTransferWeightPipelines)
                if (Pipeline != VK_NULL_HANDLE) vkDestroyPipeline(Device, Pipeline, nullptr);
            for (VkPipeline Pipeline : Pass1Pipelines)
                if (Pipeline != VK_NULL_HANDLE) vkDestroyPipeline(Device, Pipeline, nullptr);
            for (VkPipeline Pipeline : Pass2Pipelines)
                if (Pipeline != VK_NULL_HANDLE) vkDestroyPipeline(Device, Pipeline, nullptr);
            vkDestroyPipelineLayout(Device, PipelineLayout, nullptr);
            PipelineLayout = VK_NULL_HANDLE;
            throw;
        }
    }

    TSurfaceStateSolver::~TSurfaceStateSolver()
    {
        if (AccumulationHeightPipeline != VK_NULL_HANDLE)
            vkDestroyPipeline(Device, AccumulationHeightPipeline, nullptr);
        if (SparseScheduleResetPipeline != VK_NULL_HANDLE)
            vkDestroyPipeline(Device, SparseScheduleResetPipeline, nullptr);
        if (AccumulationGeometryPipeline != VK_NULL_HANDLE)
            vkDestroyPipeline(Device, AccumulationGeometryPipeline, nullptr);
        for (VkPipeline Pipeline : DynamicTransferWeightPipelines)
            if (Pipeline != VK_NULL_HANDLE) vkDestroyPipeline(Device, Pipeline, nullptr);
        for (VkPipeline Pipeline : Pass1Pipelines)
            if (Pipeline != VK_NULL_HANDLE) vkDestroyPipeline(Device, Pipeline, nullptr);
        for (VkPipeline Pipeline : Pass2Pipelines)
            if (Pipeline != VK_NULL_HANDLE) vkDestroyPipeline(Device, Pipeline, nullptr);
        if (PipelineLayout != VK_NULL_HANDLE)
        {
            vkDestroyPipelineLayout(Device, PipelineLayout, nullptr);
        }
    }
#pragma endregion

#pragma region Solver_Command_Recording

    void TSurfaceStateSolver::RecordStep(VkCommandBuffer                         CommandBuffer,
                                         const TSurfaceStateDescriptorResources& Descriptors,
                                         bool                                    bCurrentStateAB,
                                         std::size_t                             TexelCount,
                                         std::size_t                             ChannelCount,
                                         float                                   DeltaTime,
                                         const glm::mat4&                        ModelMatrix,
                                         const glm::vec3&                        GravityWorld,
                                         std::uint32_t                           SolverFlags,
                                         VkQueryPool                             TimestampQueryPool,
                                         std::uint32_t                           FirstPassQuery,
                                         bool                                    bPrepareAccumulationHeight) const
    {
        const TSurfaceSolverInstanceStep Step{
            &Descriptors,
            bCurrentStateAB,
            TexelCount,
            ChannelCount,
            DeltaTime,
            ModelMatrix,
            GravityWorld,
            SolverFlags,
            bPrepareAccumulationHeight,
            false};
        RecordSteps(CommandBuffer,
                    std::span<const TSurfaceSolverInstanceStep>(&Step, 1U),
                    TimestampQueryPool,
                    FirstPassQuery);
    }

    void TSurfaceStateSolver::RecordSteps(VkCommandBuffer CommandBuffer,
                                          std::span<const TSurfaceSolverInstanceStep> InstanceSteps,
                                          VkQueryPool   TimestampQueryPool,
                                          std::uint32_t FirstStepQuery) const
    {
        if (CommandBuffer == VK_NULL_HANDLE)
            throw std::invalid_argument("Surface State solver requires a command buffer.");
        if (InstanceSteps.empty())
            return;

        struct TPreparedStep
        {
            const TSurfaceSolverInstanceStep* Step = nullptr;
            VkDescriptorSet                   CurrentDescriptorSet = VK_NULL_HANDLE;
            VkDescriptorSet                   NextDescriptorSet = VK_NULL_HANDLE;
            TSurfaceSolverPushConstants       Constants{};
            TSurfaceSolverPushConstants       PostConstants{};
            TSurfaceSolverPushConstants       PrebuildConstants{};
            std::uint32_t                     WorkgroupCount = 0U;
            VkBuffer                          HeightBuffer = VK_NULL_HANDLE;
            VkDeviceSize                      SolverIndirectOffset = 0U;
            VkDeviceSize                      AccumulationIndirectOffset = 0U;
            VkDeviceSize                      GeometryIndirectOffset = 0U;
            bool                              bUpdateGeometry = false;
            bool                              bPrepareAccumulationHeight = true;
            bool                              bNeedsPreSolverGeometryBuild = false;
            bool                              bNeedsSparseReset = false;
        };

        std::vector<TPreparedStep> Prepared;
        Prepared.reserve(InstanceSteps.size());
        for (const TSurfaceSolverInstanceStep& Step : InstanceSteps)
        {
            if (Step.Descriptors == nullptr || Step.TexelCount == 0 || Step.ChannelCount == 0 ||
                Step.TexelCount > std::numeric_limits<std::uint32_t>::max() ||
                Step.ChannelCount > std::numeric_limits<std::uint32_t>::max() || !std::isfinite(Step.DeltaTime) ||
                Step.DeltaTime < 0.0F)
                throw std::invalid_argument("Surface State solver step received invalid dimensions or DeltaTime.");
            if (Step.TexelCount > static_cast<std::size_t>(65535U) * 64U)
                throw std::length_error("Surface State solver dispatch exceeds Vulkan's minimum X workgroup limit.");

            TPreparedStep Item;
            Item.Step = &Step;
            Item.CurrentDescriptorSet = Step.bCurrentStateAB ? Step.Descriptors->GetABSet() : Step.Descriptors->GetBASet();
            Item.NextDescriptorSet = Step.bCurrentStateAB ? Step.Descriptors->GetBASet() : Step.Descriptors->GetABSet();
            Item.WorkgroupCount = static_cast<std::uint32_t>((Step.TexelCount + 63U) / 64U);
            Item.HeightBuffer = Step.Descriptors->GetBoundBufferHandle(
                TSurfaceGPUDescriptorBinding::AccumulationHeights, Step.bCurrentStateAB);

            const TSurfaceSparseMetadataLayout SparseLayout = GetSurfaceSparseMetadataLayout(Step.TexelCount);
            const std::size_t SolverCommandWord = Step.bCurrentStateAB
                                                      ? SparseLayout.SolverACommandWord
                                                      : SparseLayout.SolverBCommandWord;
            Item.SolverIndirectOffset = static_cast<VkDeviceSize>(SolverCommandWord * sizeof(std::uint32_t));
            Item.AccumulationIndirectOffset =
                static_cast<VkDeviceSize>(SparseLayout.AccumulationCommandWord * sizeof(std::uint32_t));
            Item.GeometryIndirectOffset =
                static_cast<VkDeviceSize>(SparseLayout.GeometryCommandWord * sizeof(std::uint32_t));

            Item.bUpdateGeometry = (Step.SolverFlags & SurfaceSolverStateDrivenGeometryUpdateFlag) != 0U;
            Item.bPrepareAccumulationHeight = Step.bPrepareAccumulationHeight || Item.bUpdateGeometry;
            Item.bNeedsPreSolverGeometryBuild =
                Item.bUpdateGeometry && (Step.SolverFlags & SurfaceSolverForceFullGeometryFlag) != 0U;

            Item.Constants = MakePushConstants(Step);
            if (Step.bCurrentStateAB)
                Item.Constants.Flags |= SurfaceSolverCurrentStateABFlag;
            else
                Item.Constants.Flags &= ~SurfaceSolverCurrentStateABFlag;
            if (Item.bPrepareAccumulationHeight)
                Item.Constants.Flags |= SurfaceSolverPrepareAccumulationHeightFlag;
            else
                Item.Constants.Flags &= ~SurfaceSolverPrepareAccumulationHeightFlag;

            Item.PostConstants = Item.Constants;
            // A force-full prebuild makes CurrentState geometry valid before Pass1. The newly-produced state can
            // then use normal sparse dirty propagation. If no prebuild happened (state-driven updates OFF), keep ForceFull
            // so the final render-height pass refreshes every texel without cache/revision bookkeeping.
            if (Item.bNeedsPreSolverGeometryBuild)
                Item.PostConstants.Flags &= ~SurfaceSolverForceFullGeometryFlag;

            Item.PrebuildConstants = Item.Constants;
            Item.PrebuildConstants.Flags &= ~(SurfaceSolverSparseGeometryFlag |
                                               SurfaceSolverSparseAccumulationHeightFlag |
                                               SurfaceSolverSparseSolverFlag);

            const bool bSparseSolver = (Item.Constants.Flags & SurfaceSolverSparseSolverFlag) != 0U;
            const bool bActiveChannelMask = (Item.Constants.Flags &
                (SurfaceSolverActiveChannelMaskFlag | SurfaceSolverPerWorkgroupChannelMaskFlag)) != 0U;
            const bool bSparseHeight = (Item.Constants.Flags & SurfaceSolverSparseAccumulationHeightFlag) != 0U;
            // One fused reset pass clears only the destination persistent set, Height/Geometry schedules,
            // and merges any CPU-known input groups into the current persistent set. No full-state scan remains.
            Item.bNeedsSparseReset = bSparseSolver || bActiveChannelMask || Item.bUpdateGeometry ||
                                     (Item.bPrepareAccumulationHeight && bSparseHeight) || Step.bHasInputActivation;
            Prepared.push_back(Item);
        }

        VkMemoryBarrier ReadCompletion{};
        ReadCompletion.sType = VK_STRUCTURE_TYPE_MEMORY_BARRIER;
        ReadCompletion.srcAccessMask =
            VK_ACCESS_SHADER_READ_BIT | VK_ACCESS_SHADER_WRITE_BIT | VK_ACCESS_INDIRECT_COMMAND_READ_BIT;
        ReadCompletion.dstAccessMask = VK_ACCESS_SHADER_READ_BIT | VK_ACCESS_SHADER_WRITE_BIT;
        vkCmdPipelineBarrier(CommandBuffer,
                             VK_PIPELINE_STAGE_VERTEX_SHADER_BIT | VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT |
                                 VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT | VK_PIPELINE_STAGE_DRAW_INDIRECT_BIT,
                             VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
                             0,
                             1,
                             &ReadCompletion,
                             0,
                             nullptr,
                             0,
                             nullptr);

        const auto BindStep = [&](VkDescriptorSet DescriptorSet,
                                  const TSurfaceSolverPushConstants& Constants)
        {
            vkCmdBindDescriptorSets(CommandBuffer,
                                    VK_PIPELINE_BIND_POINT_COMPUTE,
                                    PipelineLayout,
                                    0,
                                    1,
                                    &DescriptorSet,
                                    0,
                                    nullptr);
            vkCmdPushConstants(CommandBuffer,
                               PipelineLayout,
                               VK_SHADER_STAGE_COMPUTE_BIT,
                               0,
                               sizeof(Constants),
                               &Constants);
        };
        const auto WriteTimestamp = [&](std::uint32_t Offset)
        {
            if (TimestampQueryPool != VK_NULL_HANDLE)
                vkCmdWriteTimestamp(CommandBuffer,
                                    VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
                                    TimestampQueryPool,
                                    FirstStepQuery + Offset);
        };
        const auto AppendGeometryBarriers = [&](std::vector<VkBufferMemoryBarrier>& Barriers,
                                                const TPreparedStep&                Item)
        {
            const auto& Descriptors = *Item.Step->Descriptors;
            const bool CurrentAB = Item.Step->bCurrentStateAB;
            Barriers.push_back(MakeComputeBufferBarrier(
                Descriptors.GetBoundBufferHandle(TSurfaceGPUDescriptorBinding::DynamicGeometry, CurrentAB),
                VK_ACCESS_SHADER_READ_BIT));
            Barriers.push_back(MakeComputeBufferBarrier(Item.HeightBuffer, VK_ACCESS_SHADER_READ_BIT));
        };

        // Lifecycle bootstrap only: build CurrentState-derived data once before the solver when a reset,
        // profile edit or transform change invalidated it. This path deliberately bypasses sparse lists.
        const bool bAnyPreSolverBuild = std::any_of(Prepared.begin(), Prepared.end(), [](const TPreparedStep& Item)
        {
            return Item.bNeedsPreSolverGeometryBuild;
        });
        if (bAnyPreSolverBuild)
        {
            std::vector<VkBufferMemoryBarrier> Barriers;
            Barriers.reserve(Prepared.size() * 2U);

            vkCmdBindPipeline(CommandBuffer, VK_PIPELINE_BIND_POINT_COMPUTE, AccumulationHeightPipeline);
            for (const TPreparedStep& Item : Prepared)
            {
                if (!Item.bNeedsPreSolverGeometryBuild) continue;
                BindStep(Item.CurrentDescriptorSet, Item.PrebuildConstants);
                vkCmdDispatch(CommandBuffer, Item.WorkgroupCount, 1, 1);
                Barriers.push_back(MakeComputeBufferBarrier(Item.HeightBuffer, VK_ACCESS_SHADER_READ_BIT));
            }
            RecordBufferBarriers(CommandBuffer,
                                 VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
                                 VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
                                 Barriers);

            Barriers.clear();
            vkCmdBindPipeline(CommandBuffer, VK_PIPELINE_BIND_POINT_COMPUTE, AccumulationGeometryPipeline);
            for (const TPreparedStep& Item : Prepared)
            {
                if (!Item.bNeedsPreSolverGeometryBuild) continue;
                BindStep(Item.CurrentDescriptorSet, Item.PrebuildConstants);
                vkCmdDispatch(CommandBuffer, Item.WorkgroupCount, 1, 1);
                AppendGeometryBarriers(Barriers, Item);
            }
            RecordBufferBarriers(CommandBuffer,
                                 VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
                                 VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
                                 Barriers);

            Barriers.clear();
            for (const TPreparedStep& Item : Prepared)
            {
                if (!Item.bNeedsPreSolverGeometryBuild) continue;
                vkCmdBindPipeline(CommandBuffer, VK_PIPELINE_BIND_POINT_COMPUTE,
                                  DynamicTransferWeightPipelines[WeightModeFromFlags(Item.PrebuildConstants.Flags)]);
                BindStep(Item.CurrentDescriptorSet, Item.PrebuildConstants);
                vkCmdDispatch(CommandBuffer, Item.WorkgroupCount, 1, 1);
                const auto& Descriptors = *Item.Step->Descriptors;
                const bool CurrentAB = Item.Step->bCurrentStateAB;
                Barriers.push_back(MakeComputeBufferBarrier(
                    Descriptors.GetBoundBufferHandle(TSurfaceGPUDescriptorBinding::TransferWeights, CurrentAB),
                    VK_ACCESS_SHADER_READ_BIT));
                Barriers.push_back(MakeComputeBufferBarrier(
                    Descriptors.GetBoundBufferHandle(TSurfaceGPUDescriptorBinding::DynamicConcavityWeights, CurrentAB),
                    VK_ACCESS_SHADER_READ_BIT));
            }
            RecordBufferBarriers(CommandBuffer,
                                 VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
                                 VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
                                 Barriers);
        }

        // Pass1 timing includes the fused sparse reset/input-merge setup so A/B numbers include real overhead.
        WriteTimestamp(4U);

        const bool bAnySparseReset = std::any_of(Prepared.begin(), Prepared.end(), [](const TPreparedStep& Item)
        {
            return Item.bNeedsSparseReset;
        });
        if (bAnySparseReset)
        {
            std::vector<VkBufferMemoryBarrier> ResetBarriers;
            ResetBarriers.reserve(Prepared.size());
            vkCmdBindPipeline(CommandBuffer, VK_PIPELINE_BIND_POINT_COMPUTE, SparseScheduleResetPipeline);
            for (const TPreparedStep& Item : Prepared)
            {
                if (!Item.bNeedsSparseReset) continue;
                BindStep(Item.CurrentDescriptorSet, Item.Constants);
                vkCmdDispatch(CommandBuffer, 1, 1, 1);
                ResetBarriers.push_back(MakeComputeBufferBarrier(
                    Item.HeightBuffer,
                    VK_ACCESS_SHADER_READ_BIT | VK_ACCESS_SHADER_WRITE_BIT | VK_ACCESS_INDIRECT_COMMAND_READ_BIT));
            }
            RecordBufferBarriers(CommandBuffer,
                                 VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
                                 VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT | VK_PIPELINE_STAGE_DRAW_INDIRECT_BIT,
                                 ResetBarriers);
        }

        std::vector<VkBufferMemoryBarrier> PassBarriers;
        PassBarriers.reserve(Prepared.size() * 2U);
        for (const TPreparedStep& Item : Prepared)
        {
            const std::size_t Variant = RawModeFromFlags(Item.Constants.Flags) * 2U +
                                        WeightModeFromFlags(Item.Constants.Flags);
            vkCmdBindPipeline(CommandBuffer, VK_PIPELINE_BIND_POINT_COMPUTE, Pass1Pipelines[Variant]);
            BindStep(Item.CurrentDescriptorSet, Item.Constants);
            const bool bSparseDispatch = (Item.Constants.Flags & SurfaceSolverSparseSolverFlag) != 0U &&
                                         (Item.Constants.Flags & SurfaceSolverSeedPersistentActivityFlag) == 0U;
            if (bSparseDispatch)
                vkCmdDispatchIndirect(CommandBuffer, Item.HeightBuffer, Item.SolverIndirectOffset);
            else
                vkCmdDispatch(CommandBuffer, Item.WorkgroupCount, 1, 1);
            const auto& Descriptors = *Item.Step->Descriptors;
            const bool CurrentAB = Item.Step->bCurrentStateAB;
            PassBarriers.push_back(MakeComputeBufferBarrier(
                Descriptors.GetBoundBufferHandle(TSurfaceGPUDescriptorBinding::OutgoingFluxScale, CurrentAB),
                VK_ACCESS_SHADER_READ_BIT));
            PassBarriers.push_back(MakeComputeBufferBarrier(
                Descriptors.GetBoundBufferHandle(TSurfaceGPUDescriptorBinding::RawOutgoing, CurrentAB),
                VK_ACCESS_SHADER_READ_BIT));
        }
        WriteTimestamp(5U);
        RecordBufferBarriers(CommandBuffer,
                             VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
                             VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
                             PassBarriers);

        WriteTimestamp(6U);
        PassBarriers.clear();
        PassBarriers.reserve(Prepared.size() * 5U);
        for (const TPreparedStep& Item : Prepared)
        {
            const std::size_t Variant = RawModeFromFlags(Item.Constants.Flags) * 2U +
                                        WeightModeFromFlags(Item.Constants.Flags);
            vkCmdBindPipeline(CommandBuffer, VK_PIPELINE_BIND_POINT_COMPUTE, Pass2Pipelines[Variant]);
            BindStep(Item.CurrentDescriptorSet, Item.Constants);
            const bool bSparseDispatch = (Item.Constants.Flags & SurfaceSolverSparseSolverFlag) != 0U &&
                                         (Item.Constants.Flags & SurfaceSolverSeedPersistentActivityFlag) == 0U;
            if (bSparseDispatch)
                vkCmdDispatchIndirect(CommandBuffer, Item.HeightBuffer, Item.SolverIndirectOffset);
            else
                vkCmdDispatch(CommandBuffer, Item.WorkgroupCount, 1, 1);
            const auto& Descriptors = *Item.Step->Descriptors;
            const bool CurrentAB = Item.Step->bCurrentStateAB;
            PassBarriers.push_back(MakeComputeBufferBarrier(
                Descriptors.GetBoundBufferHandle(TSurfaceGPUDescriptorBinding::NextState, CurrentAB),
                VK_ACCESS_SHADER_READ_BIT));
            PassBarriers.push_back(MakeComputeBufferBarrier(
                Descriptors.GetBoundBufferHandle(TSurfaceGPUDescriptorBinding::InputDelta, CurrentAB),
                VK_ACCESS_SHADER_READ_BIT | VK_ACCESS_SHADER_WRITE_BIT,
                VK_ACCESS_SHADER_READ_BIT | VK_ACCESS_SHADER_WRITE_BIT));
            PassBarriers.push_back(MakeComputeBufferBarrier(
                Descriptors.GetBoundBufferHandle(TSurfaceGPUDescriptorBinding::RawOutgoing, CurrentAB),
                VK_ACCESS_SHADER_WRITE_BIT,
                VK_ACCESS_SHADER_READ_BIT));
            PassBarriers.push_back(MakeComputeBufferBarrier(
                Descriptors.GetBoundBufferHandle(TSurfaceGPUDescriptorBinding::OutgoingFluxScale, CurrentAB),
                VK_ACCESS_SHADER_WRITE_BIT,
                VK_ACCESS_SHADER_READ_BIT));
            const bool bPersistentActivity =
                (Item.Constants.Flags & (SurfaceSolverSparseSolverFlag | SurfaceSolverActiveChannelMaskFlag)) != 0U;
            if (bPersistentActivity ||
                (Item.bPrepareAccumulationHeight &&
                 (Item.Constants.Flags & SurfaceSolverSparseAccumulationHeightFlag) != 0U))
            {
                PassBarriers.push_back(MakeComputeBufferBarrier(
                    Item.HeightBuffer,
                    VK_ACCESS_INDIRECT_COMMAND_READ_BIT | VK_ACCESS_SHADER_READ_BIT | VK_ACCESS_SHADER_WRITE_BIT));
            }
        }
        WriteTimestamp(7U);
        RecordBufferBarriers(CommandBuffer,
                             VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
                             VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT | VK_PIPELINE_STAGE_DRAW_INDIRECT_BIT |
                                 VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT | VK_PIPELINE_STAGE_VERTEX_SHADER_BIT,
                             PassBarriers);

        // Derive the just-produced state. Renderer and the next fixed substep consume these authoritative buffers.
        WriteTimestamp(0U);
        std::vector<VkBufferMemoryBarrier> DerivedBarriers;
        DerivedBarriers.reserve(Prepared.size() * 2U);
        const bool bAnyPostHeight = std::any_of(Prepared.begin(), Prepared.end(), [](const TPreparedStep& Item)
        {
            return Item.bPrepareAccumulationHeight;
        });
        if (bAnyPostHeight)
        {
            vkCmdBindPipeline(CommandBuffer, VK_PIPELINE_BIND_POINT_COMPUTE, AccumulationHeightPipeline);
            for (const TPreparedStep& Item : Prepared)
            {
                if (!Item.bPrepareAccumulationHeight) continue;
                BindStep(Item.NextDescriptorSet, Item.PostConstants);
                const bool bForceFull =
                    (Item.PostConstants.Flags & SurfaceSolverForceFullGeometryFlag) != 0U;
                const bool bSparseHeight =
                    (Item.PostConstants.Flags & SurfaceSolverSparseAccumulationHeightFlag) != 0U;
                if (bSparseHeight && !bForceFull)
                    vkCmdDispatchIndirect(CommandBuffer, Item.HeightBuffer, Item.AccumulationIndirectOffset);
                else
                    vkCmdDispatch(CommandBuffer, Item.WorkgroupCount, 1, 1);
                DerivedBarriers.push_back(MakeComputeBufferBarrier(
                    Item.HeightBuffer,
                    VK_ACCESS_SHADER_READ_BIT | VK_ACCESS_SHADER_WRITE_BIT | VK_ACCESS_INDIRECT_COMMAND_READ_BIT));
            }
            RecordBufferBarriers(CommandBuffer,
                                 VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
                                 VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT | VK_PIPELINE_STAGE_DRAW_INDIRECT_BIT,
                                 DerivedBarriers);
        }

        const bool bAnyGeometryUpdate = std::any_of(Prepared.begin(), Prepared.end(), [](const TPreparedStep& Item)
        {
            return Item.bUpdateGeometry;
        });
        if (bAnyGeometryUpdate)
        {
            DerivedBarriers.clear();
            vkCmdBindPipeline(CommandBuffer, VK_PIPELINE_BIND_POINT_COMPUTE, AccumulationGeometryPipeline);
            for (const TPreparedStep& Item : Prepared)
            {
                if (!Item.bUpdateGeometry) continue;
                BindStep(Item.NextDescriptorSet, Item.PostConstants);
                vkCmdDispatchIndirect(CommandBuffer, Item.HeightBuffer, Item.GeometryIndirectOffset);
                AppendGeometryBarriers(DerivedBarriers, Item);
            }
            RecordBufferBarriers(CommandBuffer,
                                 VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
                                 VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT | VK_PIPELINE_STAGE_VERTEX_SHADER_BIT |
                                     VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT,
                                 DerivedBarriers);
        }
        WriteTimestamp(1U);

        WriteTimestamp(2U);
        if (bAnyGeometryUpdate)
        {
            DerivedBarriers.clear();
            for (const TPreparedStep& Item : Prepared)
            {
                if (!Item.bUpdateGeometry) continue;
                vkCmdBindPipeline(CommandBuffer, VK_PIPELINE_BIND_POINT_COMPUTE,
                                  DynamicTransferWeightPipelines[WeightModeFromFlags(Item.PostConstants.Flags)]);
                BindStep(Item.NextDescriptorSet, Item.PostConstants);
                vkCmdDispatchIndirect(CommandBuffer, Item.HeightBuffer, Item.GeometryIndirectOffset);
                const auto& Descriptors = *Item.Step->Descriptors;
                const bool NextAB = !Item.Step->bCurrentStateAB;
                DerivedBarriers.push_back(MakeComputeBufferBarrier(
                    Descriptors.GetBoundBufferHandle(TSurfaceGPUDescriptorBinding::TransferWeights, NextAB),
                    VK_ACCESS_SHADER_READ_BIT));
                DerivedBarriers.push_back(MakeComputeBufferBarrier(
                    Descriptors.GetBoundBufferHandle(TSurfaceGPUDescriptorBinding::DynamicConcavityWeights, NextAB),
                    VK_ACCESS_SHADER_READ_BIT));
            }
            RecordBufferBarriers(CommandBuffer,
                                 VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
                                 VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT | VK_PIPELINE_STAGE_VERTEX_SHADER_BIT |
                                     VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT,
                                 DerivedBarriers);
        }
        WriteTimestamp(3U);

        if (bAnyPostHeight || bAnyGeometryUpdate)
        {
            VkMemoryBarrier DerivedReady{};
            DerivedReady.sType = VK_STRUCTURE_TYPE_MEMORY_BARRIER;
            DerivedReady.srcAccessMask = VK_ACCESS_SHADER_WRITE_BIT;
            DerivedReady.dstAccessMask = VK_ACCESS_SHADER_READ_BIT | VK_ACCESS_INDIRECT_COMMAND_READ_BIT;
            vkCmdPipelineBarrier(CommandBuffer,
                                 VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
                                 VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT | VK_PIPELINE_STAGE_VERTEX_SHADER_BIT |
                                     VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT | VK_PIPELINE_STAGE_DRAW_INDIRECT_BIT,
                                 0,
                                 1,
                                 &DerivedReady,
                                 0,
                                 nullptr,
                                 0,
                                 nullptr);
        }
    }

#pragma endregion

#pragma region Compute_Pipeline_Creation

    VkShaderModule TSurfaceStateSolver::CreateShaderModule(VkDevice Device, const char* Path)
    {
        const std::vector<std::uint32_t> Code = ReadSpirvFile(Path);
        VkShaderModuleCreateInfo         CreateInfo{};
        CreateInfo.sType = VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO;
        CreateInfo.codeSize = Code.size() * sizeof(std::uint32_t);
        CreateInfo.pCode = Code.data();

        VkShaderModule Module = VK_NULL_HANDLE;
        if (vkCreateShaderModule(Device, &CreateInfo, nullptr, &Module) != VK_SUCCESS)
        {
            throw std::runtime_error(std::string("Failed to create compute shader module: ") + Path);
        }
        return Module;
    }

    VkPipeline TSurfaceStateSolver::CreateComputePipeline(VkDevice         Device,
                                                          VkPipelineLayout Layout,
                                                          const char*      ShaderPath)
    {
        const VkShaderModule            Module = CreateShaderModule(Device, ShaderPath);
        VkPipelineShaderStageCreateInfo Stage{};
        Stage.sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;
        Stage.stage = VK_SHADER_STAGE_COMPUTE_BIT;
        Stage.module = Module;
        Stage.pName = "main";
        VkComputePipelineCreateInfo PipelineInfo{};
        PipelineInfo.sType = VK_STRUCTURE_TYPE_COMPUTE_PIPELINE_CREATE_INFO;
        PipelineInfo.stage = Stage;
        PipelineInfo.layout = Layout;

        VkPipeline     Pipeline = VK_NULL_HANDLE;
        const VkResult Result = vkCreateComputePipelines(Device, VK_NULL_HANDLE, 1, &PipelineInfo, nullptr, &Pipeline);
        vkDestroyShaderModule(Device, Module, nullptr);
        if (Result != VK_SUCCESS)
        {
            if (Pipeline != VK_NULL_HANDLE)
                vkDestroyPipeline(Device, Pipeline, nullptr);
            throw std::runtime_error(std::string("Failed to create Surface State compute pipeline: ") + ShaderPath);
        }
        return Pipeline;
    }
#pragma endregion
} // namespace MDSS::SurfaceState
