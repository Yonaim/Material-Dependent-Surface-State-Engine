/**
 * @file Window.cpp
 * @brief GLFW 창의 수명 주기와 framebuffer 변경 이벤트.
 */

#include "Application/Window.h"

#include "Logger/Logger.h"

#define GLFW_INCLUDE_NONE
#include <GLFW/glfw3.h>

#include <algorithm>
#include <cstdint>
#include <mutex>
#include <stdexcept>

namespace MDSS
{
    namespace
    {
        std::mutex    GLFWMutex;
        std::uint32_t WindowCount = 0;
    } // namespace

#pragma region Window_Lifecycle

    TWindow::TWindow(std::uint32_t Width, std::uint32_t Height, std::string Title)
    {
        InitializeGLFW();

        glfwWindowHint(GLFW_CLIENT_API, GLFW_NO_API);
        glfwWindowHint(GLFW_RESIZABLE, GLFW_TRUE);

        Handle = glfwCreateWindow(static_cast<int>(Width), static_cast<int>(Height), Title.c_str(), nullptr, nullptr);

        if (Handle == nullptr)
        {
            TerminateGLFW();
            throw std::runtime_error("Failed to create GLFW window.");
        }

        glfwSetWindowUserPointer(Handle, this);
        glfwSetFramebufferSizeCallback(Handle, FramebufferSizeCallback);

        TLogger::Info("TApplication",
                      "GLFW window created: " + std::to_string(Width) + "x" + std::to_string(Height) + ".");
    }

    TWindow::~TWindow()
    {
        if (Handle != nullptr)
        {
            glfwDestroyWindow(Handle);
            Handle = nullptr;
        }

        TerminateGLFW();
    }

#pragma endregion

#pragma region Window_State_and_Events

    bool TWindow::ShouldClose() const
    {
        return glfwWindowShouldClose(Handle) == GLFW_TRUE;
    }

    void TWindow::PollEvents() const
    {
        glfwPollEvents();
    }

    GLFWwindow* TWindow::GetNativeHandle() const noexcept
    {
        return Handle;
    }

    bool TWindow::WasFramebufferResized() const noexcept
    {
        return bFramebufferResized;
    }

    void TWindow::ResetFramebufferResized() noexcept
    {
        bFramebufferResized = false;
    }

    void TWindow::GetFramebufferSize(std::uint32_t& Width, std::uint32_t& Height) const noexcept
    {
        int FramebufferWidth = 0;
        int FramebufferHeight = 0;
        glfwGetFramebufferSize(Handle, &FramebufferWidth, &FramebufferHeight);

        Width = static_cast<std::uint32_t>(std::max(FramebufferWidth, 0));
        Height = static_cast<std::uint32_t>(std::max(FramebufferHeight, 0));
    }

    void TWindow::WaitForNonZeroFramebuffer() const
    {
        std::uint32_t Width = 0;
        std::uint32_t Height = 0;
        GetFramebufferSize(Width, Height);

        while ((Width == 0 || Height == 0) && !ShouldClose())
        {
            glfwWaitEvents();
            GetFramebufferSize(Width, Height);
        }
    }

    void TWindow::FramebufferSizeCallback(GLFWwindow* WindowHandle, int Width, int Height)
    {
        auto* WindowInstance = static_cast<TWindow*>(glfwGetWindowUserPointer(WindowHandle));
        if (WindowInstance == nullptr)
        {
            return;
        }

        WindowInstance->bFramebufferResized = true;
        TLogger::Debug("TApplication",
                       "TFramebuffer resize requested: " + std::to_string(std::max(Width, 0)) + "x" +
                           std::to_string(std::max(Height, 0)) + ".");
    }

#pragma endregion

#pragma region GLFW_Lifecycle

    void TWindow::InitializeGLFW()
    {
        std::scoped_lock Lock(GLFWMutex);

        if (WindowCount == 0)
        {
            if (glfwInit() != GLFW_TRUE)
            {
                throw std::runtime_error("Failed to initialize GLFW.");
            }
            TLogger::Debug("TApplication", "GLFW initialized.");
        }

        ++WindowCount;
    }

    void TWindow::TerminateGLFW()
    {
        std::scoped_lock Lock(GLFWMutex);

        if (WindowCount == 0)
        {
            return;
        }

        --WindowCount;

        if (WindowCount == 0)
        {
            glfwTerminate();
            TLogger::Verbose("TApplication", "GLFW terminated.");
        }
    }
#pragma endregion
} // namespace MDSS
