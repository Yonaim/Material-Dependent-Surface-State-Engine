/**
 * @file GPUImage.cpp
 * @brief Vulkan image와 device memory의 생성·재생성·해제.
 */

#include "GPU/Vulkan/Resource/GPUImage.h"
#include "GPU/Vulkan/Resource/GPUResourceMemoryStats.h"

#include "Logger/Logger.h"

#include <stdexcept>

namespace MDSS::GPU
{
#pragma region Image_Lifecycle_and_Creation

    TGPUImage::TGPUImage(VkPhysicalDevice      PhysicalDevice,
                         VkDevice              Device,
                         VkExtent2D            Extent,
                         VkFormat              Format,
                         VkImageTiling         Tiling,
                         VkImageUsageFlags     Usage,
                         VkMemoryPropertyFlags MemoryProperties,
                         std::uint32_t         ArrayLayers)
        : Device(Device)
    {
        Create(PhysicalDevice, Extent, Format, Tiling, Usage, MemoryProperties, ArrayLayers);
    }

    TGPUImage::~TGPUImage()
    {
        Reset();
    }

    void TGPUImage::Recreate(VkPhysicalDevice      PhysicalDevice,
                             VkExtent2D            NewExtent,
                             VkFormat              NewFormat,
                             VkImageTiling         Tiling,
                             VkImageUsageFlags     Usage,
                             VkMemoryPropertyFlags MemoryProperties,
                             std::uint32_t         ArrayLayers)
    {
        Reset();
        Create(PhysicalDevice, NewExtent, NewFormat, Tiling, Usage, MemoryProperties, ArrayLayers);
    }

    void TGPUImage::Reset()
    {
        if (Handle != VK_NULL_HANDLE)
        {
            vkDestroyImage(Device, Handle, nullptr);
            Handle = VK_NULL_HANDLE;
        }

        if (Memory != VK_NULL_HANDLE)
        {
            TGPUResourceMemoryStats::ImageFreed(AllocationSize);
            vkFreeMemory(Device, Memory, nullptr);
            Memory = VK_NULL_HANDLE;
        }

        AllocationSize = 0;
        Format = VK_FORMAT_UNDEFINED;
        Extent = {};
    }

    void TGPUImage::Create(VkPhysicalDevice      PhysicalDevice,
                           VkExtent2D            NewExtent,
                           VkFormat              NewFormat,
                           VkImageTiling         Tiling,
                           VkImageUsageFlags     Usage,
                           VkMemoryPropertyFlags MemoryProperties,
                           std::uint32_t         ArrayLayers)
    {
        if (NewExtent.width == 0 || NewExtent.height == 0 || ArrayLayers == 0)
        {
            throw std::invalid_argument("GPU image extent must be non-zero.");
        }

        Format = NewFormat;
        Extent = NewExtent;

        VkImageCreateInfo ImageInfo{};
        ImageInfo.sType = VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO;
        ImageInfo.imageType = VK_IMAGE_TYPE_2D;
        ImageInfo.extent.width = Extent.width;
        ImageInfo.extent.height = Extent.height;
        ImageInfo.extent.depth = 1;
        ImageInfo.mipLevels = 1;
        ImageInfo.arrayLayers = ArrayLayers;
        ImageInfo.format = Format;
        ImageInfo.tiling = Tiling;
        ImageInfo.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
        ImageInfo.usage = Usage;
        ImageInfo.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
        ImageInfo.samples = VK_SAMPLE_COUNT_1_BIT;

        if (vkCreateImage(Device, &ImageInfo, nullptr, &Handle) != VK_SUCCESS)
        {
            throw std::runtime_error("Failed to create Vulkan image.");
        }

        VkMemoryRequirements MemoryRequirements{};
        vkGetImageMemoryRequirements(Device, Handle, &MemoryRequirements);

        VkMemoryAllocateInfo AllocateInfo{};
        AllocateInfo.sType = VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO;
        AllocateInfo.allocationSize = MemoryRequirements.size;
        AllocationSize = MemoryRequirements.size;
        AllocateInfo.memoryTypeIndex =
            FindMemoryType(PhysicalDevice, MemoryRequirements.memoryTypeBits, MemoryProperties);

        if (vkAllocateMemory(Device, &AllocateInfo, nullptr, &Memory) != VK_SUCCESS)
        {
            vkDestroyImage(Device, Handle, nullptr);
            Handle = VK_NULL_HANDLE;
            AllocationSize = 0;
            throw std::runtime_error("Failed to allocate Vulkan image memory.");
        }

        if (vkBindImageMemory(Device, Handle, Memory, 0) != VK_SUCCESS)
        {
            vkFreeMemory(Device, Memory, nullptr);
            vkDestroyImage(Device, Handle, nullptr);
            Memory = VK_NULL_HANDLE;
            Handle = VK_NULL_HANDLE;
            AllocationSize = 0;
            throw std::runtime_error("Failed to bind Vulkan image memory.");
        }
        TGPUResourceMemoryStats::ImageAllocated(AllocationSize);

        TLogger::Verbose("Vulkan",
                         "TGPUImage created (" + std::to_string(Extent.width) + "x" + std::to_string(Extent.height) +
                             ", format=" + std::to_string(static_cast<int>(Format)) + ").");
    }

#pragma endregion

#pragma region Image_Accessors

    VkImage TGPUImage::GetHandle() const noexcept
    {
        return Handle;
    }

    VkFormat TGPUImage::GetFormat() const noexcept
    {
        return Format;
    }

    VkExtent2D TGPUImage::GetExtent() const noexcept
    {
        return Extent;
    }

#pragma endregion

#pragma region Memory_Type_Selection

    std::uint32_t TGPUImage::FindMemoryType(VkPhysicalDevice      PhysicalDevice,
                                            std::uint32_t         TypeFilter,
                                            VkMemoryPropertyFlags RequiredProperties)
    {
        VkPhysicalDeviceMemoryProperties Properties{};
        vkGetPhysicalDeviceMemoryProperties(PhysicalDevice, &Properties);

        for (std::uint32_t Index = 0; Index < Properties.memoryTypeCount; ++Index)
        {
            const bool bTypeSupported = (TypeFilter & (1U << Index)) != 0;
            const bool bPropertiesSupported =
                (Properties.memoryTypes[Index].propertyFlags & RequiredProperties) == RequiredProperties;

            if (bTypeSupported && bPropertiesSupported)
            {
                return Index;
            }
        }

        throw std::runtime_error("Failed to find a suitable Vulkan memory type for GPU image.");
    }
#pragma endregion
} // namespace MDSS::GPU
