/**
 * @file GPUBuffer.h
 * @brief Vulkan buffer와 device memory의 생성·갱신·해제.
 */

#pragma once

#include "GPU/Vulkan/Resource/GPUResourceMemoryStats.h"

#include <vulkan/vulkan.h>

#include <atomic>
#include <cstdint>

namespace MDSS::GPU
{
    class TGPUBuffer
    {
    public:
        // Buffer allocation and lifecycle
        /**
         * @brief 지정한 usage와 memory property로 Vulkan buffer와 memory를 생성한다.
         * @throws std::runtime_error buffer 또는 memory 생성에 실패한 경우.
         */
        TGPUBuffer(VkPhysicalDevice      PhysicalDevice,
                   VkDevice              Device,
                   VkDeviceSize          Size,
                   VkBufferUsageFlags    Usage,
                   VkMemoryPropertyFlags MemoryProperties,
                   TGPUBufferMemoryCategory Category = TGPUBufferMemoryCategory::Other);
        ~TGPUBuffer();

        TGPUBuffer(const TGPUBuffer&) = delete;
        TGPUBuffer& operator=(const TGPUBuffer&) = delete;
        TGPUBuffer(TGPUBuffer&&) = delete;
        TGPUBuffer& operator=(TGPUBuffer&&) = delete;

        /**
         * @brief host-visible buffer memory에 바이트 범위를 복사한다.
         * @param Data 복사할 데이터 주소.
         * @param DataSize 복사할 byte 수.
         * @param Offset buffer 시작점으로부터의 byte offset.
         * @throws std::runtime_error mapping 실패 시 발생한다.
         */
        // Buffer transfers
        void Upload(const void* Data, VkDeviceSize DataSize, VkDeviceSize Offset = 0) const;
        /** @brief host-visible/coherent buffer memory에서 바이트 범위를 읽는다. */
        void Download(void* Destination, VkDeviceSize DataSize, VkDeviceSize Offset = 0) const;

        // Buffer properties
        [[nodiscard]] VkBuffer      GetHandle() const noexcept;
        [[nodiscard]] VkDeviceSize  GetSize() const noexcept;
        [[nodiscard]] VkBufferUsageFlags GetUsage() const noexcept;
        [[nodiscard]] VkMemoryPropertyFlags GetMemoryProperties() const noexcept;
        [[nodiscard]] TGPUBufferMemoryCategory GetMemoryCategory() const noexcept;
        [[nodiscard]] std::uint64_t GetUploadRevision() const noexcept;

    private:
        static std::uint32_t FindMemoryType(VkPhysicalDevice      PhysicalDevice,
                                            std::uint32_t         TypeFilter,
                                            VkMemoryPropertyFlags RequiredProperties);

        VkDevice                           Device = VK_NULL_HANDLE;
        VkBuffer                           Handle = VK_NULL_HANDLE;
        VkDeviceMemory                     Memory = VK_NULL_HANDLE;
        VkDeviceSize                       Size = 0;
        VkDeviceSize                       AllocationSize = 0;
        VkBufferUsageFlags                 Usage = 0;
        TGPUBufferMemoryCategory           MemoryCategory = TGPUBufferMemoryCategory::Other;
        VkMemoryPropertyFlags              MemoryProperties = 0;
        mutable std::atomic<std::uint64_t> UploadRevision{0};
    };
} // namespace MDSS::GPU
