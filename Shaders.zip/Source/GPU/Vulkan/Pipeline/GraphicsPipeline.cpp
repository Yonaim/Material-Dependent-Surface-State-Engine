/**
 * @file GraphicsPipeline.cpp
 * @brief shader stage와 고정 기능 설정을 이용한 graphics pipeline 생성.
 */

#include "GPU/Vulkan/Pipeline/GraphicsPipeline.h"

#include "Logger/Logger.h"

#include <array>
#include <cstdint>
#include <fstream>
#include <stdexcept>
#include <string>
#include <vector>

namespace MDSS::GPU
{
    namespace
    {
        std::vector<std::uint32_t> ReadSpirvFile(const char* Path)
        {
            std::ifstream File(Path, std::ios::ate | std::ios::binary);
            if (!File.is_open())
            {
                throw std::runtime_error(std::string("Failed to open shader file: ") + Path);
            }

            const std::streamsize Size = File.tellg();
            if (Size <= 0 || (Size % static_cast<std::streamsize>(sizeof(std::uint32_t))) != 0)
            {
                throw std::runtime_error(std::string("Invalid SPIR-V file size: ") + Path);
            }

            std::vector<std::uint32_t> Data(static_cast<std::size_t>(Size) / sizeof(std::uint32_t));
            File.seekg(0);
            File.read(reinterpret_cast<char*>(Data.data()), Size);

            if (!File)
            {
                throw std::runtime_error(std::string("Failed to read shader file: ") + Path);
            }

            return Data;
        }
    } // namespace

#pragma region Pipeline_Lifecycle

    TGraphicsPipeline::TGraphicsPipeline(VkDevice                       Device,
                                         VkRenderPass                   TRenderPass,
                                         const TGraphicsPipelineConfig& Config)
        : Device(Device)
    {
        if (Config.ShaderStages.empty())
        {
            throw std::invalid_argument("Graphics pipeline requires at least one shader stage.");
        }

        std::vector<VkShaderModule>                  ShaderModules;
        std::vector<VkPipelineShaderStageCreateInfo> ShaderStageInfos;
        ShaderModules.reserve(Config.ShaderStages.size());
        ShaderStageInfos.reserve(Config.ShaderStages.size());

        try
        {
            for (const TShaderStageConfig& StageConfig : Config.ShaderStages)
            {
                if (StageConfig.ShaderPath.empty() || StageConfig.EntryPoint.empty())
                {
                    throw std::invalid_argument("Graphics pipeline shader stage path/entry point must not be empty.");
                }

                TLogger::Debug("TRenderer",
                               "Loading shader stage " + std::to_string(static_cast<int>(StageConfig.Stage)) + ": " +
                                   StageConfig.ShaderPath);
                const VkShaderModule Module = CreateShaderModule(Device, StageConfig.ShaderPath.c_str());
                ShaderModules.push_back(Module);

                VkPipelineShaderStageCreateInfo StageInfo{};
                StageInfo.sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;
                StageInfo.stage = StageConfig.Stage;
                StageInfo.module = Module;
                StageInfo.pName = StageConfig.EntryPoint.c_str();
                ShaderStageInfos.push_back(StageInfo);
            }

            VkPipelineVertexInputStateCreateInfo VertexInput{};
            VertexInput.sType = VK_STRUCTURE_TYPE_PIPELINE_VERTEX_INPUT_STATE_CREATE_INFO;
            VertexInput.vertexBindingDescriptionCount = static_cast<std::uint32_t>(Config.VertexBindings.size());
            VertexInput.pVertexBindingDescriptions =
                Config.VertexBindings.empty() ? nullptr : Config.VertexBindings.data();
            VertexInput.vertexAttributeDescriptionCount = static_cast<std::uint32_t>(Config.VertexAttributes.size());
            VertexInput.pVertexAttributeDescriptions =
                Config.VertexAttributes.empty() ? nullptr : Config.VertexAttributes.data();

            VkPipelineInputAssemblyStateCreateInfo InputAssembly{};
            InputAssembly.sType = VK_STRUCTURE_TYPE_PIPELINE_INPUT_ASSEMBLY_STATE_CREATE_INFO;
            InputAssembly.topology = Config.Topology;
            InputAssembly.primitiveRestartEnable = VK_FALSE;

            VkPipelineViewportStateCreateInfo ViewportState{};
            ViewportState.sType = VK_STRUCTURE_TYPE_PIPELINE_VIEWPORT_STATE_CREATE_INFO;
            ViewportState.viewportCount = 1;
            ViewportState.scissorCount = 1;

            VkPipelineRasterizationStateCreateInfo Rasterizer{};
            Rasterizer.sType = VK_STRUCTURE_TYPE_PIPELINE_RASTERIZATION_STATE_CREATE_INFO;
            Rasterizer.depthClampEnable = VK_FALSE;
            Rasterizer.rasterizerDiscardEnable = VK_FALSE;
            Rasterizer.polygonMode = Config.PolygonMode;
            Rasterizer.cullMode = Config.CullMode;
            Rasterizer.frontFace = Config.FrontFace;
            Rasterizer.depthBiasEnable = VK_FALSE;
            Rasterizer.lineWidth = 1.0F;

            VkPipelineMultisampleStateCreateInfo Multisampling{};
            Multisampling.sType = VK_STRUCTURE_TYPE_PIPELINE_MULTISAMPLE_STATE_CREATE_INFO;
            Multisampling.rasterizationSamples = Config.RasterizationSamples;
            Multisampling.sampleShadingEnable = VK_FALSE;

            VkPipelineDepthStencilStateCreateInfo DepthStencil{};
            DepthStencil.sType = VK_STRUCTURE_TYPE_PIPELINE_DEPTH_STENCIL_STATE_CREATE_INFO;
            DepthStencil.depthTestEnable = Config.bDepthTestEnabled ? VK_TRUE : VK_FALSE;
            DepthStencil.depthWriteEnable = Config.bDepthWriteEnabled ? VK_TRUE : VK_FALSE;
            DepthStencil.depthCompareOp = Config.DepthCompareOp;
            DepthStencil.depthBoundsTestEnable = VK_FALSE;
            DepthStencil.stencilTestEnable = VK_FALSE;

            VkPipelineColorBlendAttachmentState ColorBlendAttachment{};
            ColorBlendAttachment.colorWriteMask = VK_COLOR_COMPONENT_R_BIT | VK_COLOR_COMPONENT_G_BIT |
                                                  VK_COLOR_COMPONENT_B_BIT | VK_COLOR_COMPONENT_A_BIT;
            ColorBlendAttachment.blendEnable = Config.bBlendingEnabled ? VK_TRUE : VK_FALSE;
            ColorBlendAttachment.srcColorBlendFactor = VK_BLEND_FACTOR_SRC_ALPHA;
            ColorBlendAttachment.dstColorBlendFactor = VK_BLEND_FACTOR_ONE_MINUS_SRC_ALPHA;
            ColorBlendAttachment.colorBlendOp = VK_BLEND_OP_ADD;
            ColorBlendAttachment.srcAlphaBlendFactor = VK_BLEND_FACTOR_ONE;
            ColorBlendAttachment.dstAlphaBlendFactor = VK_BLEND_FACTOR_ZERO;
            ColorBlendAttachment.alphaBlendOp = VK_BLEND_OP_ADD;

            VkPipelineColorBlendStateCreateInfo ColorBlending{};
            ColorBlending.sType = VK_STRUCTURE_TYPE_PIPELINE_COLOR_BLEND_STATE_CREATE_INFO;
            ColorBlending.logicOpEnable = VK_FALSE;
            ColorBlending.attachmentCount = 1;
            ColorBlending.pAttachments = &ColorBlendAttachment;

            std::vector<VkDynamicState> DynamicStates = {VK_DYNAMIC_STATE_VIEWPORT, VK_DYNAMIC_STATE_SCISSOR};
            if (Config.bDynamicLineWidth)
            {
                DynamicStates.push_back(VK_DYNAMIC_STATE_LINE_WIDTH);
            }
            VkPipelineDynamicStateCreateInfo DynamicState{};
            DynamicState.sType = VK_STRUCTURE_TYPE_PIPELINE_DYNAMIC_STATE_CREATE_INFO;
            DynamicState.dynamicStateCount = static_cast<std::uint32_t>(DynamicStates.size());
            DynamicState.pDynamicStates = DynamicStates.data();

            VkPipelineLayoutCreateInfo LayoutInfo{};
            LayoutInfo.sType = VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO;
            LayoutInfo.setLayoutCount = static_cast<std::uint32_t>(Config.DescriptorSetLayouts.size());
            LayoutInfo.pSetLayouts = Config.DescriptorSetLayouts.empty() ? nullptr : Config.DescriptorSetLayouts.data();
            LayoutInfo.pushConstantRangeCount = static_cast<std::uint32_t>(Config.PushConstantRanges.size());
            LayoutInfo.pPushConstantRanges =
                Config.PushConstantRanges.empty() ? nullptr : Config.PushConstantRanges.data();

            if (vkCreatePipelineLayout(Device, &LayoutInfo, nullptr, &PipelineLayout) != VK_SUCCESS)
            {
                throw std::runtime_error("Failed to create Vulkan graphics pipeline layout.");
            }

            VkGraphicsPipelineCreateInfo PipelineInfo{};
            PipelineInfo.sType = VK_STRUCTURE_TYPE_GRAPHICS_PIPELINE_CREATE_INFO;
            PipelineInfo.stageCount = static_cast<std::uint32_t>(ShaderStageInfos.size());
            PipelineInfo.pStages = ShaderStageInfos.data();
            PipelineInfo.pVertexInputState = &VertexInput;
            PipelineInfo.pInputAssemblyState = &InputAssembly;
            PipelineInfo.pViewportState = &ViewportState;
            PipelineInfo.pRasterizationState = &Rasterizer;
            PipelineInfo.pMultisampleState = &Multisampling;
            PipelineInfo.pDepthStencilState = &DepthStencil;
            PipelineInfo.pColorBlendState = &ColorBlending;
            PipelineInfo.pDynamicState = &DynamicState;
            PipelineInfo.layout = PipelineLayout;
            PipelineInfo.renderPass = TRenderPass;
            PipelineInfo.subpass = 0;

            if (vkCreateGraphicsPipelines(Device, VK_NULL_HANDLE, 1, &PipelineInfo, nullptr, &Pipeline) != VK_SUCCESS)
            {
                throw std::runtime_error("Failed to create Vulkan graphics pipeline.");
            }

            TLogger::Info("TRenderer",
                          "Graphics pipeline created with " + std::to_string(ShaderStageInfos.size()) +
                              " shader stage(s).");
        }
        catch (...)
        {
            for (VkShaderModule Module : ShaderModules)
            {
                vkDestroyShaderModule(Device, Module, nullptr);
            }
            if (PipelineLayout != VK_NULL_HANDLE)
            {
                vkDestroyPipelineLayout(Device, PipelineLayout, nullptr);
                PipelineLayout = VK_NULL_HANDLE;
            }
            throw;
        }

        for (VkShaderModule Module : ShaderModules)
        {
            vkDestroyShaderModule(Device, Module, nullptr);
        }
    }

    TGraphicsPipeline::~TGraphicsPipeline()
    {
        if (Pipeline != VK_NULL_HANDLE)
        {
            vkDestroyPipeline(Device, Pipeline, nullptr);
            Pipeline = VK_NULL_HANDLE;
        }
        if (PipelineLayout != VK_NULL_HANDLE)
        {
            vkDestroyPipelineLayout(Device, PipelineLayout, nullptr);
            PipelineLayout = VK_NULL_HANDLE;
        }
    }

#pragma endregion

#pragma region Pipeline_Accessors

    VkPipeline TGraphicsPipeline::GetHandle() const noexcept
    {
        return Pipeline;
    }

    VkPipelineLayout TGraphicsPipeline::GetLayout() const noexcept
    {
        return PipelineLayout;
    }

#pragma endregion

#pragma region Shader_Module_Creation

    VkShaderModule TGraphicsPipeline::CreateShaderModule(VkDevice Device, const char* Path)
    {
        const std::vector<std::uint32_t> Code = ReadSpirvFile(Path);

        VkShaderModuleCreateInfo CreateInfo{};
        CreateInfo.sType = VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO;
        CreateInfo.codeSize = Code.size() * sizeof(std::uint32_t);
        CreateInfo.pCode = Code.data();

        VkShaderModule Module = VK_NULL_HANDLE;
        if (vkCreateShaderModule(Device, &CreateInfo, nullptr, &Module) != VK_SUCCESS)
        {
            throw std::runtime_error(std::string("Failed to create shader module: ") + Path);
        }
        return Module;
    }
#pragma endregion
} // namespace MDSS::GPU
