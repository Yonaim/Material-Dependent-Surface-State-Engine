/**
 * @file AssetManager.h
 * @brief 일반 에셋 로딩과 조회.
 */

#pragma once

#include "AssetManager/Assets/MaterialAsset.h"
#include "AssetManager/Assets/MeshAsset.h"
#include "AssetManager/Assets/SRProfileAsset.h"
#include "AssetManager/Assets/TextureAsset.h"
#include "AssetManager/Core/Asset.h"

#include <filesystem>
#include <memory>
#include <string>
#include <unordered_map>
#include <vector>

namespace MDSS::GPU
{
    class TVulkanContext;
}

namespace MDSS::Asset
{

    class TAssetManager
    {
    public:
        // Asset loading
        explicit TAssetManager(const GPU::TVulkanContext& Context);

        /** @brief OBJ와 참조된 material·texture만 로드한다. Profile Distribution은 Scene이 별도로 선택한다. */
        [[nodiscard]] TMeshAssetHandle LoadOBJ(const std::filesystem::path& Path);
        /** @brief `.SRProfile` 파일을 로드하고 Profile handle을 반환한다. */
        [[nodiscard]] TSRProfileAssetHandle LoadSRProfile(const std::filesystem::path& Path);
        // Loaded asset access
        /** @throws std::out_of_range Handle이 현재 등록된 Mesh 범위를 벗어난 경우. */
        [[nodiscard]] const TMeshAsset& GetMesh(TMeshAssetHandle Handle) const;
        /** @throws std::out_of_range Handle이 현재 등록된 Material 범위를 벗어난 경우. */
        [[nodiscard]] const TMaterialAsset& GetMaterial(TMaterialAssetHandle Handle) const;
        /** @throws std::out_of_range Handle이 현재 등록된 Texture 범위를 벗어난 경우. */
        [[nodiscard]] const TextureAsset& GetTexture(TextureAssetHandle Handle) const;
        /** @throws std::out_of_range Handle이 현재 등록된 Profile 범위를 벗어난 경우. */
        [[nodiscard]] const TSRProfileAsset& GetSRProfile(TSRProfileAssetHandle Handle) const;

        [[nodiscard]] std::size_t          GetMaterialCount() const noexcept;
        [[nodiscard]] std::size_t          GetSRProfileCount() const noexcept;
        [[nodiscard]] TMaterialAssetHandle GetDefaultMaterialHandle() const noexcept;

    private:
        // Generated textures and materials
        TextureAssetHandle   LoadTexture(const std::filesystem::path& Path, bool bSRGB);
        TextureAssetHandle   CreateSolidTexture(std::string Name, const std::vector<std::uint8_t>& RGBA, bool bSRGB);
        TMaterialAssetHandle CreateMaterial(std::string                  Name,
                                            const std::filesystem::path& SourcePath,
                                            glm::vec4                    BaseColor,
                                            TextureAssetHandle           BaseColorTexture,
                                            TextureAssetHandle           NormalTexture);

        const GPU::TVulkanContext& Context;

        std::vector<std::unique_ptr<TMeshAsset>>               Meshes;
        std::vector<std::unique_ptr<TMaterialAsset>>           Materials;
        std::vector<std::unique_ptr<TSRProfileAsset>>          SRProfiles;
        std::vector<std::unique_ptr<TextureAsset>>             Textures;
        std::unordered_map<std::string, TMeshAssetHandle>      MeshAssetsByPath;
        std::unordered_map<std::string, TextureAssetHandle>    TextureCache;
        std::unordered_map<std::string, TSRProfileAssetHandle> SRProfileCache;

        TextureAssetHandle   DefaultBaseColorTexture = InvalidAssetHandle;
        TextureAssetHandle   DefaultNormalTexture = InvalidAssetHandle;
        TMaterialAssetHandle DefaultMaterial = InvalidAssetHandle;
    };
} // namespace MDSS::Asset
