# 물·잔류 공동 오차와 동적 형상 민감도 — 실행 없는 후속 연구

작성: **2026-10-28 / Asia/Seoul**. [[90_Research-Archive/Research-Notes-2026-10/30_Deep-Analysis/14_Residual-Budget-Critical-Review|14의 미해결점]]인 ‘물 수송도 보호할 수 있는가, 판정 비용을 줄일 수 있는가’를 이어 검토했다.

**[C] 코드 읽기, [P] 문헌 확인, [D] 기호 유도, [H] 방법 제안만 수행했다. 앱·GPU·빌드·학습·수치 실험 미실행, 제품 코드 변경 없음.** 기준은 HEAD `880af1ebcffe601f0bac27413cad94055ce92812`와 기존 작업 트리다. 아래 식은 명시된 부분 모델의 이상 산술 결과이며, FP16/FP32·cache·실제 전체 Solver의 인증이나 신규성 증거가 아니다.

## 1. 이번에 좁혀진 연구 질문

> 내부 수송을 일부 생략하거나 형상 갱신을 늦출 때, 물과 잔류의 **공간 분포 오차**를 함께 추적하면서 그 판정을 실제 갱신보다 싸게 유지할 수 있는가?

이번 분석의 진전은 다음과 같다.

| 결과 | 확보한 것 | 확보하지 못한 것 |
|---|---|---|
| 유입 전환을 포함한 한 Step 오차 | flux 차이로 물·잔류 공동 L1 오차 제한 | 전체 다중 Reaction·장시간 품질 보장 |
| 일부 raw edge 삭제 | limiter 재분배까지 포함하는 상한 2V | 삭제할 edge의 저비용 선택·GPU 이득 |
| 서로 다른 입력 상태의 오차 전파 | 고정 계수·dt 조건에서 증폭 상한, 비수축 반례 | 임의 동적 Geometry·limiter 활성 상태의 전역 상수 |
| 코드의 Normal 복원 구조 | 정적 최소제곱 계수로 높이→Normal 민감도 사전 계산 가능 | 전체 Concavity/중력 분기의 무조건적 보장 |
| 연구 범위 | 제한된 geometry-aware 연산 생략의 구체적 설계 요건 | 선행법보다 강한 새 알고리즘·실측 우위 |

‘오차를 제어하는 적응형 계산’ 자체는 이미 확립된 분야다. 새로 해결할 후보는 **유입 장부에 의해 반응이 달라지고, 공유 형상이 후속 flux를 바꾸는 현재 계산 모델에서 좁고 싼 오차 장부를 유지하는 방법**이다. 필요성과 비용 이점은 여전히 미입증이다.

## 2. [D] 물과 잔류를 동시에 보호하는 한 Step 식

### 2.1 가정과 실제 코드와의 대응

물 q와 이동하지 않는 잔류 a만을 고려한다. recipient j에서 Incoming의 고정 비율 f_j∈[0,1]을 1:1로 잔류로 바꾼다. 다른 반응·Decay·직접 입력·저장량 제거는 없다. 모든 edge는 한 번 차감한 양을 정확히 한 번 가산하며, source의 총 outgoing은 이전 물량 이하이다. 같은 Step의 Incoming을 다시 보내지 않는다.

이는 [Transport.glsl의 rawFlux](C:/Users/yonai/Documents/MDSS_Engine/Shaders/Simulation/Solver/Transport.glsl:1), [Pass 2의 incoming/outgoing 장부](C:/Users/yonai/Documents/MDSS_Engine/Shaders/Simulation/Solver/SurfaceSolverPass2.comp:148), [reactionRequest의 유입 전환](C:/Users/yonai/Documents/MDSS_Engine/Shaders/Simulation/Solver/SurfaceReaction.comp:18)을 제한한 모델이다. 실제 임의 Profile이 이 가정을 만족한다는 뜻은 아니다.

공급량 제한 이후의 실제 flux를 F_ij라 하면

\[
q_i^+=q_i-\sum_jF_{ij}+(1-f_i)\sum_jF_{ji},\qquad
a_i^+=a_i+f_i\sum_jF_{ji}.
\]

오차는 같은 단위의 저장량에 대해 \(E=\|\delta q\|_1+\|\delta a\|_1\)로 정의한다. 물/잔류의 **위치 차이도 포함**한다. Heat 등 단위가 다른 State를 이 norm에 그대로 더하지 않는다. 그런 확장에는 관측별 단위·가중치를 먼저 정해야 한다.

### 2.2 같은 시작 상태에서 두 flux를 비교

시작 q,a와 f는 같고 F와 F̂만 다르다고 하자. δF=F−F̂, δO_i=Σ_jδF_ij, δI_i=Σ_jδF_ji이다. 그러면

\[
\boxed{\|\delta q^+\|_1+\|\delta a^+\|_1
\le\|\delta O\|_1+\|\delta I\|_1
\le2\sum_{i\to j}|\delta F_{ij}|.}
\]

첫 부등식은 물의 차이 −δO+(1−f)δI와 잔류의 차이 fδI에 삼각부등식을 적용하면 된다. (1−f)+f=1이므로 유입의 분배가 새로운 계수를 만들지 않는다.

이 결과는 F가 중력·동적 형상·limiter를 통해 계산돼도 **같은 시작 상태에서 실제 최종 F의 차이를 안다면** 성립한다. 두 실행의 다음 상태가 달라진 뒤의 전파는 별도 문제다. 열린 block만 다룰 때는 외부로 보낸 차이와 돌아오는 영향까지 장부에 넣어야 한다. 여기서는 우선 전체 닫힌 graph를 대상으로 한다.

### 2.3 일부 raw edge를 삭제하고 limiter를 다시 계산하는 경우

같은 상태/형상에서 일부 raw flux만 0으로 만들고, 나머지 raw flux는 유지한다고 하자. source i의 원래 raw 합 S_i, 삭제한 raw 합 R_i, 남긴 합 T_i=S_i−R_i, 공급량 M_i=q_i이다. 원래 배율은 λ_i=min(1,M_i/S_i), 원래 삭제 대상의 **실제** flux 합은 V_i=λ_iR_i이다. S_i=0이면 모두 0으로 정의한다.

삭제 후 남긴 edge의 실제 outgoing 합은 min(M_i,T_i)가 된다. 원래 값 λ_iT_i에서 증가한 양을

\[
D_i=\min(M_i,T_i)-\lambda_iT_i
\]

로 두면 \(0\le D_i\le V_i\)이다. 원래 limiter가 비활성이면 D_i=0이고, 활성인 경우 T_i≥M_i이면 D_i=V_i, T_i<M_i이면 D_i=(1−λ_i)T_i≤V_i이다.

**edge별 절댓값만 합치면** 삭제 V_i와 재분배 D_i 때문에 2Σ|δF|≤4ΣV_i라는 느슨한 상한이 나온다. 하지만 source 장부를 먼저 합치면 더 강한 결과를 얻는다.

- source에 남는 추가 물은 V_i−D_i이다.
- 삭제된 recipient들에서 빠지는 공동 물/잔류량은 V_i 이하이다.
- 남긴 recipient들에 추가되는 공동 물/잔류량은 D_i 이하이다.

따라서 각 source의 기여를 합쳐

\[
\boxed{\|\delta q^+\|_1+\|\delta a^+\|_1
\le2\sum_iV_i\le2\sum_iR_i.}
\]

즉 **limiter 재분배를 무시하면 안 되지만, source별 취소를 이용하면 2V 상한을 유지할 수 있다.** 이 유도에는 모든 retained edge가 같은 source 배율로 증가한다는 구조가 필요하다. retained raw flux 자체를 근사하거나 Reaction의 공급량 경쟁·다른 State 소비를 추가하면 그대로 적용할 수 없다.

이것은 한 Step local defect이다. ‘매번 2V보다 작으므로 전체 실행도 2V 이내’라고 해석하지 않는다. 또한 원래 모든 flux를 계산한 뒤 작은 것을 버리는 구현은 계산 절감의 근거가 되지 않는다.

## 3. [D] 보존한다고 오차가 수축하지는 않는다

### 3.1 고정 계수의 충분조건

형상·재질 계수가 고정되고 cavity retention의 State 의존성이 없다고 하자. 비음수 q에 대한 flux를 다음으로 제한한다.

\[
F_{ij}=k_{ij}(q_i/C_i-q_j/C_j)_++\gamma_{ij}q_i.
\]

k와 γ는 dt를 포함한 비음수 상수, C_i>0이다. γ는 고정 형상의 geometry drive×rate×weight/C_i에 해당한다. 빠진 방향의 k,γ는 0으로 둔다. 다음은 편리하지만 필요조건은 아닌 충분조건이다.

\[
\Lambda_i={1\over C_i}\sum_j\max(k_{ij},k_{ji})+\sum_j\gamma_{ij},
\qquad\Lambda=\max_i\Lambda_i\le1.
\]

이 조건에서는 outgoing≤q_i여서 limiter가 비활성이고, 반응 전 보존 수송 T(q)=q−O(q)+I(q)는 componentwise 단조이다. 자기 성분의 최소 기울기가 1−Λ_i 이상이고 다른 성분에 대한 기울기는 비음수이기 때문이다. kink에서도 연속 piecewise-linear 단조성이 유지된다.

T는 총량을 보존하므로 L1 비팽창이다. 직접적으로 z=min(q,q̂)를 두면 Tz≤Tq,Tq̂이고

\[
\|Tq-T\widehat q\|_1\le\sum_i(Tq_i+T\widehat q_i-2Tz_i)
=\|q-\widehat q\|_1.
\]

이 논리는 기존 order-preserving/integral-preserving mapping 성질의 적용이다. [Nussbaum & Shustin 2001 원문 p.388 전후](https://sites.math.rutgers.edu/~nussbaum/Pubs/nonexpansiveJDDE.pdf)는 이를 Crandall–Tartar 결과로 설명한다. 새로운 정리로 주장하지 않는다.

### 3.2 유입 전환을 추가하면 상수가 달라진다

같은 unordered pair의 양방향 saturation flux 차이를 합치면

\[
|\delta F_{ij}^{sat}|+|\delta F_{ji}^{sat}|
\le\max(k_{ij},k_{ji})|\delta(q_i/C_i-q_j/C_j)|.
\]

고정 gravity 항까지 합쳐 \(\|I(q)-I(\widehat q)\|_1\le\Lambda\|q-\widehat q\|_1\)이다. 전체 한 Step은

\[
\Psi(q,a)=(T(q)-fI(q),\ a+fI(q)).
\]

따라서 f_max=max_i f_i일 때

\[
\boxed{\|\Psi(x)-\Psi(\widehat x)\|_1
\le(1+2f_{max}\Lambda)\|x-\widehat x\|_1.}
\]

이 상한은 고정 계수·dt 조건의 두 State 모델에 한정된다. **각 상태에서 Λ≤1인 것만으로 State에 의존하는 k(q,a),γ(q,a)의 전역 상한이 되지 않는다.** 형상 변화로 인한 계수 차이를 추가해야 한다. limiter가 활성인 일반 영역의 Lipschitz 상수도 여기서 증명하지 않았다.

### 3.3 오차가 실제로 커지는 두 texel 반례

같은 C=1, gravity=0, 양방향 k=β∈(0,1/2], 같은 f>0인 두 texel을 둔다. 물이 x>y일 때 낮은 쪽 y에만 ε∈(0,x−y)를 더한 두 초기 상태를 비교한다. 초기 잔류는 같다.

한 Step 후의 차이는

\[
\delta q_1^+=\beta\varepsilon,\quad
\delta q_2^+=[1-(1-f)\beta]\varepsilon,\quad
\delta a_2^+=-f\beta\varepsilon,\quad \delta a_1^+=0.
\]

초기 공동 오차 ε가 **(1+2fβ)ε**로 커진다. 물만의 L1 오차도 (1+fβ)ε이다. 반면 signed 총량 차이는 계속 ε이고, 두 실행 각각의 상태도 비음수이다.

이유는 낮은 쪽에 물을 더 넣으면 saturation 차이가 줄어 Incoming과 잔류 생성이 감소하기 때문이다. **총량 보존·비음수성과 실행 간 분포 오차의 비증폭은 서로 다른 성질**이다. 이 반례는 코드에서 사용하는 유입 반응의 구조를 드러내지만, 그 자체를 새 수치해석 원리나 SIGGRAPH Contribution으로 세지 않는다.

## 4. [D] 여러 Step의 오차 장부

정확 모델 x_(n+1)=Ψ_n(x_n), 근사 모델 x̂_(n+1)=Ψ̂_n(x̂_n)을 비교한다. reference는 같은 fine 이산 모델이며 물리적 정답/PDE 해가 아니다. 공통 허용 영역에서 Ψ_n의 Lipschitz 상한 L_n과 같은 입력에서의 local defect δ_n이 있으면

\[
E_{n+1}\le L_nE_n+\delta_n,
\]

\[
E_H\le E_0\prod_{r=0}^{H-1}L_r+
\sum_{n=0}^{H-1}\delta_n\prod_{r=n+1}^{H-1}L_r.
\]

고정 계수 제한 모델에서는 위 L_n과 삭제 defect 2V_n을 사용할 수 있다. 정확 계산으로 돌아온 Step의 δ_n=0이어도 기존 E_n은 사라지지 않는다. block을 깨우거나 현재 근사 상태를 새 기준으로 삼았다는 이유로 오차 장부를 0으로 초기화할 수 없다.

매 Step 전역 최대 L을 곱하면 지나치게 보수적일 수 있다. node/State별 비음수 오차 전달 행렬을 유지하는 대안은 가능하지만 저장·갱신 자체가 큰 stencil 계산이 될 수 있다. **실용적인 상한의 폭과 유지 비용이 연구 문제로 남는다.** 이 recurrence 자체는 기존 적응형 수치해석의 표준 구조다.

## 5. [C/D] 현재 Normal 계산은 일부를 사전 계산할 수 있다

### 5.1 동적 Normal이지만 최소제곱 행렬은 정적이다

[StateMath.glsl::effectiveLocalNormal](C:/Users/yonai/Documents/MDSS_Engine/Shaders/Simulation/Solver/StateMath.glsl:116)을 다시 확인했다.

- tangent frame U,V,N은 **정적 macro normal**에서 만든다.
- 이웃 X,Y는 **정적 Positions의 차이**를 frame에 투영한다.
- 이웃의 유효성·macro normal 필터·LengthSquared 조건도 고정 mesh/profile/topology에서는 정적이다.
- 바뀌는 것은 meso+accumulation 높이 차이 DH이다.

그러므로 최소제곱 행렬 A_i와 determinant fallback 판정은 이 조건에서 정적이다. ‘모든 Geometry 최소제곱 행렬이 State에 따라 변한다’는 일반화는 이 함수에는 맞지 않는다. nonfinite 값 발생·mesh/profile/transform 변경은 별도이다. 뒤의 **동적 Concavity 함수**와 혼동하지 않는다.

유효 이웃의 정적 가중치 w_ij와 좌표 (X_ij,Y_ij)를 쓰면

\[
A_i=\sum_jw_{ij}\begin{bmatrix}X_{ij}^2&X_{ij}Y_{ij}\\X_{ij}Y_{ij}&Y_{ij}^2\end{bmatrix},
\quad v_{ij}=A_i^{-1}w_{ij}\begin{bmatrix}X_{ij}\\Y_{ij}\end{bmatrix},
\]

\[
g_i=\sum_jv_{ij}(h_j-h_i),\qquad
n_i(g_i)={N_i-U_ig_{ix}-V_ig_{iy}\over\sqrt{1+\|g_i\|_2^2}}.
\]

### 5.2 높이 차이의 오차로 Normal 오차를 제한

정규직교 frame에서 g→n(g)의 Jacobian 최대 특이값은 1 이하이다. 따라서

\[
\boxed{\|\delta n_i\|_2\le\|\delta g_i\|_2
\le\sum_j\|v_{ij}\|_2|\delta h_j-\delta h_i|.}
\]

각 높이 오차가 ε 이하라면 오른쪽은 2εΣ_j||v_ij|| 이하이다. **v_ij는 사전 계산 가능**하므로 bound를 만들기 위해 매번 최소제곱 역행렬을 다시 구할 필요가 없다. 하지만 이웃별 bound 합산·메모리 접근은 남는다.

공통 높이 오차는 이 Normal 식에서 상쇄된다. 따라서 절대 높이 차이만 보는 Dirty threshold보다 **높이 오차의 이웃 차이**가 더 적절한 판정량일 수 있다. 다만 curved macro normal을 따라 같은 높이를 더하면 위치 간 거리는 바뀔 수 있으므로, 모든 수송 항이 불변이라는 뜻은 아니다.

determinant fallback이 정적으로 선택되면 이 함수는 고정 Meso normal을 반환하므로 해당 branch의 높이에 대한 Normal 민감도는 0이다. 정상 branch라도 ill-conditioned A와 작은 texel 간격은 Σ||v_ij||를 크게 만들 수 있다. 해상도를 높여도 동일 ε가 동일 수송 오차를 보장하지 않는다.

고정 nonsingular NormalMatrix B에 의한 world normal에는 보수적으로

\[
\|\delta n_i^{world}\|_2\le2\,\operatorname{cond}_2(B)\|\delta n_i\|_2
\]

를 쓸 수 있다. singular transform·nonfinite·정규화 실패는 제외한다.

### 5.3 State에서 높이로 가는 bound

모든 관련 State의 cavity contribution이 0이고 profile/면적/transform이 고정된 경우, [accumulationHeight](C:/Users/yonai/Documents/MDSS_Engine/Shaders/Simulation/Solver/StateMath.glsl:48)는 비음수 q에 대해

\[
h_i=h_i^{meso}+\sum_k c_{ik}\min(q_{ik},C_{ik}),\qquad
c_{ik}={Factor_{ik}\,Thickness_{ik}\over AreaScale_i}\,WorldToLocalHeight_i.
\]

따라서 \(|\delta h_i|\le\sum_kc_{ik}|\delta q_{ik}|\)이다. cap은 높이 민감도를 줄일 수 있지만, 그 위의 숨은 저장량이 미래 반응에 영향을 주지 않는다는 뜻은 아니다. [IceReactionLab Profile](C:/Users/yonai/Documents/MDSS_Engine/Assets/SurfaceProfiles/IceReactionLab.SRProfile)은 cavity 관련 계수가 0인 예다. 그 Profile의 **전체 Ice/Heat 반응까지 §2–4에서 증명한 것은 아니다.**

## 6. [C/D] Transfer Weight와 중력에 연결할 때의 조건

### 6.1 Normal·거리 가중치

[buildTransferWeight](C:/Users/yonai/Documents/MDSS_Engine/Shaders/Simulation/Geometry/SurfaceDynamicWeightsUpdate.comp:98)의 NormalWeight는 clamp(dot(n_i,n_j),0,1)이므로

\[
|\delta W_N|\le\|\delta n_i\|_2+\|\delta n_j\|_2.
\]

DistanceWeight는 clamp(R/d,0,1), R=(meanDistance_i+meanDistance_j)/2이다. 두 실행의 관련 이웃이 동일하게 유효하고 모든 거리 d≥d_min>GeometryEpsilon, R≤R_max이면

\[
|\delta W_D|\le{|\delta R|\over d_{min}}+
{R_{max}|\delta d|\over d_{min}^2}.
\]

단위 macro normal과 고정 ModelLinear M에서 \(|\delta d_{ij}|\le\|M\|_2(|\delta h_i|+|\delta h_j|)\). meanDistance의 이웃 집합이 같으면 그 오차는 거리 오차의 평균으로 제한한다. 실제 [Geometry Update](C:/Users/yonai/Documents/MDSS_Engine/Shaders/Simulation/Geometry/SurfaceDynamicGeometryUpdate.comp:31)는 epsilon보다 작은 거리를 제외하므로 **유효 이웃 수의 변경이 없다는 조건**을 확인해야 한다.

모든 인수가 [0,1]이고 Profile boundary 항은 고정이므로 곱 가중치의 차이는 각 가중치 차이의 합으로 제한할 수 있다. FP16 가중치 양자화는 별도 오차 항이다.

### 6.2 정규화한 접선 중력에는 추가 margin이 필요하다

[prepareSourceGeometry](C:/Users/yonai/Documents/MDSS_Engine/Shaders/Simulation/Solver/GeometryDrive.glsl:6)는 t=(I−nnᵀ)g를 **길이로 정규화**한다. 따라서 접선 중력이 거의 0인 영역에서는 Normal의 작은 변화가 중력 방향의 큰 차이로 이어질 수 있다.

두 상태에서 ||t||≥g_min>GeometryEpsilon이고 같은 유효 branch에 있다면

\[
\|\delta(t/\|t\|)\|_2\le {4\|g\|_2\over g_{min}}\|\delta n\|_2.
\]

world edge vector e, ||e||≥d_min, ||e||≤d_max, SolverUp=u를 두자. 코드의 drive는 |e·u| clamp(dot(t/||t||,e/||e||),0,1)이다. H_max=||u||d_max로 놓으면 충분한 상한은

\[
|\delta Drive|\le\|u\|\|\delta e\|+
H_{max}\left({4\|g\|\over g_{min}}\|\delta n\|
+{2\over d_{min}}\|\delta e\|\right).
\]

g_min→0이면 이 bound가 나빠진다. 이는 실제 결과가 항상 불연속이라는 증명이 아니라 **이 인증 방식이 해당 영역을 값싸게 다루지 못한다는 한계**다. 중력 OFF 또는 양쪽에서 확실히 비활성인 branch는 별도로 처리할 수 있다. 애매한 branch를 임의로 정상 branch로 취급하지 않는다.

### 6.3 아직 남는 항

[buildDynamicConcavityWeight](C:/Users/yonai/Documents/MDSS_Engine/Shaders/Simulation/Geometry/SurfaceDynamicWeightsUpdate.comp:36)는 dynamic normal·dynamic position으로 frame/샘플/행렬을 만들고 fallback을 사용한다. §5의 정적 행렬 논리가 그대로 적용되지 않는다. 첫 제한 모델에서 cavityExitResistance=0 및 Decay/보호 비활성으로 **수송/손실의 Concavity 의존성을 제거**할 수는 있다. 그것은 범위를 줄인 연구이지 전체 기능의 인증이 아니다.

같은 상태 y에서 Geometry만 바뀌면 raw flux 계수 차이를 위 식들로 제한할 수 있다. 반면 두 trajectory의 상태와 Geometry가 모두 달라지면, 다음 두 항을 분리해야 한다.

1. 한 Geometry에서 x와 y의 상태 차이를 전파하는 항.
2. 같은 y에서 G(x)와 G(y)의 차이가 만드는 flux defect.

예를 들어 limiter 비활성인 허용 영역에서 두 번째 항의 edge flux 합을 Γ||x−y|| 이하로 증명했다면 공동 상태의 전파 상수로 L_frozen+2Γ를 쓸 수 있다. **현재 전체 모델의 유용한 Γ는 아직 확보하지 않았다.** State 저장량은 cap이 없으므로 saturation의 상한을 Geometry cap으로 대신할 수도 없다.

## 7. [H] 저비용 판정 방법의 구체적 초안

다음은 구현되지 않은 설계다. fine 상태를 유지하면서 연산을 선택적으로 생략하는 방식으로 먼저 좁힌다. 이것만으로 coarse 메모리 절감은 주장하지 않는다.

1. **정적 준비:** topology·profile·면적·transform 조건, v_ij와 그 norm, 가능한 계수 상한을 준비한다. mesh/profile/transform 변경 시 유효성을 다시 판정한다.
2. **공통 범위:** reference와 근사 양쪽을 포함하는 State·높이·거리·중력 margin 범위를 유지한다. 현재 근사 상태의 min/max만으로 reference까지 포함한다고 가정하지 않는다.
3. **계산 전 flux 상한:** 예를 들어 saturation 항의 raw flux는 k_ij^max(s_i^upper−s_j^lower)_+ 이하이다. gravity 항은 γ_ij^max q_i^upper로 더한다. block 내부는 느슨한 공통 범위·미리 합친 계수로 상한을 줄 수 있고, 경계는 더 세밀하게 유지한다.
4. **삭제 제안:** 삭제할 edge의 raw 상한 합을 R_bound로 두어 같은 입력의 defect를 2R_bound 이하로 제한한다. source가 한쪽에서는 edge를 보내고 다른 쪽에서는 받지 않는 독립 삭제는 금지한다. §2의 장부 계약을 유지해야 한다.
5. **오차 전파:** 이전 오차와 Geometry 계수 차이, 새 삭제 defect, 저장 양자화 항을 합쳐 관측별 허용오차를 확인한다. 같은 오차 원인을 중복 계상하거나 누락하지 않도록 map을 먼저 고정한다.
6. **정확 갱신으로 복귀:** bound가 너무 크거나 branch 조건을 확인하지 못하면 해당 영역의 생략을 허용하지 않는다. 이전 오차는 유지하며, 장기 회복이 필요하면 신뢰된 checkpoint부터의 replay 등 별도 방법/비용이 필요하다.

저비용화의 핵심은 3을 실제 fine flux보다 싸게 수행하는 것이다. 매 Step 모든 edge의 높이·Normal·거리·flux를 먼저 계산하고 생략 여부만 결정하면 연구 목표를 놓친다. 대신 정적 계수와 block 범위를 쓰면 계산은 줄일 수 있지만 상한이 넓어져 생략이 거의 사라질 수 있다.

대략적인 필요조건은

\[
C_{audit}/H+C_{bound}+C_{boundary}+C_{wake}<C_{saved}.
\]

H는 감사/범위 재구축 사이의 Step 수다. 각 항은 **미측정**이며 이 부등식을 만족한다는 주장은 없다. 현재 활성 영역 Sparse가 이미 제거하는 빈 영역을 다시 제거한 이득으로 셈하지 않는다. 남은 표적은 **State가 존재하되 변화가 작거나 목표 관측에 영향이 작은 내부 영역**이다.

## 8. 선행연구에 비추어 무엇이 남는가

문헌 확인 수준은 [[90_Research-Archive/Research-Notes-2026-10/90_Reference/07_Related-Work|R36–R38]]에 기록했다.

- 단조·총량 보존으로 L1 비팽창을 얻는 논리는 기존이다.
- conservation-law adaptive multiresolution은 이미 flux 계산/표현을 줄이면서 근사 오차를 다룬다. 관련 원문 전체 접근은 제한돼 세부 적용 가능성 판단은 남는다.
- 반응–확산에서 threshold와 local time stepping을 함께 써서 계산과 오차를 관리하는 연구도 존재한다. [Bendahmane et al.의 저자 preprint](https://arxiv.org/abs/0807.1359)의 초록에서 확인했다. ‘Reaction이 있어서 기존 적응법은 못 쓴다’는 주장은 할 수 없다.

따라서 아래는 **새 Contribution으로 주장하지 않는다**: 2V 삼각부등식, Lipschitz recurrence, 정적 LS 민감도, interval bound, 느린 곳을 잠재우는 기본 아이디어.

그 이후에 남는 후보는 다음의 결합을 **표준 대조보다 실질적으로 잘 푸는 구체적인 방법**이다.

> 유입 경로에 따른 반응과 공유 형상 변화가 있는 표면 모델에서, 물·잔류·후속 수송에 중요한 오차를 추적하는 저비용 적응 갱신.

가장 강한 반론은 ‘기존 error-controlled adaptive finite volume에 geometry cache bound를 붙인 것이다’이다. 현 단계에서는 그 반론을 이겼다고 말할 수 없다. 기존 방법에 동일한 사전 계수·오차 정보·반응 장부를 허용한 대조가 필요하다.

## 9. 세 방향의 현재 유력도와 중단 조건

| 방향 | 이번 연구가 추가한 것 | 현재 평가 |
|---|---|---|
| 3: 내부 반응·수송을 보존하는 축소/생략 | 물+잔류 분포 defect, 반응 비수축 반례, Normal 사전 민감도 | **알고리즘 탐색으로 가장 구체적. 신규성·실용성은 미입증.** 현 단계는 압축보다 연산 생략 문제에 가까움 |
| 2: 다른 현상을 보호하는 편집 | 형상 보존 제약/오차 평가에 쓸 수 있는 정적 민감도 구조 | 제작 목적과 가장 가까움. 이를 쓴 표준 optimizer보다 나은 해결법은 아직 없음 |
| 1: 미래 진행 역설계 | 목표 시점의 오차 장부를 방향2와 공유할 가능성 | 단독 기여 우선순위는 낮고, 방향2의 목표·평가로 유지 |

가장 작은 다음 이론 과제는 **cavity/Decay OFF, 단일 Incoming 전환, 제한된 transform·거리·중력 margin**에서, 위 구성의 Γ와 block 범위 갱신을 끝까지 연결하는 것이다. 여기서도 매 Step fine 계산과 같은 일이 필요하거나 bound가 대부분의 영역을 깨운다면 이 방법을 중단/수정한다.

이후 실제 실행이 허용될 때에만 품질–비용 대조를 수행한다. reference는 매 Step 전체 fine 갱신, 대조는 현 exact Sparse, 고정 주기/높이 threshold, 합리적인 적응형 flux/잔차 기준이다. 허용오차·관측·시간을 동일하게 하고 모든 준비/판정/재활성화 비용을 포함한다. 신규성 확인은 그와 별개의 문헌/방법 비교 과제다.

**현재 판정은 변하지 않는다:** 현 구현의 새로운 Contribution은 미확보다. 이번에는 ‘왜 오차 제어가 필요한가’의 반례와 ‘무엇을 사전 계산할 수 있는가’의 코드 근거가 추가됐고, 저비용 해법의 구체적 입증 과제가 줄었다. 이는 연구의 진전이지만 채택 가능성이나 실제 속도 향상의 증거는 아니다.
