# 열린 경계의 정보 계약과 오차 합성 — 조건부 확장과 실패 지점

작성: **2026-10-28 / Asia/Seoul**. [[90_Research-Archive/Research-Notes-2026-10/30_Deep-Analysis/16_Low-Cost-Certificates-and-Sleep-Horizons|16]]의 다음 질문인 열린 영역의 최소 외부 정보를 검토했다. **코드/문헌 읽기·기호 유도·문서 작성만 수행했다. 앱·GPU·빌드·수치 실험·학습 미실행, 제품 코드 변경 없음.** 코드 기준은 HEAD `880af1ebcffe601f0bac27413cad94055ce92812`와 기존 작업 트리다.

아래 [D]는 제한된 모델의 이상 산술 분석, [C]는 코드 근거, [H]는 미구현 제안, [P]는 확인한 선행연구다. 새로운 Contribution이나 실제 실행 성능을 입증하지 않는다.

## 1. 이번 결론

열린 경계를 포함하는 오차 식은 만들 수 있다. 그러나 **식을 여러 block에 합칠 수 있다는 것과, 그 결과가 실제로 쓸 만한 정확도/비용을 갖는다는 것은 다르다.**

이번에 구체화한 결과는 다음이다.

1. 같은 시점·위치로 들어온 물은 모두 새 오차로 셀 필요가 없다. 두 실행에 공통으로 남는 물/잔류를 하한으로 빼면, 유입 이후의 이동 가능량과 서로 다른 유입만 계상할 수 있다.
2. 이 하한은 이동률 구간별 recurrence로 유지할 수 있고, 제한 모델에서는 경계의 오차 항을 상쇄하여 전체 영역의 오차 상한을 만들 수 있다.
3. 하지만 그 단순 합성은 **16의 전체 영역 α 상한보다 더 느슨할 수밖에 없는 구조**가 있다. 이 자체를 주력 방법으로 구현할 근거는 부족하다.
4. 실제 코드의 경계 영향은 물량만으로 결정되지 않는다. **source의 내부 raw outgoing 합**과 **공유 Geometry의 stencil 영향**도 필요하다.
5. 따라서 다음 후보는 무조건 많은 경계 통계를 저장하는 방법보다, **내부가 경계에 영향을 주지 않는 조건 또는 제한된 영향만 주는 조건을 판정하는 계산 계약**으로 좁혀야 한다.

## 2. [D] 유입은 위치·시간·방향별로 구분해야 한다

여기서 port는 block을 가로지르는 **방향 있는 실제 edge**다. u_e^n은 Step n에서 외부→내부로 들어온 실제 물량, o_e^n은 내부→외부로 나간 실제 물량이다. source에서 뺀 값과 target Incoming에 더한 값은 같아야 한다. q는 물, a는 움직이거나 줄어들지 않는 잔류, f_i∈[0,1]은 recipient i의 고정 1:1 Incoming 전환 비율이다.

반례는 간단하다.

- 유입 총량이 같아도 f가 다른 두 위치로 들어오면 즉시 생성되는 잔류량이 다르다.
- f가 같아도 들어온 위치가 다르면 잔류의 공간 분포가 다르다.
- 위치·총량이 같아도 관측 직전에 들어온 물과 여러 Step 전에 들어온 물은 내부 이동에 사용할 수 있었던 시간이 다르다.

따라서 ΣIncoming−ΣOutgoing 또는 관측 끝의 누적 총량만으로 일반적인 후속 결과를 보존할 수 없다. 다만 **상한을 계산하는 용도**라면 이후처럼 일부 정보를 보수적으로 묶을 수 있다. 정확한 상태 복원과 오차 상한용 요약은 구분한다.

## 3. [D] 공통 유입을 이용한 열린 block의 공동 하한

### 3.1 모델과 하한

reference와 근사는 같은 q⁰,a⁰에서 시작한다. 내부/경계 outgoing 전체가 O_i^n≤α_i q_i^n을 만족하고, r_i=1−α_i∈[0,1]라 하자. 중력·동적 형상·limiter는 이 상한 안에서 허용한다. 단일 Incoming 전환 이외의 소비/생성·Decay·직접 제거는 없다.

두 실행의 경계 유입 u_e^n, û_e^n에서 c_e^n=min(u_e^n,û_e^n)를 공통 부분으로 둔다. recipient별 c_i^n=Σ_{e→i}c_e^n이다. 그러면 두 실행 모두

\[
q_i^H\ge r_i^Hq_i^0+
\sum_{n=0}^{H-1}r_i^{H-1-n}(1-f_i)c_i^n=:b_i^q(H),
\]

\[
a_i^H\ge a_i^0+\sum_{n=0}^{H-1}f_i c_i^n=:b_i^a(H).
\]

이유는 q_i^(n+1)≥r_iq_i^n+(1−f_i)c_i^n이며, 새 유입은 같은 Step에 다시 outgoing으로 사용되지 않기 때문이다. 내부 Incoming은 하한에서 버려도 비음수다. a의 내부 전환도 하한을 늘릴 뿐이다.

### 3.2 출력 이력까지 포함한 상한

내부 최종 상태뿐 아니라 **port×Step별 outgoing 이력 전체**를 벡터에 붙인다. outgoing을 최종 누적값 하나로 먼저 합치지 않는다. 이렇게 해야 앞뒤 시점의 상반된 오차가 취소되어 외부의 시간 의존 반응을 놓치는 일을 피한다.

각 실행의 (q−b^q, a−b^a, outgoing history)는 비음수다. 수지에서 두 벡터 총합을 더하면

\[
\boxed{E_B(H)+D_B^{out}(H)\le2B_B(H;c)+D_B^{in}(H),}
\]

\[
E_B=\|q^H-\widehat q^H\|_1+\|a^H-\widehat a^H\|_1,
\quad D_B^{in}=\sum_{n,e\to B}|u_e^n-\widehat u_e^n|,
\quad D_B^{out}=\sum_{n,e:B\to}|o_e^n-\widehat o_e^n|,
\]

\[
B_B(H;c)=\sum_i q_i^0(1-r_i^H)+
\sum_{n,i}(1-f_i)c_i^n(1-r_i^{H-1-n}).
\]

첫 항은 초기 물 중 그 위치를 떠날 가능성이 있는 양, 둘째 항은 **공통 유입 중 즉시 잔류로 바뀌지 않은 부분이 이후에 떠날 가능성이 있는 양**이다. 들어온 직후에는 둘째 항이 0이다. 직접 생긴 공통 잔류 f_i c_i^n은 움직이지 않으므로 차이 예산에 다시 넣지 않는다.

이 식은 앞선 2B+I_ref+I_approx보다 공통 유입을 더 세밀하게 사용한다. 하지만 c를 구하려면 보통 reference의 미래 유입이 필요하므로, 그대로 구현 가능한 공짜 입력이라고 볼 수 없다.

### 3.3 검증된 구간만 아는 경우

c를 정확히 모르고 c_lower≤u,û인 공통 하한만 알면, 입력 불일치 대신 두 입력에서 c_lower를 뺀 **남은 총량**의 상한을 사용해야 한다. 낮은 c_lower를 위 B에 넣으면서 실제 |u−û|만 더하면 공통 유입의 일부를 누락한다. 이 둘을 혼동하지 않는다.

또 근사와 reference에 같은 경계 유입을 강제로 재생한 비교는 **주어진 입력에서의 block 응답 비교**다. 완전히 결합된 MDSSP에서도 그 유입이 같다는 증거가 아니다.

## 4. [D/H] 이동률 구간으로 하한의 합을 유지

16처럼 α_i≤ᾱ_b인 구간 b를 잡고 r_b=1−ᾱ_b로 둔다. 각 구간에서 초기 Q_b^0=Σ_i∈b q_i⁰, B_B^0=0으로 시작한다. 공통 유입의 mobile 부분 U_b^n=Σ_i∈b(1−f_i)c_i^n에 대해

\[
Q_b^{n+1}=r_bQ_b^n+U_b^n,\qquad
B_B^{n+1}=B_B^n+\sum_b\bar\alpha_bQ_b^n.
\]

이 recurrence는 §3의 B를 구간 상한으로 계산한다. 원래 각 위치에 공통으로 남는 양의 하한은 존재하지만, 그 **합**만 요약해도 지름 상한 계산에는 충분하다. 유입 이력 전체나 모든 내부 texel을 매 Step 읽을 필요는 없다.

대신 경계 유입을 recipient의 구간과 f에 따라 집계하는 비용이 든다. 이미 계산된 Incoming을 활용할 수 있어도 집계/동기화 비용이 0은 아니다. K개 요약의 갱신은 O(K), 경계 집계는 실제 경계 크기에 의존한다. fine 상태와 경계에 필요한 상태는 여전히 보존한다.

## 5. [D] block을 합칠 수 있지만, 이 단순 합성은 주력 해법이 되기 어렵다

### 5.1 제한 모델의 합성

전체 닫힌 graph를 겹치지 않는 block으로 나누고 같은 fine Step을 사용한다고 하자. 각 실행 안에서 cut edge의 outgoing이 바로 이웃의 incoming이며, 같은 방향/시점/단위를 유지해야 한다. 그러면

\[
\sum_BD_B^{out}=\sum_BD_B^{in}.
\]

§3의 부등식을 합치면 경계 오차 항이 상쇄되어

\[
\boxed{E_{global}(H)\le2\sum_B B_B(H;c).}
\]

각 B_B는 c에 대해 단조 증가한다. c≤û이므로 **근사 실행에서 실제 관측한 유입 û**로 recurrence를 돌린 B̂_B를 쓰면 B_B(c)≤B̂_B이다. 따라서 reference를 실제 실행하지 않고도

\[
E_{global}(H)\le2\sum_B\widehat B_B(H)
\]

라는 더 느슨한 조건부 상한을 얻는다. 같은 초기 상태·단일 1:1 전환·유효 α·비음수/수지 계약이 모두 필요하다. 외부 입력이 다르면 해당 불일치 항은 상쇄되지 않는다. local time stepping을 허용하려면 공통 port-time 장부로 다시 정식화해야 한다.

Geometry가 달라져도 α가 그 모든 변화를 포함하면 위 두 State의 수지 증명은 유지된다. 이 때문에 아래 §7의 geometry-only 영향과 모순되지 않는다. 다만 다른 State의 결과를 자동으로 보장하지 않는다.

### 5.2 더 중요한 반론: 전체 영역 상한보다 느슨하다

같은 α_i, 같은 초기 시점, 같은 기간을 사용한 16의 전체 영역 상한은 **초기 물 cohort**만 센다. 위 block별 B̂는 그 초기 항들에 더해, 내부 경계를 넘을 때마다 생긴 경계 유입 cohort의 이동 가능량을 비음수 항으로 더한다. 따라서 닫힌 전체 영역의 물·잔류 오차만 목표라면

\[
\boxed{\sum_B\widehat B_B(H)\ge
\sum_iq_i^0(1-r_i^H)}
\]

이다(같은 bin 상한을 사용하는 경우도 동일). **단순히 쪼개 합성한 것만으로 전역 판정이 좋아지지 않는다.**

또 이 bound는 실제로 두 실행이 완전히 같은 영역의 정상적인 이동도 예산에 넣는다. 정확히 계산하는 활성 영역까지 같은 방식으로 계상하면, 생략한 영역이 작아도 상한이 커질 수 있다. 순환 이동은 경계 cohort를 반복 생성해 특히 불리하다.

따라서 ‘α-bin을 모든 block에 넣고 경계 입력을 더하면 실용적인 열린 영역 알고리즘이 완성된다’는 제안은 **현재 주력 구현안에서 보류**한다. 합성 가능성은 확보했지만 품질–비용 우위를 설명하지 못한다. 같은 시점/α의 비교에서 불리하다는 결론이며, 모든 block 모델이 불가능하다는 정리는 아니다.

필요한 개선은 **양쪽에서 같은 이동을 계속 비용으로 세지 않고, 근사 때문에 새로 달라진 부분을 구분하는 것**이다. 15의 local defect/오차 전달이나 기존 goal-oriented·compositional 분석과 연결해야 한다. 블록별 시계를 임의로 초기화해 이 문제를 숨길 수는 없다.

## 6. [C/D] 경계 source의 값만 같아도 경계 Flux는 달라진다

[SurfaceSolverPass1.comp](C:/Users/yonai/Documents/MDSS_Engine/Shaders/Simulation/Solver/SurfaceSolverPass1.comp:95)는 source의 모든 방향 raw flux를 합친 뒤, available amount M에 대해 λ=min(1,M/RawOutgoing)을 계산한다. [Pass 2](C:/Users/yonai/Documents/MDSS_Engine/Shaders/Simulation/Solver/SurfaceSolverPass2.comp:85)는 이 source 배율을 경계 incoming에도 곱한다.

source의 경계 raw flux 합을 S, 내부 raw flux 합을 T, 특정 경계 edge의 raw flux를 r_e라 하면

\[
F_e=r_e\min(1,M/(S+T)).
\]

M=1, r_e=S=1인 source에서 T=1이면 F_e=1/2, T=3이면 F_e=1/4이다. **경계 source 양과 경계 raw 조건은 같은데 내부 수송 요구량 때문에 경계 출력이 다르다.** 이는 정규화된 장부 예이며 실제 장면 실행 결과가 아니다. 내부 target saturation과 edge 가중치가 T를 바꿀 수 있고, source 전체 배율로 경계에도 영향이 전달된다.

### 내부 전체 대신 필요한 요약을 제한할 수 있는 경우

M,S,r_e가 같고 내부 T의 검증된 범위 [L,U]만 알면, S+L>0일 때

\[
r_e\min(1,M/(S+U))\le F_e\le r_e\min(1,M/(S+L)).
\]

M≥S+U이면 limiter가 확실히 비활성이므로 **F_e=r_e이고 내부 T의 정확한 값이 불필요**하다. S+L>M인 활성 branch에서는 구간 폭이

\[
\Delta F_e\le {r_eM(U-L)\over(S+L)(S+U)}
\]

이다. branch를 가로지르면 위 endpoint 식으로 처리한다. 분모가 0인 경우는 해당 raw edge도 0인 별도 경우로 다룬다. M,S,r_e까지 불확실하면 그 상관관계를 포함한 추가 enclosure가 필요하다.

이는 **내부가 경계에 영향을 주는지 판정할 수 있는 구체적 조건**이다. 다만 U를 구하려고 모든 내부 raw flux를 매 Step 계산하면 절감 목적을 놓친다. 기존 outgoing limiter의 분석이며 그 자체의 신규성을 주장하지 않는다.

## 7. [C/D] 물질이 경계를 넘지 않아도 Geometry로 영향이 전달된다

[StateMath.glsl::effectiveLocalNormal](C:/Users/yonai/Documents/MDSS_Engine/Shaders/Simulation/Solver/StateMath.glsl:111)은 이웃 높이에서 Normal을 복원할 때 해당 State 채널 지원 여부가 아니라 texel 유효성과 macro normal 등을 검사한다. 반면 [Transport.glsl](C:/Users/yonai/Documents/MDSS_Engine/Shaders/Simulation/Solver/Transport.glsl:32)은 target 채널 지원 여부로 물질 수송을 제한한다.

따라서 다음은 코드가 허용하는 **구조적 반례**다(실제 asset 구성/실행은 하지 않음).

- 안쪽 Profile은 Ice 같은 적층 State를 지원하고 WaterFilm은 지원하지 않는다.
- 바깥 Profile은 WaterFilm을 지원하며, 안쪽과의 geometry 이웃 연결은 유효하다.
- 안쪽 적층이 달라지면 바깥 texel의 복원 Normal이 달라질 수 있다.
- Normal 기반 weight 또는 gravity drive가 활성이고 민감한 배치라면 바깥 texel들 사이의 물 이동이 달라질 수 있다.

이때 cut을 넘는 WaterFilm flux가 0이어도 외부 WaterFilm 결과가 달라질 수 있다. **동일한 물질 port 이력만으로 전체 State-Driven Geometry Coupling의 경계 응답을 규정할 수 없다.** 영향이 항상 생긴다는 뜻은 아니며, 실제 크기/중요성은 미검증이다.

필요한 geometry 정보는 내부 전체 높이일 필요는 없다. 외부에서 읽는 연산 stencil에 닿는 높이/위치/Normal/Concavity의 값 또는 검증된 범위가 후보이다. 15의 정적 LS 민감도는 이 범위를 연결하는 도구가 될 수 있다.

단, 현재 Geometry scheduler의 2-hop halo가 임의 block의 **전체 한 Step 경계 계약 반경**도 정확히 2라는 뜻은 아니다. target Concavity, 이웃 source의 전체 outgoing 배율, reaction/geometry 갱신 순서를 포함한 의존성 닫힘을 별도로 확인해야 한다. 여기서는 최소 반경을 확정하지 않았다.

## 8. [H] 다음 방법 후보 — 연산 의존성을 반영한 경계 계약

이것은 구현이 아니라 다음 분석의 명세다. 경계 source/관측마다 다음 정보가 충분한지 확인한다.

| 정보 | 필요한 이유 | 생략/축약할 수 있는 조건 |
|---|---|---|
| 방향·시점·채널별 실제 물질 이동 | Incoming 반응과 외부의 시간 의존 결과 | 고정 f·고정 관측에서 필요한 cohort만 상한으로 합칠 수 있음 |
| source available amount와 내부 raw 합의 범위 | limiter가 모든 outgoing을 함께 조절 | M≥S+U로 비활성 인증, 또는 output 구간 폭이 허용량 이하 |
| 외부 stencil에 닿는 형상 정보/범위 | 질량 이동 없는 Geometry 매개 영향 | 관련 height 기여 불변 또는 geometry→관측 영향이 검증된 허용량 이하 |
| 상태/형상/배율의 계산 시점 | 다른 Step의 cache를 섞으면 공통 flux 계약이 깨짐 | 동일 갱신 기준과 오차 장부를 명시적으로 유지 |

가능한 절차는 (i) 경계 응답에 영향을 주는 연산을 추출, (ii) branch별로 필요한 요약/범위를 결정, (iii) 충분조건을 만족하는 동안 내부 갱신 생략, (iv) 조건이 만료되면 필요한 정보만 갱신하는 것이다. 이것이 일반적인 dependency/interval 분석 이상의 새 방법이 되는지는 아직 모른다.

**중단 기준:** 필요한 요약을 갱신하는 데 내부 fine 계산과 같은 비용이 듦 / limiter·geometry 범위가 대부분 불확실 / 경계 band가 대부분의 영역을 차지함 / 기존 microgrid·port reduction·오차 제어 방법에 같은 정보를 주면 동일한 결과.

규칙적인 넓은 2D patch는 내부 면적에 비해 경계가 작을 수 있다. 하지만 현재 64-thread 그룹과 UV seam/비정규 graph가 그런 patch인지 확인한 것은 아니다. thread group 크기를 근거로 경계 비용이 작다고 주장하지 않는다.

## 9. 선행연구와 후보 판정

[P] 경계 flux 일치로 보존을 유지하는 방법은 이미 AMR의 기본 구조다. [AMReX 공식 FluxRegister 설명](https://amrex-codes.github.io/amrex/docs_html/AmrCore.html?highlight=fluxregister)을 확인했다. 따라서 공유 장부 자체는 기여가 아니다. 보존을 맞췄다는 것과 근사 결과가 가깝다는 것은 구분한다.

[P] [Smetana의 port/interface reduction](https://arxiv.org/abs/1808.02946)은 geometry 변화와 재사용도 다룬다. ‘경계 정보만 작게 남긴다’ 또는 ‘geometry-aware port’라는 이름만으로 신규성을 주장할 수 없다. [Rungger & Zamani의 compositional abstraction](https://arxiv.org/abs/1507.05014)도 subsystem의 오차 관계를 연결하는 선례다. 상세 확인 수준은 [[90_Research-Archive/Research-Notes-2026-10/90_Reference/07_Related-Work|R42–R44]]를 따른다.

현재 판정은 다음과 같다.

- **단순 α-bin block 합성:** 조건부로 올바른 식을 얻었지만, 동일 조건의 전체 영역 bound보다 느슨하므로 주력 구현안 보류.
- **Limiter·Geometry 의존성을 반영한 경계 계약:** 현재 코드에서 출발하는 더 구체적인 알고리즘 탐색 후보. 충분조건 일부를 유도했으나 저비용 갱신과 실제 필요성은 미입증.
- **방향2의 보호 편집:** geometry-only 영향은 ‘물질 흐름을 바꾸지 않으면 다른 현상이 보호된다’는 가정에 대한 반례로 활용 가능. 독립적인 편집 해법을 확보한 것은 아님.

이번 연구는 유망도를 일괄 상향한 결과가 아니다. **한 단순 확장안의 약점을 확인하고, 실제로 보존해야 할 경계 정보를 더 정확히 특정한 결과**다. 새로운 SIGGRAPH Contribution은 여전히 미확보이며, 현재 구현의 시스템 통합 판정을 바꾸지 않는다.
