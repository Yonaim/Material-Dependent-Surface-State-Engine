# Contribution을 위한 심화 추론과 입증 조건

작성: **2026-10-27 / Asia/Seoul**. 사용자 요청: “새 Contribution이 입증을 위해 가능한 모든 추론을 해봐”. 현재 선택한 방향 1·2·3에서 주요 논리 경로를 확장했다. 모든 가능한 아이디어를 소진했다거나 신규성을 증명했다는 뜻은 아니다.

범위: 코드 읽기·수학적 유도·온라인 1차 문헌 확인·문서 작성. **앱/GPU/빌드/수치 실험/학습은 미실행**, 제품 코드 변경 없음. HEAD `880af1ebcffe601f0bac27413cad94055ce92812`와 기존 작업 트리를 기준으로 한다. 아래 [D]의 증명은 명시한 이상적 산술·연산 조건에 대한 것이며 GPU 측정/기계 검증이 아니다. 기존 [U/C/E/P/D/H] 구분은 [[90_Research-Archive/Research-Notes-2026-10/00_Overview|Overview]]를 따른다.

## 1. 결론부터: 입증 가능한 범위가 세 층이다

1. **문제의 존재:** 특정 관측/압축 정보가 부족함은 조건부 반례와 식으로 보일 수 있다. 이번에 이 범위를 확장했다.
2. **방법의 성질:** 양수성·저장량 수지·특정 feature 적합도·보호 오차의 조건부 bound를 증명할 수 있다. 기존 정리의 적용과 새 정리를 구별해야 한다.
3. **연구 기여:** 기존 강한 방법보다 중요한 문제를 더 잘 해결한다는 주장은 신규성 검토와 실제 비교 증거가 필요하다. 1·2만으로 SIGGRAPH 기여가 완성되지는 않는다.

현재 구현의 판정은 여전히 시스템 통합에 가깝다. 이번 추론은 후속 후보의 정의를 바꾼다. 특히 방향 3을 **반응률 보정만이 아니라, 내부 이동으로 생기는 전환까지 보존하는 coarse 표현**으로 좁힐 근거가 생겼다. 이것은 새 해법의 성능/신규성 입증이 아니다.

## 2. 가장 직접적인 새 단서: 순유량이 사라져도 유입 반응은 남는다

### 2.1 현재 구현이 요구하는 정보

[C] [SurfaceSolverPass2.comp](C:/Users/yonai/Documents/MDSS_Engine/Shaders/Simulation/Solver/SurfaceSolverPass2.comp:145)는 `Current + Input + Incoming - Outgoing - Decay`와 별도로 **Incoming 자체**를 ReactionScratch에 저장한다. [SurfaceReaction.comp::reactionRequest](C:/Users/yonai/Documents/MDSS_Engine/Shaders/Simulation/Solver/SurfaceReaction.comp:18)의 `inflowFraction`은 이 실제 유입 장부를 사용한다. [Modular baseline의 동결 규칙](C:/Users/yonai/Documents/MDSS_Engine/Scripts/Research/Plans/modular-baseline-v1.json:141)과 [제작 pilot의 준비 코드](C:/Users/yonai/Documents/MDSS_Engine/Scripts/Research/authoring_pilot.py:32)에 Waterfilm→잔류 State의 해당 규칙이 있다. `IceReactionLab.SRProfile` 원본에 이 규칙이 있다고 혼동하지 않는다.

[D] 한 coarse 영역 B 안의 fine 이동량을 \(F_{ij}\ge0\), 외부 입력·Decay·다른 반응은 0, 유일한 전환은 Waterfilm의 Incoming 중 비율 \(0<f\le1\)을 immobile 잔류 State A로 보내는 규칙이라고 하자. Transport의 공급량 제한은 유효하고 반응 공급량 경쟁은 없다. 그러면 한 Step의 잔류 증가량은

\[
\Delta A_B=f\sum_{j\in B}\sum_i F_{ij}
=f\left(\sum_{i\notin B,j\in B}F_{ij}+\sum_{i,j\in B}F_{ij}\right).
\]

내부 이동은 B의 Transport 순수지에서는 상쇄되지만 **두 번째 항은 반응에서 상쇄되지 않는다.** 외부 입출력이 전혀 없어도 내부 물 이동은 흔적을 만든다. Incoming fraction은 1 이하이고 recipient의 post-transport 보유량은 Incoming 이상이므로 이 단일 규칙에는 추가 반응 limiter가 필요하지 않은 조건이다.

이 식은 단순 request의 연속시간 근사가 아니라, 위 제한 조건에서 **현재 Transport + inflowFraction의 한 discrete Step**에 대응한다. FP 오차·cache 불일치·생산 장면에서의 재현까지 증명한 것은 아니다.

### 2.2 모든 한 점 분포가 같아도 다른 결과: 네 texel의 반례

동일 면적·동일 Profile의 네 texel을 `1—2—3—4`로 연결한 고정 graph를 생각한다. Geometry/Gravity/Decay는 꺼 두고, 양방향 edge weight는 같고 양수다. Capacity C가 같고 saturation \(s_i=W_i/C\)의 차이만으로 이동한다고 하자. [Transport.glsl::rawFlux](C:/Users/yonai/Documents/MDSS_Engine/Shaders/Simulation/Solver/Transport.glsl:1)에 따라, saturation 차이 1인 edge의 이동량을 \(\lambda>0\)라 쓸 수 있다. \(2\lambda<C\)로 택하면 outgoing limiter가 활성화되지 않는다.

| 초기 saturation 배치 | 총 Waterfilm | 값의 전체 histogram | 내부에서 양의 이동이 생기는 edge | 내부 총 이동량 | 잔류 증가 |
|---|---|---|---|---|---|
| X=(1,1,0,0) | 2C | 1 두 개, 0 두 개 | 2→3 | λ | fλ |
| Y=(1,0,1,0) | 2C | 1 두 개, 0 두 개 | 1→2, 3→2, 3→4 | 3λ | 3fλ |

하나의 닫힌 coarse 셀로 묶으면 두 경우 모두 외부 boundary flux=0이다. 모든 위치 비의존 State 통계와 histogram, 정적 graph 자체가 같다. 그러나 총 잔류량은 다르다. 즉 **공간 배열을 버린 정확한 한 점 분포조차 충분하지 않다.** 같은 압축 입력을 받은 결정론적 모델의 두 잔류 예측 오차 중 적어도 하나는 fλ 이상이다(삼각부등식).

이는 코드의 graph 연산에 대한 이상화된 최소 반례다. 현재 Scene/UV mesh에서 이 네 texel graph를 만들고 실행한 것은 아니다. 실제 mesh에서는 추가 edge·경계·geometry·채널을 계측해 분리해야 한다.

동일 가중치·gravity OFF·limiter 비활성 조건에서는 내부 총 이동이 graph total variation \(\lambda\sum_{\{i,j\}}|s_i-s_j|\)에 비례한다. 임의 directed weight/geometry/limiter에서는 이 간단한 TV 식 대신 실제 directed flux 합을 사용해야 한다.

### 2.3 연구 질문을 어떻게 바꾸는가

단순한 `coarse mean + covariance`보다 **State와 edge 연결의 공동 정보, 내부 총 이동량, 실제 유입 전환**이 중요하다. coarse cell face의 순유량만 보존하는 수송 모델은 현재 규칙을 재현하는 데 정보가 부족하다.

이 반례는 **Geometry OFF에서도 성립**한다. 그러므로 이것만으로 State-Driven Geometry Coupling 특유의 새로운 문제가 입증됐다고 할 수 없다. 정적 edge 모델로 해결되는지 먼저 확인하고, 이후 State가 바꾸는 형상이 그 모델을 실제로 무너뜨리는 경우에만 동적 결합의 추가 해법을 주장한다.

하지만 반론도 강하다. ‘유입 1회당 f’라는 규칙은 fine hop 수에 의존한다. 실제 제작자는 이 의미를 유지하기보다 거리/시간 기반 규칙을 원할 수 있다. 그런 경우 표준적인 규칙 재정의가 더 적절하며, 원치 않는 격자 의존성을 보존하는 복잡한 알고리즘을 연구할 이유가 약하다. **고정 fine 모델의 기존 결과를 저비용으로 재현할 필요**와 **해상도에 독립적인 새 모델의 필요**를 먼저 구별해야 한다. 물리 부피 모델로 전환할 필요는 없다.

[P] 이동 중 누적량을 따로 다루는 개념 자체는 transition/impulse reward 모델에도 존재한다 [R22]. 이것이 MDSSP와 같은 모델이라는 뜻은 아니지만, ‘순변화와 경로상 누적 사건을 구분’하는 발상이 새롭다고 주장할 수 없다. 반응 수송의 미해결 fluctuation을 다루는 선행연구 [R23]도 추가 대조 대상이다.

## 3. 임계값 반응과 capped geometry의 공통 구조

[[90_Research-Archive/Research-Notes-2026-10/90_Reference/09_Analytical-Findings|이전 반례]]의 평균/분산 부족을 더 일반적으로 설명한다. 한 block의 면적 가중 평균을 E, Ice/면적을 i, Heat/면적을 h라 두자.

\[
M(t)=E[i(h-t)_+],\qquad
\bar r_{\rm melt}=kM(\tau),\quad k=0.5.
\]

[D] i≥0이고 가중 첫 모멘트가 유한하면 M은 t에 대해 감소·convex하고, 오른쪽 미분은 \(M'_+(t)=-E[i\mathbf1_{h>t}]\)다. 분포 미분의 의미에서 두 번째 미분은 **Ice로 가중된 Heat 분포**다. 일반적인 stop-loss/hinge transform의 가중 형태이며 새 수학이 아니다 [R14]. 전체 joint 분포나 공간 배열을 복원하는 식도 아니다.

한편 한 State의 capped 높이는

\[
\bar g(c)=\kappa E[\min(s,c)]
=\kappa\{E[s]-E[(s-c)_+]\}.
\]

따라서 현재 융해와 높이 cap은 모두 **경계 초과량의 평균**을 참조한다. ‘임의 차수의 모멘트를 추가’하는 대신, 선언 rule의 threshold와 Capacity 위치에서 필요한 hinge feature를 선택하는 것은 합리적인 후보 설계다.

### 3.1 제한적으로 얻을 수 있는 보장

Heat를 대표값 \(\hat h\)로 치환하되 같은 i를 유지하고 \(|h-\hat h|\le\delta\)이면, positive-part의 1-Lipschitz 성질에서

\[
|\bar r-\widehat{\bar r}|\le kE[i]\delta.
\]

같은 방식으로 \(|s-\hat s|\le\delta_s\)이면 capped 평균 높이 오차는 \(\kappa\delta_s\) 이하이다. i까지 비음수 값으로 근사하면 bound는 \(kE[|i-\hat i|(h-\tau)_+]+kE[\hat i]\delta\)로 쓸 수 있다. 이 bound는 초기 연산 관측에 대한 것이지 trajectory나 Flux 오차 보장이 아니다.

Heat bins가 τ에서 나뉘고 각 bin의 \(E[i\mathbf1_b]\), \(E[ih\mathbf1_b]\)를 정확히 보존하면 초기 융해 request는 정확히 복원된다. 그러나 시간 진행으로 bin 경계를 넘는 양과 mixed moments를 어떻게 갱신할지는 남는다. 조건부 통계와 closure 자체는 CMC 등의 선례 [R15]가 있다.

### 3.2 남는 후보와 쉽게 기각되는 주장

[H] 여러 rule과 cap을 읽어 **필요한 feature·분할 경계·허용 오차를 선택**하고, 대표 상태와 edge 정보를 함께 갱신하는 제한된 모델을 검토할 수 있다. 모든 rule에 대해 exact한 범용 압축을 주장하지 않는다. generalized mass action·여러 modifier·공급량 경쟁·시간 세분화를 포함하면 초기 request feature만으로 실제 finite-step extent를 보존하지 못한다.

정해진 threshold histogram이나 2/4-node 표준 quadrature로 충분하다면 이것은 기존법의 적용이다. ‘반응식에서 필요한 feature를 자동으로 뽑았다’는 구현 편의만으로 강한 Contribution이 되지 않는다.

### 3.3 현재 계수에서 융해의 형상 효과는 부호도 바뀐다

[C,D] `IceReactionLab`의 cavity=0 조건에서 world 요청 높이는 \(g(i,w)=0.035\min(i,4)+0.0063\min(w,2)\)다. Heat는 높이에 기여하지 않는다. 수송/입력/Decay를 분리하고 융해 extent/면적/시간을 ρ라 하면 cap 경계 밖에서

\[
\dot g=\rho\{-0.035\mathbf1_{i<4}+0.0063\mathbf1_{w<2}\}.
\]

- i>4, w<2에서는 **+0.0063ρ**: 숨은 초과 Ice가 줄어도 Ice 높이는 그대로이고 새 Waterfilm 높이가 더해진다.
- i<4, w<2에서는 **−0.0287ρ**: Ice 높이 손실이 Waterfilm 증가보다 크다.
- 두 채널 모두 cap 위이면 이 반응만의 순간 높이 변화는 0이다.

따라서 ‘얼음 융해량이 늘면 높이가 항상 감소한다’는 가정을 optimizer나 오차 추정에 넣을 수 없다. State-Driven Geometry Coupling의 민감도가 branch에 따라 바뀌는 구체적인 조건이다. 실제 수송을 켠 이후 높이/Flux 곡선은 별도 검증이 필요하다. artistic occupancy의 현 계산 결과이며 물리적 융해 법칙이나 새 현상으로 주장하지 않는다.

## 4. 양수 대표 상태의 존재는 보일 수 있으나 새 정리는 아니다

현재 fine samples \(x_j\)와 면적 가중치 \(\alpha_j\ge0,\sum\alpha_j=1\), 보존하려는 m개의 유한 feature \(\phi(x)\in\mathbb R^m\)를 둔다. 예를 들면 State 평균, 각 request, capped height다.

[D,P] \(v=\sum_j\alpha_j\phi(x_j)\)는 feature vectors의 convex hull에 있다. Carathéodory로 **기존 samples 중 최대 m+1개와 비음수 가중치**를 택해 같은 v를 표현할 수 있다. 상수 feature를 포함한 공간의 rank로 더 날카로운 bound를 쓸 수 있으며, finite-function cubature는 Tchakaloff 확장에 이미 포함된다 [R16].

따라서 ‘비다항 반응·형상 feature를 양수 가중치로 동시에 맞추는 작은 snapshot 표현’의 존재는 설명할 수 있다. 하지만 다음을 보장하지 않는다.

- 한 번 선택한 samples가 이후에도 같은 오차를 유지함.
- 실제로 m이 충분히 작음, 선택/갱신 비용이 fine보다 작음.
- 노드별 양수성만으로 공간 수송 수지와 incoming 장부까지 맞음.
- coarse 상태만으로 다음 대표 상태를 선택할 수 있음. fine 재조회가 매 Step 필요하면 실용적인 압축이 아님.

[P] Graphics의 An–Kim–James 2008은 특정 재질/형상에 맞춘 cubature와 runtime error estimation을 이미 제시했다 [R17]. Empirical Cubature [R18] 및 2026 adaptive-weight preprint [R19]도 존재한다. **‘feature 맞춤 양수 quadrature + 적응 가중치’만으로 최초성 주장은 불가**하다.

## 5. 실제 연구 방법으로 남는 방향 3의 최소 설계

[H, 미구현] 후보는 **반응과 실제 유입 전환을 보존하는 적응형 표면 coarse graph**다. 명칭은 임시이며 Contribution 문장이 아니다.

| 저장/계산 요소 | 필요한 이유 | 미해결 핵심 |
|---|---|---|
| coarse 총량과 소수의 양수 대표 State | 저장량·threshold/cap feature를 보존 | 독립 시간 갱신, 대표 상태 분할/합침 |
| 대표 State 사이의 edge 공동 정보 | §2의 같은 histogram/다른 배열을 구별 | 면적 가중치와 edge incidence 가중치는 다름. 임의로 같은 marginal로 놓을 수 없음 |
| 내부 이동 및 양방향 경계 이동 장부 | inflowFraction의 실제 Incoming 재현 | 현재값만 저장해도 다음 이동량의 예측은 닫히지 않음 |
| 공유 축적 형상에 따른 edge 갱신 | State-Driven Geometry Coupling 유지 | 평균 높이로 edge 기울기/연결을 복원할 수 없음 |
| 오차가 큰 부분의 microcell fallback | 임계값·경로 변화 때 표현 실패 처리 | 대부분 fine으로 돌아가면 비용 이점 소멸 |

첫 알고리즘 초안은 node feature를 근사하는 양수 압축, 내부/경계 flux의 계산, source별 **모든 outgoing을 합친** 공급량 제한, Incoming 기반 전환, 반응/형상 갱신, 필요한 영역의 분할 순서다. 동일 inventory를 여러 edge에서 중복 사용하지 않아야 한다. 기존 limiter·finite-volume 수지·AMR를 재사용한 부분은 신규성으로 세지 않는다.

제한적으로 확보할 수 있는 성질도 있다. 대표 node의 저장 총량을 Q로 두고 같은 F를 source에서 빼고 target에 더하면 전체 수송 수지는 상쇄된다. 각 node에서 \(\ell^TS=0\)인 reaction invariant를 지키고, 재압축 때 해당 선형 불변량과 총량을 feature로 보존하면 split/merge에서도 이를 유지할 수 있다. 공급량을 넘지 않는 flux/extent와 비음수 대표 상태는 양수성의 충분조건이 된다. 모두 기존 수지/convex 표현 원리이며, **수지를 맞춘다는 사실은 fine 분포·수송·외관의 정확성을 보장하지 않는다.** 실제 floating point와 전체 연산 순서 검증도 남는다.

중요한 한계: pair 정보를 추가해도 다음 edge 상태는 주변 이웃의 영향을 받으므로 고차 공간 의존성이 생긴다. 따라서 **임의 장면·모든 미래의 exact compact closure**를 목표로 삼지 않는다. 제한된 Profile/입력/시간 범위에서 품질–비용의 유용한 차이가 목표다.

비교군: 평균+단위 보정, 조건부 histogram/QMOM, feature-matching empirical cubature, edge-aware graph aggregation, 같은 예산의 microgrid/AMR, **기존 fine solver+Sparse를 유지하고 렌더 LOD만 바꾸는 방법**. 마지막 대안이 충분하면 시뮬레이션 coarse화 자체의 필요가 약하다.

가장 강한 Reject: “경로 정보를 가진 microgrid를 일부 남긴 것 아닌가?”, “기존 inflowFraction의 격자 의존성을 재현하는 데 왜 새 방법이 필요한가?”, “압축 관리가 fine Sparse보다 싸다는 근거는?”. 이 세 질문에 실측/정량으로 답하지 못하면 주력 기여로 채택하지 않는다.

## 6. 방향 2: 최적화 실패 전에 불가능을 판정할 수 있는 범위

### 6.1 보존량으로 얻는 보호 오차의 하한

[D] 닫힌 영역, 외부 물질 입력·sink·Decay 없음, Ice→Waterfilm→AbsorbedWetness의 화학량론에서 \(I+W+A=M\)가 고정이다. 두 rollout의 차이는

\[
\delta I+\delta W+\delta A=0.
\]

흔적 변화 \(\delta A=d\)를 요청하고 \(|\delta I|\le\epsilon_I,|\delta W|\le\epsilon_W\)를 보호하면 **필요조건은 \(|d|\le\epsilon_I+\epsilon_W\)**다. 가중 L2 보호 손실을 \(P=\sqrt{(\delta I/\sigma_I)^2+(\delta W/\sigma_W)^2}\)라 하면 Cauchy–Schwarz로

\[
P\ge |d|/\sqrt{\sigma_I^2+\sigma_W^2}.
\]

예를 들어 흔적 총량을 1 줄이면서 Ice와 물의 총량 변화를 각각 0.1 이내로 제한하는 요구는 이 조건 아래 불가능하다. 공간 분포나 Geometry를 바꿔도 이 총량 제약은 피할 수 없다. 외부 입력/sink가 허용되면 그 budget을 포함해 다시 계산해야 한다. **기존 U-input은 Waterfilm 입력을 허용하므로 이 닫힌 예를 모든 U-input 과제에 적용하면 안 된다.**

### 6.2 선언 rule로 만드는 도달 가능성의 바깥쪽 근사

reaction stoichiometry S, graph incidence D, 허용 입력 B를 이용해 시간별 장부를

\[
q_{n+1}=q_n+D f_n+S\xi_n+B u_n-d_n,
\qquad f_n,\xi_n,q_n\ge0
\]

로 놓을 수 있다. 실제 단계별 Input/Transport/Reaction 순서와 overflow/Decay를 표현하거나 충분히 느슨하게 포함하고, protection·input budgets를 더한 선형 제약으로 actual trajectory 집합의 **superset**을 만든다. rate/geometry 조건을 생략하면 실제보다 자유로운 수송·반응을 허용한다.

그 superset도 infeasible이면 actual 과제는 불가능하다. feasible이면 실제 kinetics·threshold·geometry·시간 순서 때문에 여전히 불가능할 수 있다. 변수 f/ξ는 실제 flux/extent의 누적량이지 자유 조작이 아니다. 수치 solver의 infeasible 표시를 인증으로 쓰려면 dual residual/허용오차 또는 검증 가능한 certificate가 필요하다. float roundoff·clamp 보정량까지 포괄하지 않은 장부는 제품의 모든 실행에 대한 인증이 아니다.

[P] 이는 Petri-net state equation/CEGAR [R20] 및 기존 수지 기반 최적화와 가까운 접근이다. 선형 장부, Farkas certificate, 반례에 의한 refinement 자체를 새 기여라고 하지 않는다.

### 6.3 연구 후보로 남기는 범위

[H] **보호 요구의 충돌을 설명하고, 가능한 보상 입력의 최소 범위를 찾은 뒤 실제 coupled solver로 검증하는 편집 방법**을 검토한다. 결과는 (i) 검증된 편집 해, (ii) 제한된 가정에서의 불가능 certificate, (iii) 미해결/예산 소진을 구별한다.

공간–시간 의존 graph의 경로 밖은 보존될 수 있다는 사실도 표준 프로그램 slicing이다. threshold 아래 gradient=0만으로 경로를 삭제하면 유한 편집을 놓친다. Geometry·smoothing·전체 시간 간격의 의존성을 포함해야 하며, 실제 coupling의 halo 반경을 임의로 1-hop이라 두지 않는다.

강한 Baseline은 전역 bounded SQP/multi-start/derivative-free **+ 같은 수지 사전 검사**다. 그 사전 검사를 우리 방법에만 주고 우위를 주장하지 않는다. 실제 새 기여 후보는 비교적 작은 조작 집합으로 보호를 지키며 유효한 event 전환을 찾는 계산 방법과 비용 이점이다. 아직 그 방법과 이점은 미확보다.

## 7. 방향 1: 후속 probe가 줄 수 있는 것과 줄 수 없는 것

### 7.1 한 texel에서는 모호성을 단순한 probe로 풀 수 있다

[D] 같은 snapshot을 복제해, 각 복제본에 서로 다른 Heat/면적 입력 p₁,p₂를 즉시 더한다고 하자. i>0, 두 경우 모두 threshold 위, 아직 수송/냉각/공급량 제한이 작동하기 전 초기 request/면적/시간을 관측한다.

\[
r(p)=\tfrac12 i(h+p-\tau),\qquad
i=\frac{2(r(p_2)-r(p_1))}{p_2-p_1},\quad
h=\tau-p_1+\frac{2r(p_1)}i.
\]

이것은 계산상의 단일 texel 식별성이다. 영상으로 r을 정확히 측정할 수 있다는 뜻이 아니며, 같은 상태 복제 없이 연속으로 두 pulse를 주면 i,h가 바뀌므로 식이 성립하지 않는다. finite-step reaction과 노이즈, 공간 평균에서는 추가 조건이 필요하다.

또한 MDSSP 내부에는 q가 이미 저장돼 있다. 이 연구를 ‘시뮬레이터도 모르는 State를 발견’하는 것으로 포장할 이유가 없다. 문제는 **사용자의 외관 목표가 향후 거동을 충분히 지정하지 않는 것**이다. probe는 제작 의도를 추가로 기술하는 수단이다.

### 7.2 유한 probe로 모든 미래를 보장할 수 있는가

일반적으로 불가하다. 관측 y가 같아도 다른 미래가 가능하며, 모든 미래 입력에 대해 관측이 같은 상태만 합칠 수 있다는 조건은 behavioral equivalence/lumpability와 관련된 기존 개념이다 [R21/R24].

제한된 probe parameter 공간에 δ-net이 있고 response 차이 함수가 L-Lipschitz이며 모든 표본의 오차가 ε 이하이면 sup 오차≤ε+Lδ라는 표준 bound를 쓸 수 있다. 하지만 현재 stepAbove/stepBelow modifier, Geometry fallback, adaptive substep 경계에 대해 그러한 전역 L을 확보한 것은 아니다. 단지 몇 pulse에서 맞았다는 이유로 모든 미래 반응을 보장하지 않는다.

전체 augmented state와 입력이 같으면 deterministic forward의 미래도 같은 것은 자명하다. 따라서 ‘모든 State를 보존’보다 적은 제약으로 제작자가 중요한 미래만 보존하는 것이 유용한지 비교해야 한다. **참조 State 거리 penalty/constraint**도 주 Baseline에 넣는다.

방향 1의 단독 가능성은 여전히 낮다. adaptive probe selection을 추가해도 기존 experimental design·multiobjective control과 겹친다. 방향 2의 목표·평가로 쓰는 것이 우선이다.

## 8. 한 Step의 적합도에서 장시간 기여로 넘어가는 데 필요한 것

압축/재구성한 상태를 같은 공간에서 비교할 수 있고, 해당 영역에서 full Step F가 L-Lipschitz, coarse 근사/재구성의 한 Step defect가 ηₙ 이하라면

\[
e_{n+1}\le Le_n+\eta_n,\qquad
e_N\le L^Ne_0+\sum_{j=0}^{N-1}L^{N-1-j}\eta_j.
\]

이는 표준 오차 누적식이다. **현재 MDSSP 전체에 이 조건을 증명한 것은 아니다.** 작은 height 오차·request 오차가 곧 작은 상태 오차라는 주장을 대신할 수 없다. Geometry 정규화의 비퇴화, 입력/State bounds, 시간 분할, discrete event, 내부 이동 장부의 영향까지 필요하다. L이 크거나 전역 bound가 지나치게 느슨하면 실용적 보장은 못 된다.

새 이론을 주장하려면 기존식의 재서술을 넘어, 실제 MDSSP 연산에 대해 계산 가능한 충분조건과 쓸 만한 bound를 제시해야 한다. 그렇지 않으면 이론 보장 대신 명확한 제한·검증 범위·실패 감지를 갖춘 empirical 방법으로 보고한다.

## 9. 후보의 우선순위와 입증 계획

| 후보 | 현재 가능성 평가 | 논문으로 만들기 위한 실질적 새 부분 | 아직 빠진 결정적 증거 |
|---|---|---|---|
| 방향3: 반응·내부 이동·공유 형상을 함께 보존하는 coarse 계산 | **알고리즘 탐색 우선순위 1. 문제 근거는 가장 구체적, 성공 가능성은 미확정** | 표준 node-distribution/graph/AMR보다 작은 독립 갱신 표현으로 같은 오차를 유지 | 새 갱신법, 실제 제작상 영향, fine Sparse/표준 closure 대비 전체 비용 |
| 방향2: 도달 가능성과 보호 조건을 반영한 편집 | **목적 적합성 높음, 방법 기여는 중간 이하의 미입증 후보** | 유한 event 전환과 보상 범위를 효율적으로 선택하고 full forward에서 보호 유지 | nontrivial feasible witness, 강한 일반 optimizer 대비 성공률/비용, 유용한 인증 범위 |
| 방향1: 진행+후속 반응 목표 역설계 | **독립 기여 낮음** | 같은 intent를 더 적은 제약/probe로 안정적으로 지정하는 특별한 방법이 있을 경우 | 단순 state/probe loss 최적화보다 중요한 차이 |

여기서 유력도는 논문 채택 확률이 아니다. 방향3의 문제 근거가 강화됐다는 이유로 신규성이 확보됐다고 올리지 않는다. 1+2의 제품 목적 적합성과 3의 계산 문제 명확성을 구별한다.

### 최초로 반증해야 할 세 가설

- **H3-E:** 실제 fine 결과를 유지할 제작 필요가 있고, 내부 이동 장부를 버린 coarse 모델의 잔류/형상 차이가 중요하다. 규칙 재정의·표준 microgrid·fine Sparse로 충분하면 기각.
- **H3-C:** 선언 반응/형상 feature와 소수 edge 정보가 독립적으로 갱신되며 메모리·총 비용 이점을 갖는다. 매 Step fine oracle·과도한 node 수·자주 전체 refinement가 필요하면 기각.
- **H2-P:** 실제 보호 편집에서 일반 optimizer가 중요한 구조적 어려움을 겪고, 구조를 이용한 방법이 같은 조작/오차/예산에서 이를 줄인다. 수지 사전 검사만 더한 표준법으로 충분하면 기각.

아직 어느 가설도 실측으로 검증하지 않았다. 자동으로 구현을 시작하거나 중지된 실험을 재개하지 않는다. 그동안은 표준 closure의 정확한 갱신식, coarse graph의 정보/메모리 요구, 보호 과제의 feasible witness를 종이 위에서 더 좁힐 수 있다.

## 10. 지금 논문에 쓸 수 없는 문장과 조건부 문장

| 피해야 할 주장 | 지금 가능한 정확한 표현 |
|---|---|
| 다중 State와 Geometry Coupling을 처음 제안했다 | 구현·선례 대조가 있으며 최초성은 지지되지 않음 |
| 모든 모멘트를 보존하면 수송/반응을 재현한다 | 공간 배열을 버린 한 점 분포는 §2의 모델에서 충분하지 않음 |
| 양수 대표 상태를 사용한 새 수학을 제시했다 | 기존 convex/cubature 정리를 feature 선택에 적용할 수 있음 |
| 보호 편집의 불가능성을 일반적으로 판정한다 | sound relaxation이 infeasible인 경우만 제한적으로 배제 가능 |
| future-aware 역설계로 모든 후속 거동을 보장한다 | 지정된 probe/시간/조작 범위에서만 검증할 계획이며 아직 미실행 |
| SIGGRAPH Contribution이 입증됐다 | 코드 기반 반례와 구체적인 후보·입증 조건을 확보했지만 새 해법/우위는 미입증 |

문헌 원문 접근 수준·실패는 [[90_Research-Archive/Research-Notes-2026-10/90_Reference/07_Related-Work|R14–R24]]에 기록했다. 이 문서는 새로운 실험 결과가 아니므로 PERF 기록을 생성하지 않는다.
