# 방향 3 — 혼합·경로 정보를 유지하는 coarse 표현

마지막 갱신: 2026-10-27. [[03_Development/07_Research-Directions-123|최초 통합 검토]]에서 분리한 후속 연구 정본이다. 이 파일의 내용은 제안·수식 분석이며 새 구현/실험 결과가 아니다. 로컬 앱·GPU·빌드 실행 중지를 유지한다.

공통 근거는 [[90_Research-Archive/Research-Notes-2026-10/20_Solver-Semantics/10_Forward-Model-and-Controls|forward 모델]], 문헌 출처는 [[90_Research-Archive/Research-Notes-2026-10/90_Reference/07_Related-Work|문헌 확인 수준]], 이후 연구는 [[90_Research-Archive/Research-Notes-2026-10/90_Reference/09_Analytical-Findings|분석 노트]]를 따른다.


## 1. 현재 코드에서 직접 유도되는 최소 반례

[C] `IceReactionLab.SRProfile`의 `water_cooling`은 Heat에 비례하는 rate coefficient 0.5와 Waterfilm의 linear modifier(scale=1)를 사용한다. `SurfaceReaction.comp::reactionRequest`를 대입하면 local request는 \(0.5 H_i W_i/a_i\)다. \(a_i\)는 기준 면적 대비 texel 면적이고, 반응이 사용하는 정규화는 **State/면적**이다. 표시용 State/Capacity와 혼동하지 않는다.

[D] 동일 면적 셀에서 \(h_i=H_i/a_i, w_i=W_i/a_i\)라 하면 단위 면적당 초기 냉각률은 \(0.5h_iw_i\)이고

\[
\overline r=0.5(\overline h\,\overline w+\operatorname{Cov}(h,w)).
\]

두 미세 셀을 coarse 한 셀로 합친다고 하자.

| 미세 분포 | 셀 1의 (h,w) | 셀 2의 (h,w) | 평균 (h,w) | 평균 초기 냉각률 |
|---|---|---|---|---|
| 분리 | (2,0) | (0,2) | (1,1) | 0 |
| 혼합 | (1,1) | (1,1) | (1,1) | 0.5 |

동일 Profile·평면에서 Transport/Decay/Geometry 변화를 끄고 이 local reaction을 분리하면, **같은 coarse 총량만으로 두 초기 반응률을 동시에 재현할 수 없다.** 이 계산은 실제 구현 식의 대입이며 새로운 GPU 실험 결과가 아니다. 시간 적분·공급량 제한이 활성화된 장시간 결과가 위 단일률과 같다고 주장하지 않는다. 분리된 재료가 실제로 접촉/혼합되기 전 반응하는 coarse 오차의 단서다.

이것은 1·2보다 문제 존재의 근거가 구체적이다. 그러나 평균의 곱과 곱의 평균 차이, covariance closure 자체는 오래된 문제다. [R9]는 segregated initial conditions의 coarse diffusion–reaction에서 단순 rate 보정 이상이 필요함을 다룬다. **이 반례를 발견한 것만으로 신규성은 없다.**

[D] 후속 분석은 두 가지를 더 분리했다. (1) Heat 평균·분산과 모든 State 이차 모멘트가 같은 여섯 셀의 두 분포에서도 현재 ramp 융해의 초기 평균 request는 1/16과 1/24로 다르다. (2) Capacity clamp 때문에 평균 저장량에서 만든 높이와 fine 높이의 평균도 다르다. 각각 threshold 분포와 capped occupancy 정보의 필요성을 보이는 조건부 반례이며, 새 정리나 GPU 결과가 아니다. [[90_Research-Archive/Research-Notes-2026-10/90_Reference/09_Analytical-Findings#5. 방향 3A: 모든 이차 State 모멘트도 ramp 반응에는 부족한 반례|후속 분석 §5–6]]에 식과 제한을 기록했다.

## 2. ‘해상도 독립’ 대신 분명한 목표

고해상도 MDSSP의 discrete forward \(\Phi_h\)를 기준 모델로, q 총량을 합치는 restriction R을 둔다. 물리적 정답이나 아직 유도하지 않은 연속 PDE를 기준으로 가정하지 않는다. coarse 예측기 \(\widehat\Phi_H\)의 목표는 \(R\Phi_h^m(q)\)를 관측량/보존식/비용 범위에서 근사하는 것이다.

[D] 어떤 x,y에서 Rx=Ry이지만 \(R\Phi_h^m(x)\ne R\Phi_h^m(y)\)이면, 평균만을 입력으로 받는 결정론적 coarse 모델은 둘을 동시에 정확히 맞힐 수 없다. norm에서 두 fine 결과의 거리가 d이면 같은 coarse 출력의 두 오차 중 적어도 하나는 d/2 이상이다(삼각부등식). 이는 일반적인 정보 손실의 성질이며 새 정리로 주장하지 않는다. Rx에는 coarse 모델에 허용된 모든 정적 형상/재질 정보도 포함해야 한다.

따라서 연구할 것은 ‘계수 하나를 해상도에 맞게 보정’보다 **어떤 추가 상태 z를 저장하고 어떻게 진화시키면 중요한 fine 결과를 저비용으로 근사하는가**다.

## 3. 가능한 표현과 명확한 한계

| 후보 표현 | 기대 역할 | 해결되지 않는 문제 |
|---|---|---|
| 필요한 반응 쌍의 covariance/mixing fraction | Heat–Waterfilm처럼 곱 형태의 초기 평균 반응률 보정 | covariance의 시간 진화도 closure 필요. threshold/ramp·다중 소비 경쟁은 같은 이차 모멘트만으로 일반적으로 닫히지 않음 |
| 소수의 양수 quadrature 상태와 면적 가중치 | 혼합/분리·임계값 일부를 평균보다 자세히 보존 | 같은 통계라도 공간 연결이 다르면 flux를 구별하지 못함. node 수를 늘리면 비용 증가 |
| coarse 경계의 소수 통과 특성/국소 그래프 | 좁은 홈·장벽의 통과와 State 분포 상관 반영 | 고정 지형의 사전 conductance만으로 State가 바꾸는 형상을 모두 처리할 수 없음 |
| 필요한 영역만 microcell 사용 | compact closure가 실패하는 곳을 정확하게 처리 | 기존 AMR/microgrid와 다를 수 있음. 결국 대부분을 세분화하면 compact 표현 이점 사라짐 |

이 표는 구현 제안이며 기존 MDSSP 기능이 아니다. 모든 State 쌍의 covariance와 모든 세부 연결을 저장하는 것은 피한다. 반응 graph가 실제로 참조하는 쌍만 보존하는 범위도 지표로 검증해야 한다. 기존 chemistry reduced closure와 hydrology subgrid 방식의 단순 적용이면 기술 개선으로 한정한다.

[P] [R10–R11]에는 subgrid 지형에서 수위에 따른 storage/통과 특성 또는 cell/cell-face 평균화를 쓰는 선례가 있다. 따라서 ‘높이 평균 대신 경계 정보를 저장’도 독창성으로 가정하지 않는다. 동적 다중 State 축적에서 어떤 새 갱신이 필요하고 비용 대비 무엇을 유지하는지가 후보다.

[P] 추가 확인한 DQMOM-IEM 원문 서론 [R12]과 QBMM 출판사 요약 [R13]은 다중 scalar의 비선형 반응을 가중 대표 상태로 다루는 강한 선례다. 따라서 quadrature를 새 아이디어로 취급하지 않는다. 반응 request별 feature와 capped occupancy를 보존하는 표현은 탐색 후보지만, 그 feature의 시간 진화는 다시 closure를 요구한다. fine oracle 없이 갱신하는 방법과 표준 quadrature/microgrid 대비 이점은 아직 없다.

## 4. 단계와 Baseline

**3A: 반응부터 분리.** 알려진 분리/혼합, Heat threshold 근처의 분포, 공급량 경쟁을 고정 평면에서 비교한다. 기준은 fine operator를 면적 합한 결과다. scalar coarse/단위·dt 보정, best-fit scalar rate, 표준 covariance 보정, 2/4-node positive quadrature, 실제 microgrid를 대조한다. fine에서 매 Step 읽은 covariance를 쓰는 oracle은 표현 상한 진단이며 실용 방법으로 계산하지 않는다.

**3B: 수송만.** Reaction OFF에서 같은 coarse 정보/높이 통계를 갖지만 연결이 다른 홈/장벽을 구성한다. subgrid conductance, cell-face 자료, microgrid/AMR를 대조한다. 정적 지형 사전 계산만으로 충분하면 새 dynamic closure 주장을 하지 않는다.

**3C: 결합.** 3A/3B의 어려움이 확인된 경우에만 State 축적이 통과 특성과 혼합을 바꾸는 문제로 확장한다. Reaction ON/OFF × Geometry 동적/고정의 factorial 대조로 결합 항의 필요성을 확인한다. 세 요소가 있다는 이유로 각각의 baseline을 생략하지 않는다.

초기 범위는 한 평면/한 Profile·Ice/Waterfilm/Heat(+잔류)와 단일 coarsening factor다. 실제 문제 확인 뒤 다른 입력 패턴·기울기·시간 간격/해상도와 한 미사용 형상으로 넓힌다. Bunny seam 누락이나 고해상도 미수렴을 coarse 모델의 오차로 잘못 흡수하지 않는다. UV 재분할·물체 scale·normal 적분 오차는 별도 요인으로 분리한다.

**평가:** 제한한 State량·분포의 trajectory error, 누적 반응 extent, 경계 통과량/도달 시점, 목표 면적·모양, 비음수·알려진 물질 불변량, 메모리·전처리/학습/추론 총 비용. 채널 숫자를 모두 더해 물질 보존이라고 하지 않는다. fine 모델이 물리적 정답이라는 주장도 하지 않는다.

**중단 기준:** 단위/거리 보정 또는 표준 closure로 충분 / 효과가 fine 해상도를 올리면 사라지는 기준 오류 / mixing 정보가 실제 외관·진행에 중요하지 않음 / compact 모델이 microgrid보다 손해 / 매 Step fine oracle이 필요 / 계수·mesh별 대규모 재학습으로 재사용 이점 상실.

## 5. `inflowFraction`은 별도로 다룰 문제

현재 유입 비율 f는 실제 Incoming에 적용된다. 완전한 일방향 transfer를 m번 겪는 단순 예에서 남는 양은 \((1-f)^m\)이다. 이 예를 일반 MDSSP의 전체 흡수율 공식으로 쓰지 않는다. 부분 flux·되돌아오는 흐름·시간 간격·지형에 따라 관계가 다르다.

‘유입 1회당 비율’이 의도한 의미라면 그 자체가 버그는 아니다. 단위 거리/체류 시간당 효과를 의도했다면 rate/distance 기반 재정의가 필요할 수 있다. 이 **규칙의 단위 문제**와 위 **fine 혼합 정보의 손실**은 서로 다르다. 표준적인 지수 감쇠/면적·거리 보정으로 전자가 해결되었다고 후자의 closure 문제까지 해결했다고 하지 않는다.

## 6. 추가 추론: histogram과 경계 순유량만으로도 부족하다

[[90_Research-Archive/Research-Notes-2026-10/30_Deep-Analysis/11_Contribution-Proof-Obligations#2. 가장 직접적인 새 단서: 순유량이 사라져도 유입 반응은 남는다|심화 추론 §2]]에서 네 texel chain의 (1,1,0,0)/(1,0,1,0)을 비교했다. 같은 histogram·고정 graph·닫힌 coarse 영역이지만 내부 이동량은 λ/3λ, 단일 inflowFraction의 잔류 생성량은 fλ/3fλ다. 현재 연산식의 제한 조건에서 유도한 discrete 한 Step 반례이며 실제 Scene/GPU 재현은 미실행이다.

따라서 소수 대표 State만으로 충분하다고 가정하지 않는다. edge 공동 정보·내부 총 이동 장부와 그 독립 갱신이 후보이며, 단순한 graph/microgrid 또는 의미상 적절한 규칙 변경으로 충분하면 새 coarse 기여를 추진하지 않는다. hinge feature·양수 cubature의 존재, 보존성 조건, 실제 새 갱신법이 없는 부분도 심화 추론에 구분했다.

