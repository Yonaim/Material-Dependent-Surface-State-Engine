# 실행 없는 연구 — 방법 초안, 돌파 지점, 중단 조건

작성: **2026-10-27 / Asia/Seoul**. [[90_Research-Archive/Research-Notes-2026-10/30_Deep-Analysis/12_Exact-Submodels-and-Limits|최소 모델·한계 유도]]의 후속 방법 명세다. **아래 방법은 제안이며 제품에 구현하거나 실험하지 않았다.** 로컬 실행 중지 유지. 사용자가 제외한 축적 순서/층 표현은 다시 제안하지 않는다.

## 1. 이번에 바꾸는 질문

‘MDSSP의 모든 기능을 더 일반적으로 만들자’는 목표는 기여를 흐린다. 이제 두 질문을 분리한다.

1. **방향3:** 이미 아는 coarse 평균이 아니라, 아직 일어나지 않은 반응·이동 결과를 만드는 내부 상태를 얼마나 작게 유지할 수 있는가?
2. **방향1+2:** 사용자가 보호하려는 진행·후속 응답을 명시했을 때, 어떤 변경은 허용되고 어떤 변경은 반드시 다른 결과를 깨뜨리는지 계산으로 설명할 수 있는가?

두 축은 ‘향후 결과에 필요한 정보’라는 공통 관점이 있지만, 이를 하나로 묶었다는 사실은 기여가 아니다. 한 방법에서 성과가 나기 전 두 논문 분량의 시스템을 동시에 구현하지 않는다.

## 2. 후보 A — 내부 반응 잠재량을 유지하는 적응형 block 모델

### 핵심 설계

[[90_Research-Archive/Research-Notes-2026-10/30_Deep-Analysis/12_Exact-Submodels-and-Limits#2. 두 texel에서 정확히 닫히는 ‘남은 잔류 생성량’|정확한 두 texel 유도]]를 출발점으로 한다. 모든 histogram을 저장하는 대신 다음을 저장한다.

- 보존할 State 총량.
- 외부와 접촉하는 port 상태/양방향 flux.
- 내부의 아직 소멸하지 않은 mixing/transport modes.
- 각 mode가 남길 수 있는 잔류 반응량 및 오차 상한.
- threshold/cap/geometry 변화로 기존 mode 모델이 유효하지 않게 되는 조건.

두 texel에서는 p가 독립 갱신되며, 닫힌 미래에서 총 잔류 오차를 제한할 수 있다. 일반 block에서는 이런 비음수 잔여량/상한을 구성할 수 있는지가 핵심 미해결 부분이다. ‘edge마다 p를 넣고 더한다’는 방식은 shared inventory 이중 계상 때문에 정당화되지 않는다.

추가로 [[90_Research-Archive/Research-Notes-2026-10/30_Deep-Analysis/12_Exact-Submodels-and-Limits#2.5 일반 graph: Geometry가 변해도 남는 제한적 상한|닫힌 graph bound]]는 saturation-only 수송·유입 전환·충분한 dt 아래 동적 Geometry가 계수를 바꿔도 미래 잔류량을 B=M−s_min·ΣCapacity로 제한한다. 이는 **약한 근거로 시작하는 새 압축기보다, 먼저 인증 가능한 near-equilibrium 구간의 내부 계산을 생략하는 방법**이라는 대안을 준다. 다만 열린 경계/다른 반응에서 인증이 깨지고 최소 saturation=0이면 매우 느슨하다. 알려진 maximum principle의 응용이며 새 Sparse 기여를 확보한 것은 아니다.

### 가장 좁은 알고리즘 초안 [H]

1. 최초 fine 상태에서 disjoint block과 port를 정의하고, block 총량/내부 상태/보호 관측을 계산한다. 이 비용은 포함한다.
2. 정적 transport와 단일 inflow 전환부터 시작한다. 각 block의 내부 업데이트를 signed mode 또는 작은 positive compartment graph로 표현한다.
3. 외부 flux는 source inventory에서 한 번만 차감하고 target의 Incoming 장부에 한 번만 기록한다. 내부 flux의 전환과 boundary 유입 전환을 중복하지 않는다.
4. 내부 mode는 정해진 국소 식으로 갱신한다. fine 재조회를 상시 요구하는 표현은 후보에서 제외한다.
5. 남길 수 있는 관측 오차의 상한이 허용량보다 작을 때만 mode를 제거한다. 이후 port input이 mode를 재활성화할 수 있으므로 입력 분포 정보를 유지하거나 block을 분할한다.
6. 동적 Geometry를 추가할 때는 mode에 반영된 **잔류 위치·signed contrast·cap 상태**로 edge를 계산할 수 있는지 확인한다. 그렇지 않으면 이미 가진 coarse 정보에서 모르는 부분을 복원했다고 가정하지 않고 refinement/불확실성을 선언한다.

### 이번에 드러난 중요한 위험: refinement는 잃은 정보를 복구하지 않는다

단지 m,p,a만 남긴 뒤 다시 fine으로 나눠도 잔류 위치와 전체 State 분포를 알 수 없다. 현재 축소값에서 임의로 fine을 재생성하고 이를 정답 fallback이라 부를 수 없다.

가능한 선택은 (i) fine checkpoint를 보관하고 필요 시 입력 이력으로 replay, (ii) coarse 정보와 일치하는 fine 집합을 보관하며 오차를 제한, (iii) detail을 남겨 메모리 절감 대신 연산만 절감, (iv) 근사 reconstruction의 오차를 별도 계상이다. 모두 비용/제약이 있다. checkpoint+replay도 fine 비용을 미룬 것이며 공짜가 아니다.

### 기존법과 경쟁하는 정확한 지점

[P] memory ROM [R25], positive reduction [R32], reward-sensitive abstraction [R31], cubature [R17–R19]는 이미 존재한다. 남는 후보 차이는 **State가 edge geometry를 바꾸고 Incoming이 반응을 발생시키는 모델에서, 미래 누적 반응의 잔여 오차를 기준으로 내부 상태를 유지/삭제하는 구체적 방법**이다. 현재 이 전체 방법은 미완성이다.

Baseline: 같은 크기의 positive compartment graph, node/edge quadrature, microgrid/AMR, fine Sparse, geometry frozen vs updated, mode 없는 모델. 표준법에도 Incoming ledger와 같은 초기 정보/허용 관측을 준다. Reaction을 일부러 빼서 약한 비교군을 만들지 않는다.

**기각:** 중요한 block에서 내부 상태 수가 fine 수준 / 모든 port 입력 뒤 replay / geometry 복원 비용이 압축 이득을 소멸 / fine Sparse가 충분 / 고정 hop 반응의 결과를 유지할 제작 필요가 없음.

## 3. 후보 B — 보호 조건으로 선택하는 축소 모델과 편집

### 목적

State 전체를 작게 재현하는 대신, 사용자가 고정한 **편집 목표·보호량·허용 후속 입력·시간 구간**에 필요한 정보만 유지한다. 방향1은 여기서 미래 응답을 지정하는 인터페이스/평가 역할이다.

계약을 \(\mathcal C=(E,P,\mathcal U,H,\epsilon_E,\epsilon_P)\)로 쓴다. E는 바꿀 관측, P는 보호 관측, U는 허용 입력, H는 유한 시간이다. 모델 전체의 보편 보장 대신 해당 계약 안의 성공/실패를 주장한다.

### 방법 초안 [H]

1. 보존량과 입력 budget으로 명백히 불가능한 요구를 제외한다. 동일 사전 검사를 Baseline에도 준다.
2. reaction·height cap·geometry·transport·Incoming ledger를 포함한 의존 graph에서 목표/보호 관측에 닿는 경로를 잡는다. 현재 gradient=0만으로 경로를 지우지 않는다.
3. 허용 조작의 범위 안에서 threshold/cap을 넘을 가능성과 margin을 계산한다. 알려진 불연속 경계는 별도 event 후보로 취급한다.
4. 경계에서 멀리 떨어진 영역은 기존 constrained optimizer/ROM으로 처리한다. 경계 근처만 유한 event 전환·추가 조작 support·더 세밀한 모델을 검토한다.
5. full forward 검증 또는 sound enclosure로 보호 허용오차를 확인한다. 검증 불가를 ‘보호됨’으로 바꾸지 않는다.

편집에 필요한 제어 영역과 정확히 재계산해야 할 영역은 다를 수 있다. 전체 adjoint/forward 비용, event 후보 수, 실패 replay를 포함해야 한다.

### 이론적 바탕과 새로 해야 할 부분

[P] goal-oriented ROM은 최적 설계/제어/역문제에 이미 사용되고 [R27], DWR 기반 적응형 ROM도 있다 [R28]. spacetime editing과 재질 최적화/감축의 결합도 선례 [R30]가 있다. 따라서 ‘보호 지표를 loss에 넣고 중요 영역을 정밀 계산’만으로는 새 기여가 아니다.

실질적 새 해법이 될 여지는 **reaction의 threshold·형상 cap·유입 전환의 의존성을 이용해, 강한 일반 최적화가 놓치거나 비싸게 찾는 유한 편집을 더 작은 범위에서 찾는 방법**에 있다. 현재는 그러한 과제의 중요성도, 새 방법의 우위도 미확인이다.

Baseline: bounded SQP+다중 크기 FD/AD, multi-start, derivative-free, 같은 보존 사전 검사, 기존 goal-oriented ROM. 조작이 적으면 전역 grid/search도 강한 대조가 된다. 모든 후보가 같은 입력 bounds를 써야 한다.

**기각:** 작은 전역 optimizer가 충분 / 보호를 거의 하지 않아야 편집 가능 / event 분기가 폭발 / 실제 목표가 단순 State penalty로 충분 / geometry 경로를 포함해도 성능/성공률 차이가 없음.

## 4. 후보 C — 편집 가능 범위를 설명하는 제한적 인증

이것은 B의 보조 기능이 될 가능성이 크고, 독립 주력 후보로 우선하지 않는다.

### 세 가지 결과를 분리한다

1. **검증된 해:** 허용 입력으로 목표/보호를 만족하는 실제 rollout 또는 한정된 수학 모델의 witness.
2. **조건부 불가능:** sound outer approximation의 infeasibility, 또는 수지/형상 branch 하한에 의해 불가능.
3. **미해결:** 탐색 실패, 수치 예산 소진, enclosure가 너무 넓음. 불가능과 다르다.

현재 문서의 닫힌 물질 수지 하한, cap 아래 \(|\delta g|=0.0287|\delta m|\), 반응 단계의 보상 witness가 작은 예다. 이것들을 사용자의 요구를 자동 분해하는 데 쓸 수는 있으나 새 이론으로 세지 않는다.

### 후보 방법 [H]

Profile에서 stoichiometry·modifier 경계·capacity·지원 State를 읽어, 제한된 조작 box에서 interval/affine bound를 전파한다. cap 아래/위가 확실한 부분은 단순 식을 쓰고, 경계를 넘는 부분만 분할한다. 동일 Step의 실제 순서를 반영한다. Geometry 정규화의 퇴화, clamp, FP rounding, 시간 세분화 분기는 별도 처리해야 한다.

결과가 보수적으로 너무 넓으면 certification을 포기하고 full forward의 경험적 검증만 보고한다. 같은 변수의 반복 사용으로 생기는 interval dependency와 수많은 texel의 branch가 큰 장애다. Flow* 등 기존 nonlinear/hybrid reachability [R29]를 못 하는 방법처럼 묘사하지 않는다.

**기각:** 결과가 늘 미해결 / 유용한 편집을 대부분 제외 / 인증이 forward보다 훨씬 비쌈 / 설명이 단순 보존량 이상의 정보를 주지 못함. 정확성 인증 자체가 프로젝트의 필요보다 커지면 연구 범위를 축소한다.

## 5. 추가로 생각했지만 주력으로 추천하지 않는 아이디어

| 아이디어 | 매력 | 우선하지 않는 이유 / 재개 조건 |
|---|---|---|
| profile에서 자동 feature/branch compiler 생성 | 선언 모델을 재사용할 수 있음 | DSL/code generation만으로는 엔지니어링. A/B의 중요한 보장·비용 차이를 만들 때만 포함 |
| 학습된 memory closure / recurrent surrogate | 복잡한 미세 경로를 압축할 수 있음 | 데이터·일반화·양수성·분기 안정성 부담. analytic/표준 ROM보다 필요한 근거 없음 |
| coarse 실패를 자동으로 찾는 반례 생성기 | 잘못된 합치기를 진단 | 일반 differential/property testing과 CEGAR 선례. A의 검증 도구 역할이 우선 |
| 같은 외관에서 다른 후속 반응을 고르는 제작 도구 | 현상학적 모델의 목적과 잘 맞음 | hidden State 조작/다중 loss 자체는 약함. B의 제한 입력·보호와 결합될 때 의미 |
| incoming 규칙을 거리/시간 기반으로 재정의 | 해상도 의존 문제를 줄일 수 있음 | 표준 감쇠/반응 모델로 충분할 수 있음. 기존 preset 재현과 새 의미를 혼동하지 않음 |
| 논문을 ‘통합 시스템 분석’만으로 제출 | 반례와 재현 가능한 모델 계약을 정리 가능 | 작은 합성 반례만으로 SIGGRAPH급 중요성 부족. 실제 여러 시스템에서 반복되는 한계와 유용한 해결 지침이 필요 |

## 6. 실행 없이 작성 가능한 알고리즘의 정확한 공백

현재 가장 중요한 미완성 부분은 A의 **외부 port+dynamic geometry를 가진 독립 갱신식**이다. 아래 정보를 추측으로 메우면 연구가 아니라 surrogate의 주장에 그친다.

- coarse 총량과 내부 modes에서 실제 recipient Incoming을 어떻게 나눌 것인가?
- 위치를 잃은 잔류량이 형상에 기여하면 새 normal/edge weight를 어떻게 복원하는가?
- cap/threshold가 넘어갈 때 basis/compartment를 어떤 기준으로 늘리는가?
- mode를 합치거나 제거할 때 수지·양수성과 미래 오차 budget을 함께 어떻게 보존하는가?
- 외부 입력을 받은 뒤에는 이전 residual bound를 어떻게 다시 유효하게 만드는가?
- fine oracle 없이 판단할 수 없는 경우 어떤 비용을 지불하고 복원하는가?

이 중 하나라도 ‘필요하면 fine을 매번 확인’으로 답한다면 그 비용을 포함해 기존 fine Sparse와 비교해야 한다. 문제를 숨긴 채 독립 closure가 완성됐다고 쓰지 않는다.

## 7. 연구적 유력도와 현재 권고

| 후보 | 문제 근거 | 실행 없는 해법 진전 | 신규성/성공 전망의 정직한 판단 |
|---|---|---|---|
| A 내부 반응 잠재량·port 기반 적응형 block | 가장 구체적 | 제한된 exact update와 tail bound 확보 | **알고리즘 탐색 1순위**, 범용화 난도 높음. 새 기여는 미입증 |
| B 보호 계약에 맞춘 편집/축소 | 사용자 목적에 가장 가까움 | cap별 하한·sanity witness·의존 명세 | **실용 연구 1순위 / 알고리즘 탐색 2순위**. 강한 optimizer와 경쟁 필요 |
| C 보호 요구의 제한적 인증 | 수지/branch 예가 명확 | 조건부 certificate의 범위 정리 | 보조 후보. 기존 formal methods 대비 독자 이점은 약함 |
| 방향1 단독 future-aware authoring | 관측 모호성 확인 | 미래 시간/입력 범위의 필요 정리 | 단독 Contribution 유력도 낮음. B의 목표·평가로 유지 |

채택 확률을 수치로 줄 근거는 없다. ‘수식이 생겼다’는 이유로 A의 출판 가능성을 높게 확정하지 않는다. **문제만 있었던 방향3에서 제한된 독립 갱신 해법까지 한 단계 전진했다**는 평가가 적절하다.

## 8. 실행 전에 고정할 판정표

| 판별 | 통과해야 할 내용 | 실패하면 |
|---|---|---|
| 의미 | 기존 hop 기반 반응 결과를 유지할 제작 요구가 실제 있음 | 규칙 재정의/표준 모델로 전환, A 보류 |
| 최소 정확성 | 두 texel 유도가 production 연산 순서/정밀도 아래 재현됨 | 수식-구현 차이를 먼저 해결. 새 모델 실험 금지 |
| 열린 block | 동일 예산 microgrid보다 적은 내부 정보로 port input을 처리 | 정적 toy model 이상 주장을 중단 |
| Geometry | state-driven geometry 변화에 필요한 추가 정보가 작고 유효함 | frozen/static 범위로 축소하거나 A 중단 |
| 총 비용 | 생성·복원·오차 평가·replay 포함 품질–비용 이점 | GPU 내부 몇 연산의 속도 개선으로 대체하지 않음 |
| 편집 | 허용 U-input의 비자명한 feasible witness가 있음 | optimizer 실패로 Contribution을 만들지 않음 |
| 강한 대조 | 같은 보호/입력 조건의 표준법보다 성공률 또는 비용 이점 | B/C를 제품 기능으로 취급, 방법 기여 축소 |

이 표는 후속 **실행을 허가하거나 예약하는 문서가 아니다.** 지금은 문헌·기호 분석·설계만 수행했다. 실증 없이 남길 수 있는 최종 결론은 유망한 질문과 제한적 해법, 반례, 기각 조건까지이며 실제 효과·속도·제작 유용성은 미판정이다.
