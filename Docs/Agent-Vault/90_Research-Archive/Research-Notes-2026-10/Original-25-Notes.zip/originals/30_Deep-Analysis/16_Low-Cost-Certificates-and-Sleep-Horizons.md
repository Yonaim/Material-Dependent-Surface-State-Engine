# 저비용 판정과 계산 생략 기간 — 불변 영역·이동률 기반 후속 분석

작성: **2026-10-28 / Asia/Seoul**. 사용자 ‘더 연구’ 요청에 따라 [[90_Research-Archive/Research-Notes-2026-10/30_Deep-Analysis/15_Joint-State-Error-and-Geometry-Bounds|15]]의 판정 비용 문제를 검토했다. **문헌·코드 읽기와 기호 유도만 수행했다. 앱·GPU·빌드·수치 실험·학습 미실행, 제품 코드 변경 없음.** 코드 기준은 기존 HEAD `880af1ebcffe601f0bac27413cad94055ce92812` 및 작업 트리다.

아래 [D]는 이상 산술에서 명시된 부분 모델의 결과, [C]는 코드 확인, [H]는 미구현 제안, [P]는 문헌 확인이다. 수식의 신규성·전체 MDSSP의 정확성·GPU 속도를 입증한 문서가 아니다.

## 1. 이번 판단의 변화

15에서는 매 Step의 오차를 L·E+δ로 추적했다. 이번에는 **두 실행이 앞으로 머물 수 있는 공통 집합의 크기**로 오차를 제한한다. 이 방식은 매 Step 계수의 미분/민감도를 갱신하지 않아도 된다는 장점이 있지만, 집합이 넓으면 쓸모없는 상한만 준다.

이번에 확보한 것은 다음이다.

| 결과 | 조건부 진전 | 주요 제한 |
|---|---|---|
| 닫힌 saturation 수송의 공동 오차 ≤2B | 시간과 함께 커지지 않는 물·잔류 분포 상한 | 중력/다른 반응/외부 경계를 그대로 추가할 수 없음 |
| 이동률 기반 공동 오차 ≤2Σq₀[1−(1−α)^H] | 중력·동적 Geometry·outgoing limiter 허용, 미분 상수 불필요 | 단일 1:1 Incoming 전환, 닫힌 영역, 큰 α에서 느슨함 |
| 이동률 구간별 질량 요약 | 초기 감사 후 O(K) 크기의 기간 판정 | fine 상태는 유지, K 선택과 실제 비용은 미검증 |
| 기존 cap 판정 재확인 | 이미 구현된 생략을 후보에서 제거 | 새 스케줄러 필요성을 약화하는 근거 |
| 열린 경계 반례 | 어떤 사건이 기존 인증을 깨는지 특정 | 일반적인 GPU workgroup에 닫힌 영역 상한을 적용할 수 없음 |

이것은 ‘저비용 판정이 원리적으로 불가능하다’는 걱정을 제한 모델에서 줄인다. **유용한 기간이 실제로 얼마나 길며 기존 Sparse보다 이득인지**는 아직 모른다.

## 2. [D] 공통 하한과 수지만으로 공동 오차를 제한

물 q_i≥0, 움직이지 않는 잔류 a_i≥0, 단일 1:1 Incoming 전환만 고려한다. 직접 입력·Decay·다른 반응·외부 유출입은 우선 없다. 초기 상태 q⁰,a⁰에서 출발한 reference와 근사 모두

\[
\sum_i(q_i(t)+a_i(t)-a_i^0)=M_0,\quad
a_i(t)\ge a_i^0,\quad q_i(t)\ge b_i\ge0
\]

를 만족한다고 하자. **같은 b_i가 두 실행 모두에 유효해야 한다.**

증분 벡터 \(z(t)=(q(t)-b,\ a(t)-a^0)\)는 비음수이고 총합은 \(B=M_0-\sum_i b_i\)이다. 두 비음수 벡터 사이의 L1 거리는 각 총합의 합 이하이므로

\[
\boxed{\|q(t)-\widehat q(t)\|_1+\|a(t)-\widehat a(t)\|_1\le2B.}
\]

공통 하한이 초기 q⁰ 이하이면 q̂=q⁰,â=a⁰로 동결하는 근사도 포함된다. 잔류의 **공간 분포**까지 포함하는 bound이며, 잔류 총량만의 상한이 아니다.

이 결과는 simplex의 지름과 수지에서 나온다. 새로운 수학적 원리가 아니다. 이전 L1 증폭 반례와도 모순되지 않는다. 가까운 두 초기 상태의 거리가 한 Step에서 늘어날 수 있어도, 같은 초기 상태에서 생긴 두 허용 trajectory가 들어갈 수 있는 집합의 크기는 제한될 수 있다.

## 3. [D] saturation-only에서는 기간에 무관한 판정이 가능

[[90_Research-Archive/Research-Notes-2026-10/30_Deep-Analysis/12_Exact-Submodels-and-Limits|12 §2.5]]의 조건을 따른다. 닫힌 graph, 고정 C_i>0, F_ij=k_ij(s_i−s_j)_+, s_i=q_i/C_i, k≥0이며 매 Step Σ_j max(k_ij,k_ji)≤C_i이다. k는 State/Geometry에 따라 변해도 된다. 단일 Incoming 전환·immobile 잔류 외의 반응/Decay/중력은 없다.

초기 최저 saturation l=min_i(q_i⁰/C_i)은 이후에도 하한이다. 따라서 b_i=lC_i를 §2에 대입하면

\[
\boxed{E_{joint}(t)\le2\left(M_0-l\sum_iC_i\right)=2B\qquad \text{모든 }t\ge0.}
\]

12의 물 bound와 잔류 bound를 따로 더하는 것보다 강할 수 있다. 잔류가 증가하면 남은 물의 초과량은 같은 만큼 감소하므로, 두 최대치를 독립적으로 계상할 필요가 없기 때문이다.

### 계산 비용과 의미

초기에 M₀와 l을 한 번 집계하고 C 합을 준비하면, 조건이 유지되는 동안 E_joint≤ε인지 확인하는 데 새로운 fine flux가 필요하지 않다. 2B≤ε이면 해당 두 State의 계산을 동결해도 이 norm에 대한 판정은 시간에 따라 악화하지 않는다. 동적 형상이 k를 바꾸더라도 k의 비음수/상한 조건 안에 있으면 된다. **Geometry 미분 상수 Γ가 이 증명에는 필요 없다.**

물량이 작지 않아도 saturation이 거의 일정하면 B가 작을 수 있다. 반면 빈 texel 하나로 l=0이면 B=M₀가 되어 거의 쓸모없는 상한이 된다. 물이 퍼지는 전체 UV 영역에는 빈 texel이 많을 수 있으므로 이 한계는 중요하다.

이 방식은 q,a의 결과만 보호한다. 다른 State의 수송이 이 형상에 영향을 받아 달라지는 경우까지 보호하려면 그 State를 별도로 포함해야 한다. Surface 전체를 무조건 멈추는 인증이 아니다.

### 두 texel의 정확한 sanity 식

같은 C, 고정 β∈(0,1/2], 같은 f, 중력/외부 입력이 없는 두 texel에서 실제 flux를 F₁₂=β(q₁−q₂)₊와 반대 방향 식으로 정의한다. d=q₁⁰−q₂⁰, ρ=1−(2−f)β일 때 H Step의 한 방향 누적 이동은

\[
S_H={|d|\over2-f}(1-\rho^H).
\]

초기 상태를 동결한 실행과의 공동 공간 L1 차이는 정확히 2S_H이다. source의 물 감소 S_H, recipient의 물 증가 (1−f)S_H, 잔류 증가 fS_H를 합한 것이다. B=|d|이므로 일반 상한 2B와 일치하는 방향의 sanity check가 된다. **기호 유도이며 실행 결과가 아니다.**

## 4. [D] 중력까지 허용하는 유한 기간 하한

이번에는 saturation maximum principle을 사용하지 않는다. 같은 단일 Incoming 전환 모델에서 source의 실제 outgoing O_i가 모든 허용 상태에서

\[
0\le O_i^n\le\alpha_i q_i^n,\qquad0\le\alpha_i\le1
\]

을 만족한다고 하자. 남는 Incoming은 비음수이므로 q_i^(n+1)≥(1−α_i)q_i^n이다. 따라서 0≤t≤H 동안

\[
q_i(t)\ge q_i^0(1-\alpha_i)^H=:b_i(H).
\]

reference와 근사 모두 같은 α 범위 안에 있고 같은 초기 상태에서 시작하면 §2에서

\[
\boxed{E_{joint}(t)\le2\sum_iq_i^0\{1-(1-\alpha_i)^H\},\quad0\le t\le H.}
\]

이 식은 중력·비대칭 flux·State-Driven Geometry Coupling·활성 outgoing limiter를 허용한다. 단, 두 실행이 모두 비음수/수지/1:1 유입 전환을 지켜야 하며 α는 **현재 관측 flux가 아니라 모든 허용 미래의 상한**이어야 한다. 임의 다중 Reaction의 소비는 포함하지 않는다.

이 상한은 f에 의존하지 않는다. 잔류 생성만 보호할 때보다 더 강한 물 분포 요구를 함께 다루기 때문이다. H가 크거나 α가 1이면 2M₀의 자명한 상한으로 가까워진다. 반면 αH가 작은 짧은 기간에는 15의 반복 L·E+δ보다 유용할 가능성이 있다. 어느 것이 실제로 더 좁은지는 미검증이다.

## 5. [C/D] α는 실제 fine flux를 계산하지 않고 구할 수 있는가

### 5.1 저장량 cap에서 Geometry 범위를 먼저 얻는다

[accumulationHeight](C:/Users/yonai/Documents/MDSS_Engine/Shaders/Simulation/Solver/StateMath.glsl:48)는 저장 State를 Capacity까지만 형상에 반영한다. profile·mesh·transform·meso가 고정되고 모든 값이 유한하다고 하자. 채널 k에 대해 p_ik=ProfileCapacity_ik, F_ik=AccumulationFactor_ik, T_ik=ThicknessPerAmount_ik라 하면

\[
0\le h_i^{acc}\le H_i^{max}:=FillDepth_i+
WorldToLocalHeight_i\sum_k p_{ik}F_{ik}T_{ik}.
\]

이 상한은 cavity contribution도 포함한다. cavity height≤FillDepth이고, cavity 초과량의 following 기여는 cavity 가중 두께 합 이하이다. 비cavity following과 이를 합치면 ΣAmount·Thickness 이하이며 Amount≤pF이다. 적용되지 않는 채널/비양수 Factor는 합에서 제외할 수 있다.

이는 정확한 최대치보다 느슨할 수 있지만 **저장량 자체에 cap이 없어도 형상의 범위는 유한하게 제한되는 코드 구조**를 이용한다. 새 물리 부피 모델을 도입하지 않는다.

### 5.2 중력 방향의 민감도 대신 크기 상한 사용

정적 meso 위치를 P_i^m, macro normal을 N_i, ModelLinear를 M, SolverUp을 u라 하자. 높이의 직사각형 범위에서

\[
D_{ij}^{max}=\max_{\eta_i\in\{0,H_i^{max}\},\eta_j\in\{0,H_j^{max}\}}
|u\cdot M(P_j^m+N_j\eta_j-P_i^m-N_i\eta_i)|
\]

를 사전 계산한다. affine 함수 절댓값의 최대는 모서리에서 얻으므로 네 조합이면 충분하다. [geometryDriveToPosition](C:/Users/yonai/Documents/MDSS_Engine/Shaders/Simulation/Solver/GeometryDrive.glsl:74)의 DirectionDrive∈[0,1]이므로 **GeometryDrive≤D_ij^max**이다. 접선 중력이 거의 0인 branch도 반환값 0이므로 이 크기 상한에 들어간다.

따라서 15의 미분 기반 bound와 달리, 여기에는 접선 중력 g_min이나 dynamic Concavity의 미분을 요구하지 않는다. 그 대신 모든 가능한 방향·적층 높이를 허용해 상한이 넓어질 수 있다. transform/meso/profile이 바뀌면 다시 계산하거나, 처음부터 그 변화 범위를 포함해야 한다.

### 5.3 raw 식에서 outgoing 비율 상한

[rawFlux](C:/Users/yonai/Documents/MDSS_Engine/Shaders/Simulation/Solver/Transport.glsl:1)에서 saturation 차이의 양수 부분은 q_i/C_i 이하, weight와 Retention은 [0,1]이다. saturation rate S_i, geometry rate G_i에 대해

\[
rawF_{ij}\le {\Delta t\over C_i}(S_i+G_iD_{ij}^{max})q_i.
\]

실제 flux는 outgoing limiter로 더 줄어드므로

\[
\boxed{\alpha_i=\min\left(1,{\Delta t\over C_i}\sum_{j:i\to j}
(S_i+G_iD_{ij}^{max})\right)}
\]

는 충분한 상한이다. 고정 dt·정적 조건에서 State를 매 Step 읽지 않고 준비할 수 있다. rate 상수의 코드 정본은 [SurfaceSolverRates.h](C:/Users/yonai/Documents/MDSS_Engine/Source/SurfaceState/Types/SurfaceSolverRates.h:8)이다. 작은 texel footprint의 C_i와 큰 Geometry rate 때문에 α=1로 포화될 수 있다. 실제 장면에서 α가 얼마나 작은지는 **측정하거나 수치 실험하지 않았다**.

이 α는 무제약 다중 반응의 소모율을 포함하지 않는다. 현재 IceReactionLab에는 Heat 소비·Ice 융해가 있으므로 이 식을 그 전체 실험의 휴면 인증으로 사용하면 안 된다. FP raw 저장/산술의 과대 반올림도 별도 여유량이나 검증이 필요하다.

## 6. [H/D] 이동률 구간별 질량으로 O(K) 기간 판정

α_B=max_i α_i 하나만 쓰면 작은 면적의 한 texel 때문에 전체 α_B=1이 될 수 있다. 이를 완화하는 간단한 방법은 **α의 구간별로 초기 질량을 모으는 것**이다.

각 구간 b에 상한 ᾱ_b를 두고, 그 구간에 포함된 위치의 초기 물량을 M_b=Σ_i∈b q_i⁰로 저장한다. 구간 membership은 정적 α로 정할 수 있다. 그러면

\[
E_{joint}(t)\le2\sum_{b=1}^K M_b\{1-(1-\bar\alpha_b)^H\},\qquad t\le H.
\]

K는 fine texel 수와 독립적으로 작게 고르는 제안이다. 실제 최적 K/분할은 미검증이다. 높은 α 구간에 물이 거의 없으면 그 구간의 큰 α가 다른 질량 전체에 적용되는 것을 피한다.

초기 질량을 그대로 두는 이유는 이것이 **초기 물량 중 각 위치에 최소한 남는 양**의 하한이기 때문이다. 이후 유입은 하한을 더 크게 만들 뿐이다. 실제 물이 이동하는 동안 질량 bin을 매 Step 재분류하는 알고리즘이 아니다. 새 입력은 아래 §8처럼 별도 처리해야 한다.

거듭제곱 없이 더 느슨하게 판정하려면 Bernoulli 부등식으로

\[
E_{joint}(t)\le2\sum_bM_b\min(1,H\bar\alpha_b)
\le2H\sum_bM_b\bar\alpha_b
\]

를 쓸 수 있다. W=Σ_b M_bᾱ_b>0일 때

\[
H_{safe}=\left\lfloor{\varepsilon\over2W}\right\rfloor
\]

Step까지는 조건부 충분 판정이 된다. H_safe=0이면 생략하지 않는다. W=0이면 초기 물은 빠져나가지 않고 새 유입도 없는 현재 가정 아래 상태가 정지한다. 비선형 식을 사용하는 경우 O(K) 평가/단조 검색으로 더 긴 기간을 찾을 수 있다.

**판정 비용은 줄었지만 효과는 아직 모른다.** 시작 시 O(N) 집계·K 저장·만료/입력 사건 관리가 필요하다. coarse State만 남기는 방법은 아니며 fine 상태와 A/B 일관성도 유지해야 한다. 매 Step GPU workgroup 목록을 실제로 건너뛰는 설계는 구현하지 않았다.

### 해상도를 높이면 이 상한이 나빠질 수 있다

같은 물리적 표면을 균일하게 세분화하고 선형 간격을 ℓ이라 하자. 고정 Profile에서 C_i는 texel 면적에 비례하므로 O(ℓ²)이다. 이웃 수가 고정이면 saturation 항의 α 상한은 O(Δt/ℓ²)로 커진다. 서로 독립적인 전체 적층 범위로 D_max를 잡으면 이웃끼리 최대 높이 차이가 O(1)로 남을 수 있어 gravity 상한도 같은 악화를 보인다. 국소 기울기가 제한돼 D_max=O(ℓ)라고 추가 보장하면 gravity 항은 O(Δt/ℓ)로 완화된다.

이는 조건부 스케일 분석이다. 실제 UV 왜곡/경계 면적은 균일하지 않으며 측정값도 없다. α가 1이 된다는 것은 **이 판정이 무력해진다는 뜻**이지, outgoing limiter가 있는 원래 Solver가 음수가 되거나 불안정하다는 증명이 아니다.

정적 전체 범위 α만으로는 정밀한 Mesh에서 유용한 H를 얻기 어려울 수 있다. 돌파하려면 전체 cap 범위보다 좁은 **미래 높이 차이/State 범위**를 싸게 확보해야 한다. 현재 순간의 범위를 이후에도 유지된다고 가정해서는 안 된다. 제안한 범위가 앞으로 H Step의 갱신을 포함하는지 검증하는 enclosure가 필요하며, 그 원리도 기존 reachability 연구 R29와 겹친다.

## 7. [D] 열린 경계에서 깨지는 최소 반례

block 내부 두 texel의 q₁=q₂=1, C=1, 초기 잔류 0이면 l=1, B=0이다. 하지만 q₂가 block 밖 q₃=0과 연결되고 k₂₃=β>0이면 첫 Step에 β가 유출된다. 닫힌 block이라고 잘못 가정해 모두 멈춘 실행과의 전체 물·잔류 L1 차이는 2β이다. **B=0인데 실제 오차는 0이 아니다.**

경계 수송을 계속 계산하고 내부만 멈춰도 첫 유출 뒤 q₁>q₂가 되어 다음 Step에 내부 수송이 생긴다. ‘외부 Incoming이 오면 깨운다’만으로는 부족하다. **Outgoing·직접 제거·경계 상태 변화**도 기존 판정을 무효화할 수 있다.

또 같은 q₁=q₂=1인 닫힌 두 texel이라도 중력 방향 flux γq₁가 있으면 첫 공동 변화량이 2γ이다. saturation 기반 B=0 상한은 이 경우 사용할 수 없다. 반면 §4의 α 상한은 중력을 포함하므로 모순이 없다.

실제 GPU의 64-thread workgroup은 transport graph에서 닫힌 영역이 아니다. 이웃 halo를 붙였다고 닫힌 집합이 되는 것도 아니다. §3–6을 일반 workgroup마다 독립 적용하고 오차를 합하는 방식은 아직 정당화되지 않는다.

### 제한적으로 가능한 경계 확장

공통 하한 b가 두 실행에서 계속 유지되고, 잔류가 감소하지 않는다는 조건을 **별도로 보장**하자. 각 실행의 누적 외부 유입/유출을 I,O라 하면 내부 벡터 (q−b,a−a⁰)의 질량은 B+I−O이다. 누적 port별 outgoing을 비음수 장부로 붙이면 총질량은 B+I가 된다. 따라서 두 실행의 내부 상태와 누적 outgoing 장부의 공동 차이는

\[
E_{aug}\le2B+I^{ref}+I^{approx}
\]

로 제한할 수 있다. 이것은 외부 이웃의 상태/이후 반응까지 제한하는 식이 아니다. 외부로 나갔다 돌아오는 양은 gross 유입으로 다시 세야 한다. 순유량 0만으로 작은 budget이라 판단할 수 없다. α로 구한 초기물 하한은 boundary outgoing까지 α에 포함하면 유지할 수 있으나, reference의 실제 미래 Incoming을 공짜로 아는 것은 아니다.

일단 경계가 열리면 이 조건과 외부 영향 관리가 큰 비용/연구 과제가 된다. 따라서 현재의 O(K) 판정은 **닫힌 transport component 또는 명시적으로 경계 budget이 주어진 부분 문제**에 대한 방법이다.

## 8. [H] 인증의 생성·만료·재사용 계약

| 사건 | 필요한 처리 |
|---|---|
| 알려진 초기 상태에서 최초 감사 | 질량/floor 또는 α-bin 질량 집계. 준비 비용 계상 |
| 조건 안의 State-Driven Geometry 변화 | §4–6의 α가 전체 가능한 형상을 포함하면 재감사 불필요. 다른 State의 결과까지 보호되는 것은 아님 |
| 직접 양수 입력 | 사건 전에 깨우거나 유입 budget에 추가. 닫힌 전체 모델에서 양쪽 총 입력≤I_max이면 공통 초기물 하한을 유지한 지름 bound는 2B_H+2I_max로 완화 가능 |
| 제거 입력·다른 소비/생성 반응·잔류 Decay | 현재 증명의 가정을 깨므로 그대로 사용 불가 |
| profile·mesh·transform·dt 변경 | α/형상 범위의 유효성 재판정. 기존 범위 밖이면 만료 |
| 예정 H 도달 | 추가 생략을 허용하지 않음. 정확 갱신으로 돌아와도 이미 생긴 오차는 없어지지 않음 |
| 다음 휴면 기간 시작 | 근사 상태를 새 ‘정답 초기 상태’로 보고 budget을 0으로 초기화하면 안 됨. 공통 reference enclosure/이전 오차 또는 신뢰 checkpoint 필요 |

상태를 매번 확인하는 대신 다음 감사 시점을 미리 정하는 기본 발상은 기존 self-triggered 방법과 겹친다. 이번 제안은 그런 스케줄링 원리를 새로 발명한 것이 아니다.

## 9. [C] cap 위의 높이 생략은 이미 구현돼 있다

[StateFinalize.glsl::accumulationContributionChanged](C:/Users/yonai/Documents/MDSS_Engine/Shaders/Simulation/Solver/StateFinalize.glsl:1)는 Old/New State를 [0,Capacity]로 clamp한 뒤 비교한다. 둘 다 cap 위이면 값이 달라도 높이 재계산을 예약하지 않는다. [Pass 2](C:/Users/yonai/Documents/MDSS_Engine/Shaders/Simulation/Solver/SurfaceSolverPass2.comp:172)와 [Reaction](C:/Users/yonai/Documents/MDSS_Engine/Shaders/Simulation/Solver/SurfaceReaction.comp:175)가 이 함수를 사용한다.

[SurfaceAccumulationHeight.comp](C:/Users/yonai/Documents/MDSS_Engine/Shaders/Simulation/Geometry/SurfaceAccumulationHeight.comp:66)는 예약된 위치에서 실제 높이를 구하고 BuiltHeight와 비교해 Geometry 갱신을 예약한다. 반면 Solver의 다음 활성화는 Current>0 또는 NewState>0으로 유지된다. 따라서 **높이 불변 영역의 생략과 비영 물량의 수송 계산 생략은 이미 서로 다른 단계**다.

α 기반 하한으로 q_i⁰(1−α_i)^H≥C_i를 예측하면 cap 유지 기간을 구할 수는 있다. 그러나 이것은 기존 함수가 매 Step 수행하는 작은 비교를 예측으로 대체하는 수준일 수 있다. 다른 채널/이웃 형상 변화도 있어야 하고, 전체 갱신 이득을 새로 얻는다고 가정할 수 없다. **‘cap을 이용한 Geometry 생략’을 새 기여나 주력 알고리즘으로 제안하지 않는다.**

## 10. 기존 연구와의 경계·현실적인 선택

[P] 불변 영역·convex limiting은 기존 수치해석 분야다. [Guermond, Popov & Tomas의 연구](https://arxiv.org/abs/1807.02563)는 이 개념의 선례이며 이번 식과 동일한 알고리즘이라고 주장하지 않는다. 현재 상태에서 다음 계산 시점을 예측하는 [Anta & Tabuada의 self-triggered control](https://arxiv.org/abs/0806.0709), 낮은 복잡도의 상태 범위로 전체 갱신을 줄이는 [Silvestre 등의 set-valued observer 연구](https://doi.org/10.1016/j.ins.2017.10.029)도 관련 선례다. 실제 열람 수준은 [[90_Research-Archive/Research-Notes-2026-10/90_Reference/07_Related-Work|R39–R41]]에 기록했다.

이번 simplex 지름·하한 곱·rate bin 합산·만료 예약은 모두 표준 도구의 적용이다. 독립적인 SIGGRAPH Contribution으로 보기 어렵다. 그래도 다음 두 선택을 더 정확히 비교할 수 있게 됐다.

| 선택 | 장점 | 중단/방향 수정 기준 |
|---|---|---|
| 닫힌 saturation component의 near-equilibrium 생략 | 2B가 작으면 추가 fine 판정 없이 장기 제한 가능 | 실제 장면 대부분 l=0/중력 ON/다중 반응이면 적용 범위가 너무 좁음 |
| α-bin 기반 짧은 기간 생략 | 중력·동적 형상·limiter를 포함하면서 O(K) 기간 판정 가능 | H_safe가 대부분 0–1이거나 준비/목록 관리 비용이 이득을 소멸 |
| 임의 열린 block의 생략 | 실용성이 높을 수 있는 최종 대상 | boundary/다른 State 영향 관리가 fine 계산만큼 비싸거나 기존 적응법으로 충분 |

**현재 권고:** 새 코드를 먼저 만들지 않는다. 다음 비실행 분석은 (i) 알려진 Profile/geometry 계약으로 α가 어느 조건에서 1로 퇴화하는지, (ii) 열린 경계에서 원래 충분조건을 보존하는 최소 외부 정보가 무엇인지, (iii) 이 범위가 실제 제작 목표에서 중요한지를 좁힌다. 이미 가진 PERF 자료가 이 새로운 방법의 품질–비용을 입증하는 것처럼 재사용하지 않는다.

방향3은 **저비용 판정의 조건부 구성까지 진전**했지만 아직 주력 Contribution 확정 단계가 아니다. 방향2는 여전히 제작 목적과 가장 가깝고, 위 bound는 제한적 보호 평가의 도구로 쓸 가능성이 있다. 방향1은 방향2의 목표/평가로 유지한다. 이번 분석으로 현 구현의 시스템 통합 판정이나 신규성 평가를 상향하지 않는다.
