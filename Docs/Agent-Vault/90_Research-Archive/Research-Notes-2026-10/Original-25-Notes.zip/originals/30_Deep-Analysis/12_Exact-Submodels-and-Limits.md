# 실행 없는 연구 — 정확한 최소 모델과 불가능 조건

작성: **2026-10-27 / Asia/Seoul**. 사용자 요청: “직접적인 실험없이 할 수 있는거 전부 해봐. 추론, 새로운 아이디어, 돌파할 지점 뭐든”.

[[90_Research-Archive/Research-Notes-2026-10/30_Deep-Analysis/11_Contribution-Proof-Obligations|직전 분석]]을 이어 코드 읽기·기호 유도·문헌 대조만 수행했다. **앱·GPU·빌드·수치 시뮬레이션·학습·새 benchmark는 실행하지 않았다.** 아래 숫자는 식에 대입한 예이며 측정치가 아니다. 제품 코드 수정 없음. HEAD `880af1ebcffe601f0bac27413cad94055ce92812`와 기존 작업 트리를 읽었다. [C/D/P/H]는 코드/조건부 유도/문헌/가설이다. 전체 탐색 공간을 소진했다는 뜻은 아니다.

## 1. 이전 분석에서 실제로 전진한 부분

- [D] 내부 이동에 따른 잔류 반응을 **fine 값을 매 Step 다시 읽지 않고** 갱신하는 제한된 두 texel 모델을 유도했다. 미래 잔류 오차의 상한도 얻는다.
- [D] 더 일반적인 닫힌 graph에서도 saturation 차이 수송·단일 유입 전환·시간 간격 조건 아래, **형상이 바뀌어도 유효한 미래 총 잔류량 상한**을 유도했다. 전역 형상/이미지 오차 보장은 아니다.
- [D] 모든 미래를 정확히 보존하는 고정 크기 압축은 일반적으로 불가능하다. MDSSP의 제한된 확산 경로에서 필요한 차원이 늘어나는 예를 구성했다.
- [D] 현재 형상이 같거나 현재 물막이 같다는 조건은 후속 수송 보호를 뜻하지 않는다. 보호 조건을 유한 시간·허용 입력으로 한정해야 한다.
- [D] 현 Ice 규칙에서 융해를 바꾸면서 한 substep 끝의 Heat와 capped 높이를 보존하는 **반응 단계의 대수적 witness**를 만들었다. 실제 U-input rollout의 witness는 아니다.
- [P] 기억을 가진 축소 모델, 목적별 축소, 적응형 오차 제어, 보상/누적량 보존은 기존 분야다. 아래 유도를 새 수학의 발견으로 주장하지 않는다.

실제 알고리즘 초안·중단 조건은 [[90_Research-Archive/Research-Notes-2026-10/30_Deep-Analysis/13_Method-Blueprints-and-Decision|후속 방법 명세]]를 따른다.

## 2. 두 texel에서 정확히 닫히는 ‘남은 잔류 생성량’

### 2.1 모델과 코드 대응

동일 면적·Capacity·Profile의 두 texel만 연결한다. 이동하는 Waterfilm을 x,y, 두 texel에 쌓인 immobile 잔류 State의 합을 a라 한다. 잔류는 높이·다른 반응에 기여하지 않는다. 외부 Input/flux, Gravity, Decay, 다른 Reaction, Geometry 갱신은 없다. Waterfilm의 saturation spread만 켠다. 유일한 Reaction은 **Incoming의 비율 f를 물에서 잔류로 전환**, 0<f≤1이다.

[C] [Transport.glsl::rawFlux](C:/Users/yonai/Documents/MDSS_Engine/Shaders/Simulation/Solver/Transport.glsl:1), [Pass 1의 outgoing 제한](C:/Users/yonai/Documents/MDSS_Engine/Shaders/Simulation/Solver/SurfaceSolverPass1.comp:127), [Pass 2의 Incoming 저장](C:/Users/yonai/Documents/MDSS_Engine/Shaders/Simulation/Solver/SurfaceSolverPass2.comp:153), [reactionRequest](C:/Users/yonai/Documents/MDSS_Engine/Shaders/Simulation/Solver/SurfaceReaction.comp:18)에 대응한다. 이 inflow 규칙은 기존 연구용 계획/준비 코드에 있으며, `IceReactionLab` 원본의 두 continuous rule과 구별한다.

한 Step의 양방향 raw flux를

\[
F_{12}=\beta(x-y)_+,\quad F_{21}=\beta(y-x)_+,
\qquad 0\le\beta\le\tfrac12
\]

로 쓴다. β는 공통 saturation 계수·weight·dt/Capacity를 묶은 무차원 값이다. β≤1/2는 충분조건으로 선택했다. source의 outgoing은 보유량 이하이며, recipient의 post-transport 보유량은 Incoming 이상이어서 f≤1의 반응 limiter도 비활성이다. 이상적 산술에서 FP16 flux/cache 양자화는 제외한다.

### 2.2 독립 갱신식과 증명

\(m=x+y\), \(d=x-y\), \(\rho=1-(2-f)\beta\)라 하자. d≥0이면

\[
x'=x-\beta d,\qquad y'=y+(1-f)\beta d.
\]

d<0이면 x와 y의 역할을 바꾼다. 두 경우 모두

\[
m'=m-f\beta|d|,\qquad d'=\rho d,\qquad
a'=a+f\beta|d|.
\]

0≤ρ≤1이므로 d의 부호는 뒤집히지 않는다. 이제

\[
\boxed{p=\frac{f}{2-f}|d|}
\]

를 **현재의 비균일한 물 분포가 이후 내부 이동으로 만들 수 있는 잔류량의 상한**으로 정의하면,

\[
\boxed{p'=\rho p,\quad a'=a+(1-\rho)p,\quad
m'=m-(1-\rho)p.}
\]

따라서 m,p,a만으로 block 총량의 다음 상태를 계산한다. 매 Step fine snapshot을 조회할 필요가 없다. m+a 및 a+p는 불변이고, 0≤p≤m가 유지된다. p는 별도 물질 저장량이 아니라 **m 안의 불균일성이 남길 수 있는 결과를 나타내는 변수**다. 질량 합에 m+p+a를 쓰면 이중 계상이다.

β가 일정하면 N Step 후

\[
a_N-a_0=p_0(1-\rho^N),\qquad m_N=m_0-p_0(1-\rho^N).
\]

β가 매 Step 달라져도 각 βₙ이 위 조건을 만족하고 독립적으로 알려져 있으면 ρᴺ을 \(\prod_{n=0}^{N-1}\rho_n\)로 바꾼 식이 성립한다. 곱이 0으로 수렴할 때에만 최종 잔류 증가가 p₀와 같고, 이동이 중간에 멈추면 더 작다.

**얻은 성질:** 현재 시점에서 내부 모드를 없애고 m,a를 그대로 유지할 때, 같은 닫힌 조건이 계속되는 미래의 block 총 잔류·물 총량 오차는 각각 p 이하이다. p≤ε인 경우에 한해 이 관측에 대한 생략 기준을 만들 수 있다. 공간 분포·최대 texel 오차·이미지 오차의 보장은 아니다.

### 2.3 의미와 한계

평균값만 쓰면 두 texel을 즉시 균일하게 만들어 이후 Incoming 반응을 전혀 만들지 못한다. p는 이미 생긴 잔류량이 아니라 **아직 발생하지 않은 내부 이동의 효과**를 보관한다. 이것이 이전의 ‘통계가 부족하다’는 반례보다 진전한 부분이다.

그러나 두 물 변수 x,y를 m,p로 바꾸는 것만으로 차원을 줄인 것은 아니다. a를 aggregate할 수 있는 관측에서만 원래 두 잔류 값의 위치 정보를 생략한다. 중요한 후속 가능성은 **p가 작아진 block에서 내부 변수를 제거하는 기준**이지, 두 셀 예제 자체의 속도 향상이 아니다. 원래 fine Sparse도 정지/작은 활동을 잘 처리한다면 유용성이 없다.

이 유도는 기존 compartment/mode elimination/transition reward의 특수 사례에 가깝다 [R22, R25, R31]. 논문 신규성으로 확정하지 않는다.

### 2.4 어디에서 즉시 깨지는가

| 추가 요소 | 필요한 정보 / 실패 이유 |
|---|---|
| 어느 한쪽으로 들어오는 외부 입력 | d와 −d는 같은 m,p이지만 같은 위치의 입력 후 \(|d+u|\)가 달라진다. p만으로 충분하지 않음 |
| 좌우 boundary flux | 각 port의 물량을 알려면 signed d 또는 동등한 방향 정보가 필요 |
| 다른 f를 가진 재질·direction별 계수 | 위의 하나의 ρ와 p 정의를 그대로 재사용할 수 없음 |
| 잔류가 Geometry에 기여 | 잔류가 어느 texel에 생겼는지에 따라 다음 edge weight가 달라짐. a의 합만으로 부족 |
| Ice/Heat의 국소 반응·공급량 경쟁 | 지역별 joint State와 반응 branch가 필요. 물의 contrast만으로 닫히지 않음 |
| 3개 이상 texel의 일반 graph | 각 edge contrast는 이웃 edge와 공유 inventory를 사용. edge마다 독립 p를 합하면 동일 물/미래 반응을 중복 계산할 수 있음 |
| 새로운 입력 뒤의 생략 보장 | 새 입력이 contrast를 다시 만들 수 있다. 이전 p≤ε는 새 과제의 보장이 아님 |

따라서 이 식으로 ‘일반적인 MDSSP coarse solver를 해결했다’고 쓰지 않는다. **외부 port와 state-driven edge를 가진 block에서도 작은 내부 상태와 쓸 만한 잔여 오차 한계가 존재하는가**가 새 연구의 실질적 질문이다.

### 2.5 일반 graph: Geometry가 변해도 남는 제한적 상한

두 texel의 exact closure와 별도로, 닫힌 graph 전체에 적용하는 더 느슨한 bound를 유도할 수 있다. 각 texel의 고정 Capacity 총량을 Cᵢ>0, 물을 qᵢ, saturation을 sᵢ=qᵢ/Cᵢ라 하자. 단일 Incoming 전환 비율은 texel별 0≤fᵢ≤1이고, 잔류는 이동/소멸하지 않는다. 다른 입력·Decay·물 생성/소비 Reaction·Gravity drive는 없다. **물/잔류가 Geometry를 바꾸는 것은 허용**하되, flux가

\[
F_{ij}=k_{ij}(s_i-s_j)_+,\qquad k_{ij}\ge0
\]

형태이며 모든 미래 Step에서

\[
\sum_j\max(k_{ij},k_{ji})\le C_i
\]

를 만족한다고 요구한다. k에는 dt가 포함된다. 상대 방향 edge가 없으면 그 k는 0으로 둔다. 이 충분조건은 공급량 limiter를 비활성으로 만들고 다음 convex-combination 성질을 보장한다. 실제 기본 dt가 언제나 이 조건을 만족한다고 확인한 것은 아니다.

수송 후 유입 전환을 합친 갱신은

\[
s_i'=s_i-\sum_{s_j<s_i}\frac{k_{ij}}{C_i}(s_i-s_j)
 +(1-f_i)\sum_{s_j>s_i}\frac{k_{ji}}{C_i}(s_j-s_i).
\]

위 조건 아래 sᵢ와 이웃 sⱼ의 비음수 가중 합이며 가중치 합은 1이다. 따라서 한 시점 n의 최소/최대 saturation lₙ,uₙ은 모든 후속 시점의 값들을 감싼다. k가 State/Geometry에 따라 변해도 매 Step 조건을 만족하면 귀납적으로 성립한다. kᵢⱼ=kⱼᵢ 대칭성은 필요하지 않다.

총 물 Mₙ=Σqᵢ, 총 잔류 Aₙ, CΣ=ΣCᵢ에 대해 M+A는 일정하고, 미래 물량은 lₙCΣ 이상이므로

\[
\boxed{0\le A_t-A_n\le M_n-l_n C_\Sigma=:B_n\quad(t\ge n).}
\]

또 각 texel의 물 상태는 같은 saturation interval에 남으므로, 시점 n의 물 상태를 고정한 근사와 비교한 미래 물 상태 L1 오차에는 \(\sum_i|q_i(t)-q_i(n)|\le C_\Sigma(u_n-l_n)\)라는 느슨한 bound도 있다. 잔류 변화는 비음수라 그 L1 오차는 위 Bₙ과 같다. 형상/normal/렌더 오차를 이 식에서 곧바로 결론내리지 않는다.

[C] [buildTransferWeight](C:/Users/yonai/Documents/MDSS_Engine/Shaders/Simulation/Geometry/SurfaceDynamicWeightsUpdate.comp:98)는 유효 경로의 distance/normal/profile weight를 [0,1]에 제한하고, `rawFlux`의 cavity Retention도 [0,1]이다. **Gravity OFF의 saturation 항**에서는 material rate·dt·최대 이웃 수로 k 상한을 정할 수 있다. 따라서 동적 형상 때문에 coefficient가 바뀐다는 사실 자체는 위 증명을 깨지 않는다. 고정 footprint Capacity도 이 분석에 부합한다. FP16 raw flux 양자화·산술/동일 Step cache 일관성은 이 이상적 식의 범위 밖이다.

이 bound가 Bₙ≤εA 및 CΣ(uₙ−lₙ)≤εW이면, 위 조건이 유지되는 닫힌 영역에서 내부 계산을 멈췄을 때 지정 State 총량/L1 오차가 제한됨을 뜻한다. 하지만 **그 영역을 다른 영역과 연결하거나 새 입력을 주면 기존 인증은 만료**된다. 빈 texel 때문에 lₙ=0이면 Bₙ=Mₙ으로 매우 느슨할 수 있다. 많은 State가 계속 반응하는 전체 MDSSP의 정지 기준은 아니다.

[P,D] 사용한 이론은 고전적인 discrete maximum principle/convex combination과 수지 [R33]다. 새 maximum principle을 발명한 것이 아니다. 남는 후보는 이런 bound를 실제 제작에 유용한 open block·다중 반응 범위까지 넓히고, 기존 fine Sparse보다 적은 비용으로 계산을 중단/재개하는 방법이다. 그 확장과 효과는 미확인이다.

## 3. Fine 제거의 대가는 기억 또는 추가 상태다

[D] 고정된 선형 영역에서 resolved z, unresolved r를

\[
z_{n+1}=Az_n+Br_n+Eu_n,\qquad
r_{n+1}=Cz_n+Dr_n+Fu_n
\]

로 나눈다. 두 번째 식을 반복 대입하면

\[
z_{n+1}=Az_n+BD^n r_0+Eu_n+
\sum_{j=0}^{n-1}BD^{n-1-j}(Cz_j+Fu_j).
\]

fine 성분을 식에서 없애도 **초기 미세 상태와 과거 입력/거동**이 남는다. 현재 평균의 Markov 모델만으로 대체할 수 있다는 보장은 없다. \(\|D\|\le\gamma<1\)이면 오래된 memory tail의 기하급수 bound를 만들 수 있지만, 현재 MDSSP의 모든 block에 이 안정성/시간척도 분리를 증명한 것은 아니다. 느린 내부 모드가 많으면 기억 비용도 크다.

[P] Mori–Zwanzig와 기존 ROM의 핵심 논점이다 [R25]. 기억을 저장한다는 발상·RNN으로 근사한다는 발상은 기여가 아니다. 위 두 texel의 p는 해당 특수 모델에서 기억을 한 비음수 변수로 나타낸 경우로 해석할 수 있다.

### 3.1 정확한 고정 선형 quotient의 판정

\(q'=Lq+Bu\), 관측 \(y=Cq\), 장부 증가 \(a'=a+Rq\), 압축 \(z=Pq\)가 선형이라고 하자. 모든 q,u에서 정확한 축소를 원하면

\[
PL=\widehat L P,\quad C=\widehat C P,\quad R=\widehat R P,
\quad \widehat B=PB
\]

가 충분하며, 해당 선형 형태에서는 필요한 조건이다. 동치인 kernel 불변성으로 검사할 수도 있다. state 출력뿐 아니라 장부 R도 보존 조건에 넣어야 한다. affine 항은 상수 좌표를 붙인다.

이것도 기존 observability/lumping의 적용이다. 일반 MDSSP는 반응 곱·limiter 비율·Geometry 정규화 때문에 branch를 고정해도 전체가 선형이 아니다. 이 검사를 전체 Solver의 exact compiler로 확대하지 않는다.

## 4. 모든 미래를 정확히 유지하는 소수 변수의 보편 해법은 없다

동일 면적·Profile, Geometry/Gravity/Reaction/Decay OFF, outgoing limiter 비활성인 n texel path를 생각한다. 포화도 차이에 의한 양방향 positive-part는 순수지에서 차이로 합쳐져

\[
q_{t+1}=Aq_t,\qquad A=I-\alpha L_{\rm path},
\quad 0<\alpha<1/2
\]

가 된다. 모든 q가 양수인 작은 열린 영역에서도 이 모델을 쓸 수 있다. 첫 texel의 물량 \(y_t=e_1^Tq_t\)만 관측한다.

\[
\mathcal O_n=\begin{bmatrix}e_1^T\\e_1^TA\\\cdots\\e_1^TA^{n-1}\end{bmatrix}.
\]

k번째 거듭제곱은 첫 texel에서 k edge보다 멀리 닿지 않으며, 열 k+1의 계수는 유일한 최단 경로의 \(\alpha^k\ne0\)이다. 이 행렬은 위쪽 성분이 0인 삼각 형태로 대각이 1,α,…,αⁿ⁻¹이므로 rank n이다.

**결론:** 임의 초기 상태에서 첫 texel의 n개 시점 값을 정확히 재현하는 선형 축소 모델은 최소 n차원을 필요로 한다. differentiable encoder E:ℝⁿ→ℝᵐ와 differentiable reduced rollout H가 열린 집합에서 \(H(E(q))=\mathcal O_nq\)를 만족한다고 요구해도 chain rule의 rank로 m≥n이다. 비연속 실수 부호화나 제한된 초기 상태 집합까지 배제하는 정리는 아니다.

시간 범위를 H<n−1로 줄이면 같은 행렬의 H+1개 행 rank는 H+1이다. 이 예에서는 **얼마나 먼 미래까지 보호/예측할지**가 최소 정보량에 직접 영향을 준다. 시간은 discrete Step 수이며 dt를 바꾸면 비교 계약도 달라진다. 작은 α의 먼 영향은 아주 작을 수 있으므로 exact rank 하한을 실용적인 근사 차원 하한으로 오용하지 않는다.

[P] 이는 고전 observability [R26]를 이 graph에 적용한 증명이다. 새 Complexity 정리나 MDSSP만의 한계가 아니다. 다만 모든 mesh·모든 입력·모든 미래를 소수의 대표 State로 정확히 계산하겠다는 연구 목표는 버릴 근거가 된다.

## 5. Geometry 보호의 강도와 수송 보호의 강도는 다르다

### 5.1 현재 물이 균일하면 Geometry 차이가 숨을 수 있다

고정 형상의 symmetric diffusion 단계에서 \(w'=w-L(g)w\)라 하자. g→ĝ의 한 Step 영향이 0일 조건은

\[
[L(\hat g)-L(g)]w=0.
\]

균일 w는 어떤 해당 Laplacian에서도 kernel에 있으므로 형상이 달라도 현재 이동은 0이다. 모든 w에서 같은 결과를 요구하면 L(ĝ)=L(g)가 필요하다. 즉 한 장면의 균일/빈 물막에 대한 ‘보호 성공’은 대단히 약한 검사다.

현재 w에서 차이가 없어도 다음 \(L(g)w\) 방향 또는 새 input 뒤에는 차이가 생길 수 있다. 고정 선형 경로의 N Step 보호는 \(CA^kw=C\widehat A^kw\) (필요한 k 범위), 모든 입력까지 포함하면 \(CA^kB=C\widehat A^k\widehat B\) 같은 추가 조건을 요구한다. 일반 coupled nonlinear 모델에서 이 행렬 식을 그대로 사용하지 않는다.

### 5.2 Height를 보호하는 방법과 후속 반응을 보호하는 방법

[C,D] cavity=0인 `IceReactionLab`의 world 요청 높이:

\[
g(i,w)=0.035\min(i,4)+0.0063\min(w,2).
\]

두 채널이 cap 아래이고 반응만으로 Ice→Water extent가 m만큼 발생하면 \(\Delta g=-0.0287m\). 같은 초기 상태에서 extent의 편집 차이를 δm라 하면, 다른 입력/효과가 없는 이 branch에서

\[
|\delta g|=0.0287|\delta m|.
\]

따라서 geometry tolerance εg는 \(|\delta m|\le\epsilon_g/0.0287\)를 강제한다. 반면 i>4,w>2가 전체 비교 구간 유지되면 해당 height의 변화는 0이다. **같은 목표라도 cap branch에 따라 보호 가능한 자유도가 달라진다.**

형상 동일은 Ice 상태·융해 속도 동일을 뜻하지 않는다. Saturation은 저장 State를 참조하고 reactionRequest도 unclamped Ice를 읽는다. geometry를 유지하는 숨은 초과량 편집은 미래를 바꿀 수 있다. 이 자유도는 의도적으로 쓸 수도, 보호 검사에서 막아야 할 수도 있다.

### 5.3 현재 두 반응식의 대수적 feasible witness

이하 i,w,h는 **ReactionScratch 입력 plane의 면적당 값**이다. 전체 Input/Transport/Decay를 포함한 실행 가능한 contact timeline이라고 주장하지 않는다. 한 continuous substep dt=δ=1/240, limiter 비활성, h>τ=0.25라 하면 실제 두 rule은

\[
m=\tfrac12 i(h-\tau)\delta,\quad
c=\tfrac12 hw\delta,\qquad
i'=i-m,\ w'=w+m,\ h'=h-0.45m-c.
\]

i=5,w₀=3,h₀=0.5에서 baseline h′를 H*라 두면 H*=0.495703125이다. 원하는 h>h₀를 정한 뒤

\[
w(h)=\frac{2(h-H^*)}{\delta h}-0.45i\frac{h-\tau}{h}
\]

로 놓으면 **h′=H***가 정확히 유지된다. h=0.501이면 w≈3.94760479, 융해량은 baseline보다 1/96000 증가한다. 두 경우 모두 i′>4,w′>2이고 초기·최종 height는 0.1526이다. 반응 수요는 10% depletion 제한보다 충분히 작아 위 δ 선택과 limiter 비활성 가정에 모순이 없다.

이 결과가 보여주는 것은 ‘보호 편집이 언제나 불가능하다’가 아니라는 작은 대수적 사례다. 보호하는 것은 **그 한 substep 끝의 Heat와 capped height**뿐이다. 물 총량·Ice 총량·전체 Heat 곡선·이후 probe는 보호하지 않는다. 새 물 입력 비용도 공짜가 아니다. geometry coupling은 활성 변화가 없는 사례이므로 핵심 연구 데모로 쓰지 않는다. 실제 U-input의 bounds·접촉 형상·전 단계 수송/Decay·복수 substep을 통과하는 witness는 아직 없다.

이 식은 표준 optimizer가 쉽게 풀 수 있는 강한 sanity baseline이다. 이보다 못한 새 편집 방법은 버려야 한다.

## 6. 규칙 재정의로 문제가 없어지는지 먼저 확인한다

고정 경로를 따라 같은 물질이 N번 이동하고 각 이동에서 f만큼 남긴다는 이상화에서는 생존 비율이 (1−f)ᴺ이다. hop마다 같은 f를 쓰면 경로 분할에 의존한다. 단방향 경로 구간 길이 ℓ에 대해 \(f(\ell)=1-\exp(-\kappa\ell)\)라 두면 두 구간의 생존 비율 곱은 합친 길이의 비율과 같다.

이는 표준 지수 감쇠의 semigroup 성질이고 새 알고리즘이 아니다. 또한 **현재 MDSSP의 확산 flux·분기·공급량 경쟁 전체에 대한 격자 불변성 증명이 아니다.** 확산성 random walk에서 이동 거리 총합은 refinement에 따라 발산할 수도 있어, 단순히 distance 계수를 붙이면 해결된다고 하지 않는다. 시간 노출·표면 접촉·순수송/총수송 중 어느 의미를 의도하는지부터 선택해야 한다.

따라서 방향3의 갈림길은 다음과 같다.

- 기존 fine preset의 결과를 보존해야 한다면: 누적 유입과 미해결 내부 이동을 재현하는 축소 문제.
- 해상도 변화에도 의미가 유지되는 제작 규칙이 목표라면: rule 의미와 discretization을 먼저 재정의. 그 뒤 기존 FV/반응 모델로 충분하면 새 closure 연구 중단.

두 목표를 혼용해 새로운 모델이 원래 결과와 다르다는 사실을 ‘coarse 오차 감소’로 보고하지 않는다.

## 7. 수학적으로 확인한 것과 아직 확인하지 못한 것

| 주장 | 현재 수준 |
|---|---|
| 두 texel의 m,p,a 갱신식·보존/양수성·누적 오차 상한 | 명시한 discrete 이상 모델에서 대수적으로 유도 |
| 동적 coefficient를 허용하는 닫힌 graph의 미래 잔류/물 L1 bound | saturation-only·단일 전환·고정 Capacity·충분한 dt 조건에서 유도. open block/전체 MDSSP 적용 불가 |
| 같은 식이 실제 GPU 결과를 허용오차 안에서 재현 | 미실행 |
| 외부 port/다중 반응/동적 Geometry까지 작은 표현으로 확장 | 미해결 |
| 전체 미래를 exact하게 유지하는 범용 저차 압축 | path 예제에서 제한을 입증. 보편 주장 불가 |
| capped geometry 아래 보호 편집의 반응 단계 witness | 명시한 한 substep 식에서 유도 |
| 실제 U-input에서 유용한 편집 과제를 만족 | 미검증 |
| 위 방법이 기존 ROM/optimizer/AMR보다 우수 | 미검증 |
| 새로운 논문 Contribution | 미입증 |

이 문서의 진전은 ‘논문이 된다’는 결론이 아니라, **독립 갱신이 가능한 최소 출발점과 그 확장을 막는 정확한 경계**를 확보한 것이다.
