# Contribution 후보 장부

현재 안내 갱신: **2026-11-03**. 아래 유력도는 채택 확률이 아니라 **현재 근거와 연구 추진 가치의 질적 판단**이다. 현재 강한 Contribution으로 확정된 후보는 없다. §1–9는 탐색 과정의 판단을 보존한다. 현재 판단은 다음 표와 §10–14, 빠른 읽기는 [[90_Research-Archive/Research-Notes-2026-10/00_Overview|연구 안내]]를 따른다.

| 현재 순위 | 후보 | 확인된 출발점 | 가장 큰 공백 | 판정 |
|---|---|---|---|---|
| **1** | **A: 목표 진행·보호 편집** | 결합 Solver와 실제 Heat 접촉 48개의 시간 조정 가능성, 제한 연속 모델의 조건부 입력 해 | 실제 접촉으로 목표와 보호를 함께 달성한 사례 및 표준 최적화 대비 필요한 새 방법 | 목적 적합성이 가장 높음. **기여 미입증** |
| **2** | **B: 반응·수송 규칙의 의미 일관성** | 현재 `inflowFraction` 요청/소비 의미와 경로·방향·경쟁 반례 | 표준 배분/kinetics/이산화로 충분하지 않은 실질적 문제와 해법 | 모델 계약을 먼저 고정. **알고리즘 기여 미입증** |
| **3** | **E: 미래 반응을 고려한 계산 축소** | 제한 모델의 수지·오차 상한과 계산 생략 조건 | 열린 경계·다중 반응·동적 형상에서 값싸고 유용한 방법 | 별도 탐색. **실용성·신규성 미입증** |
| 보류 | 공통 State–Reaction–Geometry 시스템 자체, Meso 강건성 | 구현과 제한된 실험 | 가까운 범용 시스템/합리적 모듈식 대조 대비 학술적 차이 | 현 상태의 시스템 통합 주장은 약함 |

**읽는 방법:** 지금 결론만 필요하면 위 표와 [[90_Research-Archive/Research-Notes-2026-10/02_Evidence-and-Current-Judgment|증거·현 판정]]을 읽는다. 수식·반례를 검토할 때만 해당 절의 링크로 내려간다. [C] 코드, [E] 실행 증거, [D] 조건부 유도, [H] 제안을 혼동하지 않는다.

## 1. 후보와 판정

| 후보 | 유형 | 현재 근거/차이 | 강한 심사 반론 | 현재 강도 | 추진 조건 |
|---|---|---|---|---|---|
| 공통 State–Reaction–Geometry 모델 | 시스템 | 선언 규칙·국소 flux·형상 결합 구현, 기전 실험 | Günther/Chen/Lo의 범용·결합 선례가 있고 모듈식 대조도 확장 가능 | 낮음 | 기존 모델의 중요한 제작 부담/표현 제약을 해결하는 사례 필요 |
| 목표 진행·후속 반응 역설계(방향1) | 응용·제어/알고리즘 | 현재 미구현. 관측 적합과 후속 동작을 동시에 지정 | loss를 추가한 표준 최적화와 무엇이 다른가? | 낮음 | 모호성의 중요성과 표준 optimizer의 구체적 한계. 방향2 평가 층으로 우선 결합 |
| 다른 현상을 보존하는 수정(방향2) | 알고리즘·제작 시스템 | 현재 미구현. 제한 입력·반응·공유 형상의 보상 문제 | 국소 편집·제약 보존은 기존. SQP로 충분하지 않은가? | 미입증, 주력 탐색 가치 중간 | 강한 동일 조작 Baseline 대비 edit/protection 품질–비용의 실질적 차이 |
| 혼합/경로 coarse 표현(방향3) | 모델·알고리즘 | 평균화/내부 이동 반례와 제한된 두 texel의 exact closure·tail bound 유도. 범용 closure 미확보 | 기존 compartment·memory ROM·subgrid/microgrid의 적용 아닌가? | 문제·최소 해법 구체화, 해법 신규성 미입증 | 외부 port/동적 Geometry의 독립 갱신, 실제 진행 영향과 기존법 대비 총 비용 증거 |
| 후속 오차를 고려한 Sparse Geometry 갱신 | 알고리즘 | 결합과 선택형 Sparse 구현. 새 오차 제어 없음 | dirty/halo/표준 오차 추정으로 충분할 수 있음 | 매우 낮음 | Dense 대조에서 중요한 실패와 단순 해법의 한계가 먼저 필요 |
| Meso 복원·cavity 강건성 | 모델·알고리즘 | 현재 구현과 PERF-043 | 표준 LS/국소 모델 정리로 충분한 것 아닌가? | 매우 낮음 | 실제 asset에서 중요한 수송/표현 실패를 새로 확인할 때 재개 |

## 2. 신규성으로 간주하지 않는 항목

GPU 사용, 여러 State 채널, 2-pass gather, outgoing limiter, Normal Map 적분, cavity filling, active tile/halo, 기존 속도 최적화, 버그 수정, 이름에 따른 기본 외관 binding은 단독 Contribution으로 주장하지 않는다. 이들이 새 문제의 구체적 해법에 필수인 경우에만 그 역할을 설명한다.

‘State가 형상을 바꾸고 그 형상이 다음 이동에 참여한다’도 넓은 최초성 주장은 불가하다. 형상에 반영하는 양이 Capacity로 제한되는 현 계약에서 저장량 보존과 부피 보존을 동일시하지 않는다.

## 3. 보류·제외와 재개 조건

- **사용자 제외:** 축적 순서/층 표현 방향4. 새 기능 목록에 다시 넣지 않는다.
- **현재 보류:** 물리적으로 정확한 다중 물질 Solver로의 전환, Chart 대표 높이의 독립 Contribution화, 새로운 Sparse scheduler의 선제 개발.
- **비교 중단 유지:** 같은 선언/수치 provider를 쓰는 U/M backend 선택만으로 제작 시간 우위를 측정하는 연구.
- **연구 재개:** 방향1·2·3의 문헌/수식 분석은 진행한다. 실제 앱/실험 실행은 명시적 재개 요청 전 중지한다.

## 4. 논문 기여로 전환하는 최소 기준

문제의 중요성, 강한 기존 방법의 구체적인 한계, 새 방법의 실질적 차이, 독립적인 재현·미사용 조건 검증을 함께 요구한다. 새로운 문제나 분석만의 기여도 가능하지만, 일반적인 평균화/관측성/제약 최적화 성질을 MDSSP에 대입한 설명만으로 새 정리를 주장하지 않는다.

실패 기준을 피하려고 목표·조작 범위·Baseline을 사후 변경하지 않는다. 변경이 필요하면 이전 결과와 이유를 보존한다. 사람의 생산성을 주장하려면 실제 제작 과제/참가자 증거가 필요하며, AI 보조 실험은 그 범위를 명시한다.

세부 정식화와 제안은 [[90_Research-Archive/Research-Notes-2026-10/10_Authoring/04_Inverse-Authoring|방향1]], [[90_Research-Archive/Research-Notes-2026-10/10_Authoring/05_Protected-Editing|방향2]], [[90_Research-Archive/Research-Notes-2026-10/30_Deep-Analysis/06_Coarse-Reactive-Transport|방향3]]을 따른다.

## 5. 폴더 정리 후 분석에 따른 갱신

[[90_Research-Archive/Research-Notes-2026-10/90_Reference/09_Analytical-Findings|후속 분석]]에서 방향1의 capped 관측 모호성, 방향2의 threshold 아래 0 민감도, 방향3의 동일 이차 모멘트/상이한 융해 request와 capped 높이 평균화 반례를 유도했다. 문제의 구체성은 높아졌지만 실제 허용 rollout·보호 과제·새 closure의 성공을 확인하지 않았으므로 위 유력도는 상향하지 않는다.

다음 판별의 초점은 **1의 문제를 2의 목표/후속 평가에 사용하고, 3에서는 표준 양수 quadrature가 충분한지 먼저 따지는 것**이다. 추가 문헌 R12–R13 때문에 ‘소수 대표 상태를 저장’ 자체의 신규성 주장은 더욱 제한된다.

후속 [[90_Research-Archive/Research-Notes-2026-10/30_Deep-Analysis/11_Contribution-Proof-Obligations|심화 추론]]은 방향3에서 **같은 전체 State histogram·같은 고정 graph·외부 순유량 0이어도 내부 이동량과 inflowFraction 전환량이 다른 네 texel 반례**를 제시했다. 알고리즘 탐색의 우선순위는 방향3이 가장 구체적이다. 다만 hop 기반 규칙의 격자 의존성을 보존할 필요, edge 정보의 독립 갱신, 표준 graph/microgrid/fine Sparse 대비 비용을 입증해야 한다. 신규성이 확보됐다는 평가로 상향하지 않는다.

방향2는 보호 오차의 수지 하한·도달 가능성 바깥쪽 근사를 추가 후보로 삼되, 동일한 사전 검사를 쓰는 표준 optimizer와 비교한다. 방향1은 단독 기여보다 방향2의 목표/평가로 유지한다. 대표 상태·cubature·적응 가중치·도달 불가능 진단·행동 equivalence의 기존 연구 R14–R24도 확인했다.

## 6. 실험 없는 추가 연구 이후

[[90_Research-Archive/Research-Notes-2026-10/30_Deep-Analysis/12_Exact-Submodels-and-Limits|정확한 최소 모델]]에서 닫힌 두 texel의 내부 이동/유입 전환은 총량 m과 잔여 반응 잠재량 p로 독립 갱신할 수 있고, 내부 모드를 생략할 때의 미래 총 잔류 오차를 p로 제한할 수 있음을 유도했다. **일반 block의 외부 port·잔류 위치·동적 Geometry에서는 아직 닫히지 않는다.** 두 셀의 변수 변환 자체가 차원/속도 개선은 아니며, 이미 구현된 기능도 아니다.

같은 분석은 path 확산의 미래 관측에 대한 차원 하한, cap 아래 형상 보호의 융해량 제한, 한 reaction substep의 Heat/height 보호 witness도 포함한다. 실제 production U-input의 feasible witness와 GPU 일치는 미확인이다.

추가로 닫힌 graph의 saturation-only 수송·단일 유입 전환·충분한 dt에서는 동적 Geometry를 허용하는 잔류/물 오차 bound를 유도했다. 이것은 임의 다중 State 전체 Solver의 인증이 아니다.

[[90_Research-Archive/Research-Notes-2026-10/30_Deep-Analysis/13_Method-Blueprints-and-Decision|방법별 판정]]에서 A(내부 반응 잠재량·port 기반 block)를 알고리즘 탐색 1순위, B(보호 목적에 맞춘 편집/축소)를 목적 적합성 1순위로 유지한다. C(제한적 보호 인증)는 보조 후보, 방향1은 B의 목표/평가다. R25–R33의 memory·목적별 ROM·hybrid verification·reward abstraction·positive reduction·maximum principle 선례 때문에 단순 조합의 신규성은 여전히 낮다.

2026-10-28 [[90_Research-Archive/Research-Notes-2026-10/30_Deep-Analysis/14_Residual-Budget-Critical-Review|추가 고찰]]에서 A를 더 좁혔다. 열린 경계/중력에도 조건부 potential 상한을 만들 수 있지만, cycle을 무기한 허용하면 전체 물량 bound로 퇴화한다. 유한 시간·outgoing 비율·gross inflow budget은 이 한계를 완화하나, 잔류 오차만으로 물 수송/Geometry의 생략을 정당화할 수 없다. 첫 방법은 fine 메모리를 유지하는 제한적 연산 생략으로 검토하고, 수송/경계 관측을 함께 보호해야 한다. R34–R35의 표준 Bellman 원리와 겹치므로 후보의 신규성 평가는 상향하지 않는다.

## 7. 공동 오차·형상 민감도 분석 이후

[[90_Research-Archive/Research-Notes-2026-10/30_Deep-Analysis/15_Joint-State-Error-and-Geometry-Bounds|15]]에서 단일 Incoming 전환 모델의 **물+잔류 공간 L1 오차**를 실제 flux 차이로 제한했다. raw edge 일부 삭제는 limiter 재분배를 고려해도 한 Step 2V 상한을 갖는다. 한편 고정 계수에서도 반응이 실행 간 오차를 증폭하는 두 texel 반례가 있으므로, 총량 보존을 근거로 장기 오차 비증폭을 가정할 수 없다.

현재 `effectiveLocalNormal`의 LS 행렬은 정적 mesh 기준이어서 높이→Normal 민감도 일부를 사전 계산할 수 있다. 방향3의 저비용 판정과 방향2의 형상 보호 평가에 활용할 여지가 있지만, 중력 정규화 margin·동적 Concavity·다중 반응·실제 비용을 해결하지 못했다. **방향3은 알고리즘 탐색의 구체성 1순위, 방향2는 제작 목적 적합성 1순위, 방향1은 방향2와 결합**하는 판단을 유지한다. 기존 adaptive multiresolution/RD 선례 R36–R38 때문에 이 분석 자체를 새 Contribution으로 평가하지 않는다.

## 8. 저비용 판정 구성 이후

[[90_Research-Archive/Research-Notes-2026-10/30_Deep-Analysis/16_Low-Cost-Certificates-and-Sleep-Horizons|16]]에서는 민감도 recurrence 대신 공통 하한·수지를 써서 두 실행의 공동 오차를 제한했다. 닫힌 saturation-only 영역의 장기 2B 상한, 중력/limiter를 포함하는 outgoing 비율 α 상한, α 구간별 초기 물량을 사용하는 O(K) 기간 판정을 구성했다. 따라서 방향3은 **저비용 충분조건의 구체적 구성**까지 진전했다. 다만 실제 기간/비용·열린 경계·다중 반응의 유용성은 미입증이다.

cap 위 State 변화의 높이 재계산 생략은 이미 `StateFinalize.glsl`에 구현돼 있어 별도 새 기여에서 제외한다. 높은 해상도에서 α가 1로 퇴화할 수 있다는 분석과 열린 block 반례는 후보의 적용 범위를 좁힌다. R39–R41의 invariant-domain/self-triggered/set-valued 선례를 고려해 **신규성 평가는 상향하지 않는다.** 이전과 마찬가지로 방향3은 알고리즘 탐색, 방향2는 제작 목적 적합성이 가장 구체적이다.

## 9. 열린 경계 분석 — 단순 합성안 보류

[[90_Research-Archive/Research-Notes-2026-10/30_Deep-Analysis/17_Open-Boundary-Contracts-and-Composition|17]]은 공통 유입 cohort·port-time outgoing을 포함한 오차와 block 합성을 유도했다. 그러나 **단순 α-bin block 합성은 동일 조건의 전체 영역 bound보다 느슨**하며, 정확하게 유지되는 이동까지 예산에 넣는다. 이 하위안을 주력 구현 후보에서 보류한다. 방향3 전체의 불가능 판정은 아니다.

코드에서 더 구체적인 문제를 확인했다. 경계 source의 양과 경계 raw가 같아도 내부 raw outgoing 합이 달라지면 source limiter 때문에 경계 Flux가 달라진다. 또 채널별 물질 flux가 0이어도 적층→Normal/weight를 통해 외부 수송이 달라질 수 있다. 다음 탐색 후보는 **내부 outgoing 범위·Geometry stencil 영향을 포함해 내부 갱신 생략의 충분조건을 판정하는 경계 계약**이다. 일부 branch 조건은 유도했지만 저비용 갱신·실제 중요성은 미입증이다. R42–R44의 port reduction/보존 장부/합성 선례와 경쟁해야 하며 신규성 평가는 유지한다.

## 10. 연구 목적을 넓힌 최신 비교 — 2026-10-28

[[90_Research-Archive/Research-Notes-2026-10/18_Research-Landscape-and-Selection|18]]에서 기존 1·2·3과 새 분기를 일곱 방향으로 비교했다. 세부 후보가 모두 독립된 Contribution이라는 뜻은 아니다.

| 방향 | 현재 판정 | 기존 장부와 달라진 점 |
|---|---|---|
| A 보호 편집 | 목적 적합성 기준 주력 탐색, 신규성 미입증 | 기존 1+2 유지. 진단 F와 재사용 C는 보조 평가로 먼저 사용 |
| B 해상도 변화에 대한 재질 규칙의 의미 일관성 | **새 후보 중 우선 판별**, 새 해법 필요성 미확인 | 유입당 전환의 경로 분할 의존성·Incoming 합의 거리 정보 손실을 분리. 표준 거리 보정/가중 gather로 충분하면 독립 기여 중단 |
| C 동작 명세 기반 자산 재사용 | 조건부 시스템/제작 후보 | profile 복사에서 반응 순서·배출 비율 등 동작의 재사용으로 과제 명확화. 기존 weathering transfer와 경쟁 |
| D 미래 반응을 위한 상태 식별 | 사용 시나리오가 있을 때만 추진 | cap 모호성의 별도 응용. 내부 State를 이미 아는 정상 재생에는 필요 없음 |
| E 미래 상호작용을 보존하는 LOD | 제한된 독립 알고리즘 탐색 | 기존 방향3. 분석량이 많다는 이유로 전체 연구 1순위로 두지 않음. 단순 block bound 보류 유지 |
| F 실패 원인·수정 가능성 진단 | 독립 기여 가능성 낮음, A의 보조 | 장부와 인과효과 구분. 표준 ablation/optimizer보다 필요한 차이 미입증 |
| G Meso 불확실성에 대한 동작 강건성 | 보류 | PERF-043의 약한 실제 효과 때문에 새 실패 증거 전 주력화하지 않음 |

이 표의 우선도는 실험 재개/구현 지시가 아니다. 사용자가 제외한 기존 방향4는 계속 제외한다. 새 기여가 확보됐다는 판정도 하지 않는다.

## 11. A/B 심화 이후 — 문제 근거와 해법 신규성의 분리

[[90_Research-Archive/Research-Notes-2026-10/10_Authoring/19_Protected-Editing-Feasibility-and-Response-Coordinates|19]]에서 A의 제약 종속성과 반응 진행 좌표를 유도했다. Heat 전 과정 보호는 제한 모델에서 Ice 진행을 고정하므로 잘못된 편집 과제를 제거할 수 있다. 공급 비율/substep을 포함한 이산 Z는 최종 Ice 보호를 표현하지만, 그 자체는 정보 압축/새 optimizer가 아니다. **A는 목적 적합성 주력 후보를 유지하되 실제 입력 witness·표준법 대비 필요성은 미입증**이다.

[[90_Research-Archive/Research-Notes-2026-10/20_Solver-Semantics/20_Transport-Reaction-Semantics-and-Refinement|20]]에서 B의 순수송/교환량 차이, 거리 보정 이후 stencil 방향성, 경쟁 전환의 분할 반례를 유도했다. **B의 문제 정의는 더 구체적**이다. 그러나 표준 병렬 kinetics·gradient absorption PDE·operator splitting을 강한 대조로 추가했으므로 해법 신규성은 올리지 않는다. 네 이웃의 분석을 현 여덟 방향 GPU 오류의 실측으로 취급하지 않는다.

현재 탐색의 우선순위는 A와 B를 유지하고 E는 제한된 별도 탐색이다. ‘문제를 찾았음’, ‘조건부 유도’, ‘구현 성공’, ‘기존법 대비 새 기여’는 계속 구분한다.

## 12. 양수 입력 구성 이후의 판정

[[90_Research-Archive/Research-Notes-2026-10/10_Authoring/21_Constructive-Controls-and-Reaction-Contracts|21]]에서는 A의 제한 연속 모델에 양수 입력을 직접 구성했다. 입력 여유가 있으면 동일 초기·최종 Ice/Water/Heat와 동일 총 Heat 입력에서도 중간 진행을 바꿀 수 있다. **과제의 조건부 가능성 근거가 강화됐으나, 현 contact/GPU의 성공·새 optimizer의 기여는 아니다.** A를 주력 탐색으로 유지하되 표준 제어/최적화에도 이 구성과 초기값을 허용한다.

B는 현 inflowFraction이 신규 유입 기반 요청을 전체 보유량에서 처리함을 확인했다. 신규분만 소비하는 대안은 다른 모델 계약이며 표준 자원 배분으로 다룰 수 있다. 따라서 B의 우선 과제는 **일관된 의미와 재사용 조건을 정의하는 것**이다. 새 수치 알고리즘의 필요성은 아직 입증하지 못했다. 기존 rule 결과 불변·새 rule의 양의 소비·유한 공급을 동시에 요구하는 조합성 기준은 불가능하므로 사용하지 않는다. E는 이번 분석으로 평가가 달라지지 않았다.

## 13. 실제 편집 자유도·형상 경로를 통한 A의 축소

[[90_Research-Archive/Research-Notes-2026-10/10_Authoring/22_Protected-Editability-and-Geometry-Mediation|22]]는 21의 양수 입력 witness가 기존 입력의 시간 재배치를 허용한다는 점을 명시했다. 추가만 가능한 조작과 동일 총 입력을 동시에 요구하면 비자명한 입력 편집은 불가능하다. 유한 contact basis에서는 보호 제약의 rank와 입력 bound가 실제 자유도를 결정한다. cap 아래 Ice↔Water 높이의 보호 한계는 이미 12에서 유도했으므로 신규 기여로 중복 계산하지 않는다.

A의 강한 실험적 질문은 **공유 Geometry가 보호 편집의 가능 범위에 실제로 어떤 차이를 주는가**다. 기준 궤적의 시간별 Geometry를 재생하는 진단은 초기에 형상 하나를 고정한 기존 E ablation과 다르며 현재 미구현이다. full과 이 재생 대조가 같은 기준 궤적에서 출발하게 해야 기전 비교가 해석 가능하다. 기전 효과가 확인돼도 표준 최적화/모듈식 구조 대비 연구 기여는 별도 입증 사항이다. A의 우선순위는 유지하지만 신규성 등급을 올리지 않는다.

## 14. 코드가 제공하는 실제 입력 자유도

[[90_Research-Archive/Research-Notes-2026-10/10_Authoring/23_Contact-Control-Space-Audit|23]]에서 `b_heated`의 서로 다른 48개 시점에 같은 spatial stamp의 Heat Add가 존재함을 확인했다. 두 strength를 `+ε/−ε`로 조정하면 현재 asset 형식 안에서 texel별 시간 합산 **요청 입력**을 보존할 수 있다. 무한차원 연속 입력 해와 실제 contact basis 사이의 한 공백을 좁혔다. 그러나 최종 State·Geometry·보호 지표를 유지하는 구체적인 접촉 입력은 아직 없다. A의 **문제 실행 가능성 근거만 부분 강화**, 알고리즘 신규성·실험적 성공 등급은 그대로다.
