# 보호 편집의 양수 입력 구성과 유입 반응의 경쟁 계약

작성: **2026-10-28 / Asia/Seoul**. [[90_Research-Archive/Research-Notes-2026-10/10_Authoring/19_Protected-Editing-Feasibility-and-Response-Coordinates|19]]와 [[90_Research-Archive/Research-Notes-2026-10/20_Solver-Semantics/20_Transport-Reaction-Semantics-and-Refinement|20]]의 후속.

**코드·문헌·기호 분석만 수행했다. 앱·GPU·빌드·수치 실험·학습 및 제품 코드 변경은 없다.** 아래 양수 입력의 존재는 제한된 연속 국소 모델의 결과이며 production contact/GPU의 성공 사례가 아니다.

## 1. 이번에 추가된 결론

- **A:** 단순히 같은 exposure를 갖는 Heat 곡선을 제안하는 단계를 넘어, 주어진 반응식을 만족하는 **음이 아닌 Heat 입력**을 역으로 구성할 수 있다. 충분한 입력 여유가 있는 제한 모델에서는 최종 Ice·Water·Heat를 같게 두고 중간 진행을 다르게 만드는 해가 존재한다. 추가 조건에서는 총 Heat 입력도 같게 만들 수 있다.
- **B:** 현 `inflowFraction`은 신규 유입으로 request를 계산하지만, 경쟁의 공급 상한은 **반응 직전 전체 보유량**이다. 여러 rule을 합치면 신규 유입보다 많이 소비할 수 있다. 이는 코드의 명시된 계산에서 유도한 것이며 ‘유입에 의해 촉발’과 ‘유입분만 소비’라는 다른 의미를 구분해야 한다.
- 두 결과 모두 새 원리의 발명이 아니다. A는 constrained trajectory generation/반응 좌표 선례, B는 표준 자원 배분으로 먼저 다룰 수 있다. **A의 feasible 기준 문제는 진전했고, B는 새 알고리즘을 찾기 전에 모델 계약을 명확히 해야 한다는 판단이 강해졌다.**

## 2. A의 국소 연속 모델 — 실제 계수와 제외 조건

[IceReactionLab](../../../../../Assets/SurfaceProfiles/IceReactionLab.SRProfile)의 반응 계수를 쓰되, 공간 수송을 제거한 닫힌 한 영역으로 한정한다. 초기 이후 Ice/Water 입력은 없고 Heat 입력 u(t)≥0만 허용한다. i,w,H는 기준 면적당 양이다.

$$
\dot i=-k i(H-\tau),\quad
\dot w=k i(H-\tau),\quad
\dot H=u-\nu k i(H-\tau)-\gamma H w-d,
$$

여기서 `k=0.5`, `τ=0.25`, `ν=0.45`, `γ=0.5`, `d=0.015`, 그리고 H>τ인 구간만 사용한다. M=i+w는 일정하다. 공급 limiter·이산 splitting·반응 substep은 이 연속 모델에 없다.

**Decay 확인:** [StateMath.glsl::decayAmountPrepared](../../../../../Shaders/Simulation/Solver/StateMath.glsl)는 `DecayRate×AreaScale×Retention×dt`를 양으로 빼고 현재량으로 제한한다. 이 Profile의 protection은 0이므로 양수 H 구간의 연속 대응은 상수 d다. `−dH`라는 비례 감쇠로 바꾸면 코드와 다른 분석이다. 온도·열역학의 물리 모델이라는 뜻도 아니다.

현재 Profile의 Water/Heat는 실제로 수송하므로 위 국소 축약이 production 전체와 같지 않다. 수송을 제거하거나 균일 영역으로 이상화한 sanity reference다.

## 3. 진행 곡선으로부터 필요한 입력을 직접 구한다

z(t)=−log(i(t)/i₀), i₀>0라고 하면 z'=k(H−τ)>0다. 따라서

$$
i=i_0e^{-z},\quad w=M-i_0e^{-z},\quad H=\tau+z'/k,
$$

$$
u[z]=z''/k+\nu i_0e^{-z}z'
 +\gamma(\tau+z'/k)(M-i_0e^{-z})+d.
$$

**검사 가능한 조건:** z는 C²이고 z(0)=0, z'>0, w≥0, 0≤u[z]≤u_max를 만족해야 한다. 초기/최종 Heat는 z'(0),z'(T)를 고정하고, 최종 Ice는 z(T)를 고정한다.

이 식은 ‘원하는 Heat를 직접 덮어쓴다’는 조작과 다르다. 반응과 냉각 손실을 포함해 필요한 입력을 계산한다. 그러나 여전히 자유로운 연속 스칼라 Heat source를 허용한 것이며, 제한된 contact 위치·입력 횟수·event 양만으로 같은 곡선을 만들었다는 뜻은 아니다.

[R59–R61] 반응 진행 좌표와 출력 곡선으로 상태/입력을 복원하는 접근은 기존이다. 이 유도 자체를 새로운 differential flatness 결과나 전체 MDSSP의 flatness 증명으로 주장하지 않는다.

## 4. 음의 입력 없이 다른 중간 진행이 존재하는 조건

baseline `z₀(t)=a t`, a>0를 택한다. H₀=τ+a/k는 일정하고 i₀(t)=i₀exp(−at), w₀=M−i₀(t)다. 필요한 baseline 입력은

$$
u_0(t)=\nu i_0e^{-at}a+\gamma H_0(M-i_0e^{-at})+d>0.
$$

유한 T에서 이 입력이 u_max보다 **양의 margin**만큼 작다고 가정한다. 양의 margin이 실제 앱에서 주어졌다는 뜻은 아니다. 입력 상한이 너무 낮다면 이 구성은 적용되지 않는다.

`b(t)=t²(T−t)²`로 두고 `z_ε=at+εb(t)`라 하자. b와 b'는 양 끝에서 0이다. 따라서 모든 ε에 대해 z의 시작·끝 값과 양 끝 도함수가 baseline과 같고, 최종 i,w,H도 같다.

충분히 작은 |ε|에서는 compact 구간의 연속성으로 z'>0와 0<u[z]<u_max가 유지된다. ε≠0이면 중간 i,w,H는 달라진다. **따라서 이 연속 국소 모델에서는 허용 범위 안의 양수 입력으로 endpoint를 보호하며 중간 진행을 바꾸는 해가 실제로 존재한다.** 수치 적분으로 찾은 결과가 아니라 명시적 구성과 continuity에 의한 존재 결과다.

이 사례는 공간 수송/변화된 Geometry의 효과가 없어서 주 연구 데모가 될 수 없다. 새 optimizer가 풀어야 할 최소 sanity 과제로 쓴다. 이 모델에서도 못 푼다면 복합 장면으로 확대할 이유가 없다.

## 5. 최종 상태가 같아도 입력 비용은 같지 않다

초기/최종 상태와 Z=z(T)를 고정하고, ΔI=i₀−i(T), U=∫u dt라 두면 Heat 수지를 적분해

$$
U=H(T)-H(0)+\nu\Delta I
 +\gamma\tau\int_0^T w\,dt
 +\frac{\gamma}{k}(MZ-\Delta I)+dT.
$$

유도에는 `∫z'w dt=MZ−ΔI`를 쓴다. 따라서 두 endpoint-preserving 경로 사이의 입력량 차이는

$$
\Delta U=\gamma\tau\int_0^T\Delta w(t)\,dt.
$$

위 b≥0, ε>0 구성은 중간에 Ice를 더 일찍 줄여 w를 늘리므로 U도 증가한다. **같은 endpoint의 예쁜 진행을 얻었다고 같은 입력 비용에서 우수하다고 비교하면 안 된다.** 이 제한 모델에서는 냉각과 threshold가 timing–input trade-off를 만든다.

### 총 입력량까지 같게 유지할 수 있는가

서로 다른 시간 구간에 지지집합을 갖는 음이 아닌 smooth bump b₁,b₂를 두고, 둘 모두 양 끝에서 값과 도함수가 0이라고 한다. `z=at+εb₁−ηb₂`를 사용한다.

`F(ε,η)=∫[w(z)−w(at)]dt`라 하면 원점에서

$$
\partial_\epsilon F=\int i_0e^{-at}b_1dt>0,\qquad
\partial_\eta F=-\int i_0e^{-at}b_2dt<0.
$$

음함수 정리에 의해 충분히 작은 ε에 대해 F=0을 만족하는 η(ε)가 존재한다. 입력/상태의 margin도 작은 perturbation 아래 유지된다. 따라서 **동일 초기·최종 상태와 동일 총 Heat 입력을 가지면서 중간 진행이 다른 국소 해**도 구성 가능하다. 이때 한동안 빨라진 융해를 다른 구간에서 보상하며, 모든 시간에서 일방적으로 더 빠른 융해를 공짜로 만드는 것은 아니다.

이는 구체적인 숫자의 production witness가 아니다. 연속 입력 표현과 양의 margin을 가정한 국소 존재 정리이며, 표준 음함수 정리의 적용이다.

## 6. A에서 이제 정말 남는 공백

이 국소 문제가 표준 방법으로 풀린다는 점은 약점이 아니라 **강한 대조를 확보한 것**이다. 새 방법의 필요성은 다음에서 찾아야 한다.

| production으로 돌아갈 때 추가되는 조건 | 아직 하지 못한 일 |
|---|---|
| Heat가 접촉 영역·event 시점·양으로만 주어짐 | u[z]가 실제 허용 input basis의 범위 안에 들어가는 witness |
| Water/Heat의 공간 수송 | 보상 입력이 다른 보호 영역을 훼손하지 않는지 판정 |
| State-Driven Geometry Coupling | 국소 진행 변경이 물길·weights를 바꾸는 효과와 보호 응답 연결 |
| cap/threshold·공급 제한·적응 substep | 연속 해를 이산 production에 옮긴 오차 및 branch 변화 |
| 제작자가 정한 보호·입력 비용 | 동일 요구를 받는 SQP/continuation 대비 새 방법의 필요성 |

첫 새로운 알고리즘 후보는 여전히 **반응 진행으로 구성한 입력 후보를 공간적 보호 제약에 맞게 보정하는 방법**이다. 그러나 이것은 후보 생성+표준 SQP만으로 충분할 수 있다. 기준 대조에도 위 analytic seed를 허용한다. 새 방법만 좋은 초기값을 받게 만들지 않는다.

## 7. B에서 확인된 구현 의미: 신규 유입은 trigger인가, 소비 자격인가

다음 네 경로를 읽었다.

- [SRProfileLoader.cpp](../../../../../Source/AssetManager/Loaders/SRProfileLoader.cpp): inflowState·fraction·source mask를 읽는다.
- [ValidateSurfaceReactions](../../../../../Source/SurfaceState/Types/SurfaceReactions.cpp): 각 fraction∈[0,1]을 검증한다. 동일 inflowState의 여러 rule fraction 합에 대한 제한은 이 함수에 없다.
- [ProfilePacking.cpp](../../../../../Source/SurfaceState/GPU/Packing/ProfilePacking.cpp): rule별 fraction/source/state를 각각 패킹한다.
- [SurfaceReaction.comp](../../../../../Shaders/Simulation/Solver/SurfaceReaction.comp): request는 신규 유입에서 만들고 공급 비율의 Available은 reaction snapshot의 전체 State다.

이 조합은 **유입으로 촉발된 request를 전체 보유량에서 처리**하는 계약이다. 신규분의 소유권이나 이동 이력을 따로 추적하지 않는다.

### 코드로부터 유도되는 작은 사례

반응 직전 W 총량이 `old 1 + incoming 1 = 2`이고, 다른 소비/생성이 없다고 하자. 같은 incoming W를 기준으로 W→A, W→B가 각각 fraction=0.75, 소비 계수 1로 선언되어 있다.

request는 각각 0.75이고 총 소비 수요 1.5≤Available 2이므로 공급 비율은 1이다. 최종 W=0.5, A/B는 각각 0.75 증가한다. **신규 incoming은 1인데 총 W 전환은 1.5**다. 총량 보존·비음수성은 지켜지며, 코드의 전체 보유량 제한 계약과 모순되지 않는다.

이는 static code/dataflow의 대수적 결과다. 해당 Profile을 생성하거나 GPU로 재현하지 않았고 모든 asset에서 발생하는 버그라고 판정하지 않았다. 기존 단일 inflowFraction sanity 결과를 무효화하는 것도 아니다.

**정확한 설명:** 현재는 ‘새 유입량에 비례해 반응을 요청한다’. ‘여러 rule을 조합해도 새로 들어온 물질만 소비한다’는 더 강한 의미는 보장하지 않는다. ‘가만히 있는 물은 유입 없이 전환되지 않는다’는 성질과도 구분한다.

## 8. 신규분만 소비하고 싶다면 표준 배분 문제가 먼저다

이는 **제안된 다른 계약**이며 현재 코드를 바꾸지 않았다. Step 안의 Input/Incoming 자격을 다루며, 사용자가 제외한 축적 순서·층 모델을 재도입하는 제안이 아니다.

선택된 신규분이 N이고 여러 rule이 같은 신규분을 나눠 쓴다면, 최소한 그 inflowState의 총 소비가 N 이하라는 제약이 필요하다. 그러나 단순히 모든 rule의 fraction 합≤1로 제한하는 것은 source mask가 겹치지 않는 경우까지 과하게 제한한다.

positive Input pool P와 Incoming pool I가 있다고 하자. 같은 trigger State에 대해 Input-only rule들의 실제 소비 합이 D_P, Incoming-only가 D_I, 둘 다 허용한 rule들의 소비 합이 D_B이면 다음 조건이 필요하고, 이 두 pool만의 배분에는 충분하다.

$$
D_P\le P,\quad D_I\le I,\quad D_P+D_I+D_B\le P+I.
$$

마지막 rule들은 앞의 두 소비 뒤 남은 pool을 나눠 쓰면 된다. 추가 reactant와 여러 trigger State가 있으면 전체 State의 stoichiometric 공급 제약도 함께 요구해야 한다. 수송 중 old 물량이 얼마나 남았는지와 별개로, incoming은 이번 Step의 새 소비 자격으로만 사용한다는 선택이다.

이런 resource allocation/선형 제약 자체는 새 알고리즘이 아니다. 비례 축소·우선순위·최적화 중 어느 배분을 쓸지는 제작 계약이며, 그 차이가 결과의 재사용성에 중요하다는 증거가 필요하다.

## 9. ‘규칙을 추가해도 기존 결과는 그대로’라는 보장은 일반적으로 불가능

신규 pool이 1이고 기존 rule A가 모두 소비하도록 정해져 있을 때, A의 소비 1을 그대로 유지하면서 새 rule B에 양의 소비를 허용하면 공급을 초과한다. 따라서 다음 셋을 동시에 항상 만족시킬 수 없다.

1. 모든 기존 rule의 실제 반응량 불변.
2. 새로 추가한 rule도 양의 반응량 확보.
3. 동일한 유한 공급량과 비음수성 유지.

이는 단순한 수지 반례다. 일반적인 조합성은 **기존 결과의 불변**이 아니라 **어떤 자원 경쟁·공유 Geometry 효과가 생기는지 일관된 규칙으로 설명하고 예측하는 것**으로 정의해야 한다. 이전 시스템 기여 가설의 재사용/조합성 평가에서도 두 의미를 혼동하지 않는다.

## 10. 순수송 의미를 선택할 때도 새 Solver가 필수는 아니다

20의 양방향 flux 사례에서 실제 limiter 이후 flux F_ij,F_ji를 얻었다면

$$
\widetilde F_{ij}=(F_{ij}-F_{ji})_+
$$

로 상쇄한 directed flux를 구성할 수 있다. 각 cell의 net divergence는 원래와 같고 outgoing 합은 늘지 않으므로 **그 수송 단계만의 State 결과·공급 상한**은 유지된다. 그러나 incoming 반응 장부는 달라지므로 이후 coupled 결과는 다른 모델이다.

이것은 표준 대수적 상쇄이며 신규 기여가 아니다. 실제 cache/FP16 결과에서의 재현성·추가 비용을 측정하지 않았다. 또한 stencil 방향성·연속 flux 복원·reaction/Geometry 시간 분할 문제를 해결하지 않는다. R62 같은 기존 구조 보존 drift–diffusion 방법도 관련 대조지만 현재 임의 Profile·Geometry가 그 energy 구조를 갖는다고 가정할 수 없다.

## 11. 최신 우선순위와 기각 기준

| 방향 | 이번에 강화된 점 | 여전히 부족한 점 | 판단 |
|---|---|---|---|
| A 보호 편집 | 양수 입력·동일 endpoint, 조건부 동일 총 입력의 analytic reference 확보 | 실제 contact 제약·공간 결합·표준 optimizer 대비 필요성 | **주력 탐색 유지**, 기초 feasibility는 진전 |
| B 규칙 의미 일관성 | trigger/eligible-pool 차이를 현 코드에서 분리, 조합성의 불가능 요구 제거 | 표준 배분/kinetics/FV를 넘어서는 새 해법 | **계약 정립을 우선**, 현재는 모델·시스템 후보 |
| E 계산 축소 | 이번에는 새 결과 없음 | 기존 경계/closure 비용 문제 유지 | 별도 제한 탐색 유지 |

다음 비실행 작업은 A의 analytic input이 실제 event basis로 표현 가능한 조건과, 공간 수송을 복원했을 때 필요한 추가 제약이다. B는 현재 trigger 계약과 제안된 신규분 소비 계약 중 어느 의미를 비교하는지 먼저 고정해야 한다. 현재 계약을 조용히 수정하거나 이를 곧바로 연구 Contribution으로 포장하지 않는다.

기각 기준도 유지한다. A가 analytic seed+표준 constrained optimizer로 충분하면 특화 최적화 기여를 낮춘다. B가 표준 배분·거리/시간 kinetics·기존 공간 이산화로 충분하면 중요한 모델 개선은 될 수 있어도 새로운 수치 알고리즘 주장으로 확대하지 않는다.

**후속 조작 범위 보정:** 이 문서의 `u[z]≥0`는 두 실행의 입력이 각각 양수라는 뜻이다. 기존 입력에 대한 차이 `δu`까지 양수라는 뜻은 아니다. 동일 총 입력의 비자명한 구성은 기존 Heat 공급의 시간 재배치를 사용할 수 있어야 한다. 유한 contact basis·한쪽 방향 조작·보호 조건의 국소 차원과 시간별 Geometry 재생 대조는 [[90_Research-Archive/Research-Notes-2026-10/10_Authoring/22_Protected-Editability-and-Geometry-Mediation|22]]를 따른다.
