# 방향 2 — 다른 현상을 보존하는 수정

마지막 갱신: 2026-10-27. [[03_Development/07_Research-Directions-123|최초 통합 검토]]에서 분리한 후속 연구 정본이다. 이 파일의 내용은 제안·수식 분석이며 새 구현/실험 결과가 아니다. 로컬 앱·GPU·빌드 실행 중지를 유지한다.

공통 근거는 [[90_Research-Archive/Research-Notes-2026-10/20_Solver-Semantics/10_Forward-Model-and-Controls|forward 모델]], 문헌 출처는 [[90_Research-Archive/Research-Notes-2026-10/90_Reference/07_Related-Work|문헌 확인 수준]], 이후 연구는 [[90_Research-Archive/Research-Notes-2026-10/90_Reference/09_Analytical-Findings|분석 노트]]를 따른다.


## 1. 핵심 Research Question

최신 심화는 [[90_Research-Archive/Research-Notes-2026-10/10_Authoring/19_Protected-Editing-Feasibility-and-Response-Coordinates|19: 보호 편집의 가능 범위·반응 진행 좌표]]를 따른다. 전체 Heat 진행의 고정이 Ice 편집을 막는 조건과, 최종 Ice 보호를 누적 반응 조건으로 표현하는 범위를 추가했다. 아래 최초 과제는 이 조건을 적용해 해석하며 실제 입력 witness·새 해법의 우위는 여전히 미검증이다.

> 허용된 입력/소수 계수만 바꿔 지정한 잔류 흔적을 수정하면서, 보호한 영역의 융해 진행과 후속 반응의 변화를 제한할 수 있는가? 필요한 보상 조작의 범위를 어떻게 선택하는가?

국소라는 말은 **목표 영역**, **조작 영역**, **재계산 영역**을 각각 뜻할 수 있다. 세 영역을 동일하다고 가정하지 않는다. 목표가 국소여도 보상 Heat 입력은 다른 곳/이전 시간에 필요할 수 있다. 보호된 지표가 만족되지 않으면 ‘다른 State를 그대로 유지했다’고 쓰지 않는다.

## 2. 제약식과 어려움

기존 입력을 a₀, 목표 편집 지표를 E, 보호 지표를 P라 하면:

\[
\min_{\delta a}\;\|E\Phi(a_0+\delta a)-y^*\|^2+\lambda\|\delta a\|_W^2,
\quad \|P\Phi(a_0+\delta a)-P\Phi(a_0)\|\le\epsilon_P,
\quad a_0+\delta a\in\mathcal U.
\]

보호 대상은 초기에는 소수 영역의 Heat/Ice 총량 곡선·후속 pulse 응답처럼 유한한 지표다. 전체 State의 모든 시점을 완전히 고정하면서 연결된 일부 State를 자유롭게 변경할 수 있다고 요구하지 않는다.

[D] Dense 수학 경로에서 \(G=B(q)\), \(q'=F(q,G,a)\)이면 국소 민감도는 개념적으로 \(F_q+F_G B_q\)다. Geometry 경로를 빼면 Heat처럼 축적 계수가 0인 채널도 영향을 받을 가능성을 누락한다. 이 chain rule 자체는 새 이론이 아니다. 실제 bootstrap/이전 Geometry 의존성은 전체 상태·연산 순서로 포함해야 한다.

[C] `max` flux, outgoing limiter, 반응 threshold, supply competition, 내부 시간 세분화, 형상 Capacity clamp가 있다. AD를 연결하면 모든 분기에서 쓸 만한 gradient가 자동으로 생기는 것은 아니다. [P] TeG는 불연속 미분이 이미 별도 연구 분야임을 보여준다 [R8].

## 3. 논문으로 발전시킬 수 있는 기술적 가설

[H] **반응·형상 경로를 포함한 보호 민감도로 수정 방향을 제한하고, 실제 forward 오차를 확인하면서 조작 영역을 확장하는 방법**이, 고정 반경 편집 또는 전역의 모든 조작을 쓰는 방법보다 같은 edit/protection 품질에서 유용한 trade-off를 줄 수 있다.

첫 알고리즘 초안은 다음 정도로 제한한다.

1. 기존 rollout과 입력 basis에서 \(J_E,J_P\)를 추정한다. 처음에는 finite difference도 허용한다.
2. 작은 편집은 \(J_P\delta a\simeq0\)인 방향에서 constrained least-squares/trust-region으로 제안한다.
3. 원래 production 의미의 full-coupling forward로 edit/protection·비음수·수지를 검증한다.
4. 선형화 예측이 빗나가면 trust region을 줄이고 active regime를 갱신한다. 조작 범위가 부족하면 사전에 허용한 이웃/이전 시간 basis로 확장한다.
5. 더 넓혀도 찾지 못하면 미달/국소 탐색 실패와 완화 선택지를 보고한다. 전역 불가능 인증으로 표현하지 않는다.

[D,H] 후속 분석에서 `ice_melting`은 Heat/면적=0.20 근방의 작은 변화에는 request 민감도가 0이지만, 허용된 +0.10 입력으로 threshold=0.25를 넘으면 양의 request를 만들 수 있음을 유도했다. 따라서 진전이 없을 때 단순히 trust region을 줄이는 것으로 충분하지 않을 수 있다. 선언된 event margin을 보고 유한 trial을 검토하는 초안을 추가하되, 다중 크기 finite difference·multi-start·derivative-free와 비교한다. 이것은 전체 보호 제약의 feasible witness나 새 알고리즘 검증이 아니다. [[90_Research-Archive/Research-Notes-2026-10/90_Reference/09_Analytical-Findings#4. 방향 2: 0 민감도와 유한 편집의 실행 가능성은 다르다|후속 분석 §4]]를 따른다.

**여기서 1–5는 기존 기법의 합성 초안이다.** 새 알고리즘으로 확정하지 않는다. full Jacobian으로 같은 계산을 하는 전역 SQP가 충분히 좋으면 특화 방법을 만들 이유가 없다. finite-difference 민감도 구축 비용·다중 forward·캐시 구축을 모두 비용에 포함한다.

## 4. 국소 선형 실행 가능성과 전역 불가능의 구분

[D] bound가 활성화되지 않은 선형화에서 N을 \(\ker J_P\)의 basis라 하면, 목표 변화 d가 \(\mathrm{range}(J_E N)\) 안에 있는지가 보호를 유지하는 작은 수정의 조건이다. nullspace나 이 조건 자체는 표준 선형대수다. d가 range 밖이라고 비선형 유한 편집까지 불가능한 것은 아니다. threshold를 건너는 해결책을 현재 Jacobian이 못 볼 수도 있다.

별도의 **정확히 불가능한 단위 과제**는 물질 수지로 만들 수 있다. 닫힌 graph, 물질 외부 입출력·Decay 없음, Ice↔Waterfilm/Waterfilm→AbsorbedWetness만 있는 경우 \(M=I+W+A\)는 보존된다(Heat는 이 합에 넣지 않는다). I 총량과 W 총량도 같게 유지하면서 A 총량만 줄이기는 불가능하다. 이는 통상적인 보존식의 적용이며 새 정리가 아니다. 비현실적인 과제를 optimizer의 실패로 오인하지 않는 sanity case로 사용한다. 외부 sink/입력 또는 다른 반응이 있으면 이 인증을 그대로 쓸 수 없다.

## 5. 가까운 연구와 실질적 차이의 후보

- [P] Pan 2013: 국소 keyframe을 volume-preserving 기하 변형으로 편집하고 주변 시간·후속 시뮬레이션으로 전달 [R4]. 국소성·시공간 전파 자체는 기존이다.
- [P] Barbič 2012: 기존 세부 운동을 보존하는 reduced spacetime edit와 contact constraints. 관련 절은 모든 force를 허용하는 fully actuated 문제와 제한된 조작 문제의 차이도 설명 [R5]. ‘일부 결과를 보존하며 편집’도 기존이다.
- [P] Kong 등: bulk/subgrid 계층으로 differentiable fluid control의 메모리를 줄임 [R6]. ‘부분 영역에서 역설계한다’만으로 새 기여가 아니다.
- [P, 초록] Ishitobi 등 2026: 시공간적으로 제한된 weathering offset을 pseudo-time reversal로 제어 [R7]. 되돌리기·국소 풍화 수정의 최초성 주장은 불가.

[H] 남는 차이는 **소수의 허용 입력 아래, 반응으로 서로 소비/생성되고 공유 형상을 바꾸는 여러 채널의 지정 동작을 함께 보호하는 문제**다. 위 논문이 이를 원리상 못 한다고 주장하지 않는다. 강한 일반 최적화와 그 모델을 합리적으로 확장한 대조가 필요하다.

## 6. 최소 비교 과제와 Ablation

| 과제 | 조작/보호 | 목적 |
|---|---|---|
| Q2-A 작은 feasible sanity case | 분리된 영역에서 목표만 변경. 알려진 허용 입력 witness를 보관 | 제한·gradient·보호 구현이 맞는지 확인. 주 기여 사례로 사용하지 않음 |
| Q2-B 연결된 열–물–흔적 편집 | 한 ROI의 흔적을 줄이고 다른 ROI의 Ice/Heat 진행을 보호 | 실제 coupling에서 trade-off·보상 범위 확인. 처음부터 feasible이라고 가정하지 않음 |
| Q2-C Geometry 매개 편집 | Reaction 직접 경로와 Geometry 경로가 모두 있는 사례 | Geometry를 무시한 민감도가 부족한지 확인. 기존 2.95%로 중요성을 대신하지 않음 |
| Q2-D 명시적 불가능 과제 | 위 닫힌 수지 조건 | 불가능한 요구를 실패/오류와 구분 |

주 비교: **같은 허용 조작을 쓰는 전역 bounded SQP/finite difference 또는 full AD**, 동일 budget의 derivative-free 최적화. 보조 비교: edit-only, fixed spatial support, Geometry gradient 경로 제거(실제 forward는 full coupling), 보호를 단순 penalty로 처리. 직접 State painting은 외관만의 상한/미래 반응 비교군으로 별도 표시한다. 원래 허용 조작을 위반하는 painting을 불공정한 주 Baseline으로 삼지 않는다.

지표는 edit error–protection error Pareto 곡선, 동시 충족률, 미사용 probe 오차, 조작 support/크기, full rollout 호출·총 시간·메모리, 실패·재시도다. 목표/보호 tolerance는 반복 수치 오차와 독립적인 품질 요구를 바탕으로 실행 전에 정한다. UI가 같지 않은 인간 생산성 비교는 아직 열지 않는다.

**중단 기준:** 작은 표준 SQP가 모든 중요 과제를 충분히 처리 / Geometry 경로의 중요성이 관측되지 않음 / 보호가 사실상 모든 편집을 막음 / 동일 품질에서 사전 계산 포함 이득 없음. ‘다중 State라 복잡하다’는 이유만으로 계속하지 않는다.

후속 [[90_Research-Archive/Research-Notes-2026-10/30_Deep-Analysis/11_Contribution-Proof-Obligations#6. 방향 2: 최적화 실패 전에 불가능을 판정할 수 있는 범위|심화 추론 §6]]은 닫힌 I+W+A 수지에서 보호 오차의 하한, 선언 stoichiometry/graph로 만든 도달 가능성 superset의 제한적 infeasibility 판정을 추가했다. 기존 Petri-net/수지 기반 방법의 적용이며, 같은 사전 검사를 제공한 표준 optimizer와 비교해야 한다. 외부 물 입력을 허용하는 U-input에 닫힌 보존 예를 그대로 적용하지 않는다.

