# 실제 Contact 입력 공간 감사와 예산 중립 편집의 최소 구성

작성: **2026-10-28 / Asia/Seoul**. [[90_Research-Archive/Research-Notes-2026-10/10_Authoring/22_Protected-Editability-and-Geometry-Mediation|22]]의 ‘실제 조작 가능 범위’ 질문을 코드와 현 자산에서 감사했다.

**코드·자산의 정적 읽기와 대수 분석만 수행했다. 앱·GPU·빌드·수치 실험·학습 및 제품 코드 변경은 없다.** 아래의 48개 사건은 파일에 선언된 입력 좌표이며, 서로 독립적인 최종 결과를 만든다고 검증한 것은 아니다.

## 1. 현재 입력의 실제 계약

| 항목 | 확인한 코드·자산 | 연구에 주는 의미 |
|---|---|---|
| 사건 형식 | `Source/SurfaceState/State/SurfaceInput.h::TSurfaceContactInput` | instance·State·world 위치·반경·양·falloff·Add/Remove·shape 등을 가진 discrete event. 음의 Strength 자체는 허용하지 않음 |
| Scene 초기 입력 | `Source/Scene/SceneLoader.cpp::Load`, `Source/SurfaceState/SurfaceStateSystem.cpp::QueueInitialContacts` | `initialContacts`는 양의 strength와 world stamp를 읽으며 `Operation` 필드를 설정하지 않아 기본 Add. Scene 재시작 때 다시 queue |
| 시간별 입력 | `Source/Scene/DemoAnimation.cpp::LoadDemoAnimation`, `Source/Scene/Scene.cpp::AdvanceDemoAnimation` | `.DemoAnim`의 sorted `contactEvents`가 시간·위치·양과 Add/Remove를 선언. 지정 시간이 진행 구간을 통과한 frame에 한 번 발화. Event 시간 자체를 연속 입력으로 해석하지 않음 |
| 접촉의 실제 raster | `Source/SurfaceState/Contact/SurfaceContactApplication.cpp::ApplyPendingContacts` | 기본 `Texel.Position`의 world 변환을 사용하며 현재 DynamicGeometry를 읽지 않음. 같은 transform/Profile/stamp 조건에서 State가 바뀌어도 요청 입력의 공간 계수는 같음 |
| Step에서의 의미 | `Shaders/Simulation/Solver/SurfaceSolverPass2.comp::main` | 같은 Step의 signed `InputDelta`를 합산해 `max(Current+EventInput+Incoming−Outgoing−Decay,0)`에 적용. `positiveInput` 장부는 `max(EventInput,0)`이며 Step 뒤 delta를 비움 |

`SurfaceContactApplication.cpp`에서 `Strength≥0`을 검사하고 `Remove`면 부호를 음수로 바꾼 뒤 접촉별 값을 합산한다. 같은 Step·texel·State에 Add와 Remove를 보내면 먼저 **signed net delta**로 합쳐진다. Remove는 현재 보유 State를 깎는 새 사건이다. 이미 발생한 융해·형상·수송을 시간 역행해 지우는 조작이 아니다.

## 2. IceReactionLab에 이미 존재하는 유한 시간 입력 basis

현재 [IceReactionLab.DemoAnim](../../../../../Assets/Animations/IceReactionLab.DemoAnim)을 정적으로 읽었다. `b_heated`의 Heat Add는 `t=0.25,0.50,…,12.00`의 **서로 다른 48개 시점**에 하나씩 있고, 모두 `strength=0.2`다. 48개의 target·State·operation·shape·localPosition·radius·secondaryRadius·depth·falloff·rotationDegrees가 같다. Animation track은 camera position 하나이고 이 instance의 transform track은 없다. 원래 Scene의 `b_heated` 초기 Heat contact는 별도의 strength 2.0이며 여기서는 고정한다.

`c_cooled`의 Heat Add 48개와 Waterfilm Add 47개는 **다른 instance**의 사건이다. `b_heated` 한 instance의 보호 편집 자유도로 합쳐서 96개라고 세지 않는다. `a_finite`에는 이 DemoAnim의 Heat 시간 사건이 없다.

이 입력은 파일에 strength/time/shape/위치를 다시 지정해 로드할 수 있는 **offline scripted authoring 좌표**다. 현재 최적화기가 자동으로 이 사건을 조정하거나 기존 사건을 GUI timeline에서 직접 수정하는 기능을 확인한 것은 아니다. 반복 평가에는 파일 설정·재로드·State 재시작이 필요할 수 있으며, 이를 사용자 생산성 증거로 여기지 않는다.

## 3. 실제 자산으로 표현 가능한 정확한 입력 예산 중립 방향

기존 48개 Heat Add strength를 `a_j=0.2`라 한다. 두 시점 `j≠k`를 골라

$$
a'_j=0.2+\epsilon,\qquad a'_k=0.2-\epsilon,\qquad 0<\epsilon\le0.2
$$

로 변경하고 나머지는 유지할 수 있다. 파일 parser의 비음수 Strength 조건을 만족한다. **현재 사건을 추가하는 것이 아니라 기존 두 사건의 양을 재배치**하는 작업이다. 새 둘의 Operation은 여전히 Add이므로 Remove의 다른 반응 의미가 끼지 않는다.

같은 instance transform·Profile/InputFactor·stamp를 고정하면 `ApplyPendingContacts`의 한 texel `x`에 대한 요청량은 `D_{x,j}=a_j K_x`다. 여기서 `K_x`는 그 texel의 footprint/falloff/InputFactor·면적 계수다. 48개가 같은 stamp이므로

$$
\sum_j D'_{x,j}-\sum_j D_{x,j}=K_x(\epsilon-\epsilon)=0
$$

가 **각 texel마다** 성립한다. 즉 이 입력 family는 전체 strength 합 9.6뿐 아니라 각 texel의 **시간 합산 요청 InputDelta**를 보존한다. 고정된 동일 stamp의 strength만 조정하면 48차원 계수 공간에 `Σδa_j=0`인 **47차원 명목상 예산 중립 방향 공간**이 있다. 양의 strength margin 0.2는 충분히 작은 양·음의 계수 편집을 허용한다.

이는 실수 대수와 고정 stamp 조건의 결과다. 부동소수점 업로드·합산의 bitwise 동일성을 보장하지 않는다. 또 **시간별** 입력, retention, 반응, 냉각, Decay, Geometry, 최종 State가 같다는 결과는 전혀 아니다. 21의 동일 최종 State witness가 이 48차원 basis 안에 놓이는지도 확인하지 않았다. 따라서 22의 실제 입력 gap 중 ‘예산 중립의 유한 입력 방향이 존재하는가’만 닫혔다.

### 첫 변경 사건에서 보장되는 좁은 차이

`j`가 `k`보다 이른 사건이면, `j` 직전까지 두 실행의 입력·State·Geometry는 동일한 결정론적 경로다. `SurfaceSolverPass1.comp::main`은 현재 State에서 Decay를 빼고 남은 양으로 outgoing을 제한한다. 따라서 Pass 2의 입력 전 기본량 `Current+Incoming−Outgoing−Decay`는 정상적인 비음수·유한 경로에서 0 이상이다. 같은 spatial stamp의 첫 Add를 `+ε`로 바꾸면, 해당 stamp가 실제로 닿는 texel에서 **첫 변경 Step의 반응 직전 Heat snapshot**은 실수 대수상 `εK_x` 증가한다. 뒤의 `k` 사건은 이 시점에 영향을 줄 수 없다. 부동소수점의 bitwise 차이·반응 후 State 증가·Ice/Geometry 변화는 별도 문제다.

이 사실은 제안된 입력 차이가 Solver에 도달하는지에 관한 **최소 causal sanity**다. 최종 보호 편집의 feasibility를 증명하지 않는다. `k` 이전의 측정 창을 잡으면 초기 변화와 나중 보상 사건의 효과를 분리할 수 있다.

## 4. 공간 자유도와 시간 자유도를 혼동하지 않는다

이 48개 사건은 같은 spatial stamp `K_x`와 서로 다른 시점을 가진다. 입력의 공간 shape는 하나이고, time-amplitude 좌표만 48개다. 장면 내 목표·보호 영역의 spatial 분리에는 Heat 수송·반응·동적 형상의 **시간별 응답 차이**가 필요하다. 48개 strength가 최종 관측에 48개의 독립적인 방향을 제공한다는 결론은 불가능하다.

매끄러운 한 branch에서 전체 State의 Step 선형화를 `A_n`, 사건의 입력 방향을 `B_jK`, 최종 관측을 `Cq_T`로 쓰면 각 strength의 1차 최종 응답 열은

$$
J_j=C A_{T-1}A_{T-2}\cdots A_{j+1}B_jK.
$$

같은 `K`여도 서로 다른 시점의 전파 연산자 때문에 `J_j`들이 달라질 수 있다. 그러나 모두 거의 평행하면 사건 48개가 있어도 유효 편집 방향은 작다. `A_n`에는 기준 경로의 반응·수송·형상 매개 효과가 들어가야 한다. 이 식은 표준 선형화/도달성 표현이지 새 알고리즘이나 현재 계산된 Jacobian이 아니다. 유효 rank만이 아니라 입력 범위·허용오차·조건수도 평가해야 한다.

**접촉 좌표의 제한:** 현 raster는 `DynamicGeometry`가 아닌 정적 texel 위치를 사용한다. 따라서 State가 만든 돌출부를 따라 stamp support가 움직이는 입력 모델을 현재 구현의 기능으로 주장할 수 없다. 같은 위치의 script 입력을 비교할 때 `K`가 고정된다는 이점이 있지만, 제작자가 현재 보이는 형상에 직접 접촉한다고 해석하면 다른 입력 의미다. 동적 표면에서의 접촉 불일치가 시각적·수치적 문제를 만들었는지는 실행으로 확인하지 않았다. 그 자체를 독창적인 기여 후보로 승격하지 않는다.

22의 `J_P` rank/허용 cone 조건을 이 구체적인 계수 벡터에 적용할 수 있다. 예를 들어 같은 총 요청 InputDelta 조건 한 개를 포함하면, 보호 제약 추가 전의 내부 방향은 47개다. 이후 최종 Ice·Heat·Water 분포 등 보호 지표를 더하면 실질 자유도는 Jacobian의 rank 및 사건이 닿는 branch에 따라 줄어든다. 다수 텍셀의 동일 분포 보호는 47개를 모두 고정할 수도 있다. 현 Jacobian·rank는 계산하지 않았다.

기존 실험의 `D–E` 분포 차이와 이 입력 basis의 보호 편집 가능성은 서로 다른 증거다. 전자는 forward coupling 기전이고, 후자는 입력→목표/보호 응답의 역문제다.

특히 **두 사건의 `±ε` 대조는 입력 경로 sanity**로만 쓴다. 21의 닫힌 국소 모델에서조차 총 입력·최종 Ice·최종 Heat가 세 독립 제약인 regular branch라면, strength 두 개만 조절해서 비자명한 정확 보호 편집을 기대할 수 없다. 같은 세 제약 아래 국소 자유도를 남기려면 일반적으로 네 개 이상의 독립 strength가 필요하다. 공간 수송이 있으면 최종 Water 분포 등 독립 제약이 더 생길 수 있어 이 숫자를 production 보장으로 옮기지 않는다. 48개 입력의 실제 효용은 보호 Jacobian의 rank와 허용 범위에 달려 있다.

## 5. 앞으로의 연구 판정에 바로 쓸 축소 과제

1. **Sanity 과제:** 같은 stamp의 두 Heat strength를 `±ε`로 조정해 저장된 사건 형식과 명목상 texel별 입력 예산을 유지한다. 48개 전체를 조정하기 전 입력 경로의 정확성을 판정할 수 있다. 실행은 현재 중지 상태다.
2. **핵심 가능성 질문:** 48개 strength 중 제한된 일부를 조정해 정해진 중간 Ice/Water/Geometry 목표를 바꾸면서 지정한 최종 또는 이웃 영역 관측을 보호할 수 있는가? 성공을 미리 가정하지 않는다.
3. **기전 질문:** 기준 Geometry 시퀀스 재생 대조와 full coupling에서 같은 contact basis·목표·보호를 사용한다. 형상 경로가 보호 편집의 달성 범위를 넓히는지, 좁히는지 판정한다.
4. **기여 판단:** analytic seed를 포함한 표준 bounded 최적화와 같은 파일 조작·같은 rollout budget을 준다. 새 방법이 필요하지 않으면 알고리즘 기여 주장을 낮춘다.

**현재 결론:** 현 코드/자산에는 실제로 표현 가능한 예산 중립의 시간 입력 family가 있다. 이는 21의 연속 입력 해를 production에서 재현한 것이 아니고 보호 편집의 성공 증거도 아니다. 지금 가장 날카로운 미해결 질문은 **이 제한된 temporal basis가 State-Driven Geometry Coupling 아래에서 실제 보호 편집 방향을 남기는가**다.
