# 방향 1 — 목표 진행과 후속 반응을 만족하는 역설계

마지막 갱신: 2026-10-27. [[03_Development/07_Research-Directions-123|최초 통합 검토]]에서 분리한 후속 연구 정본이다. 이 파일의 내용은 제안·수식 분석이며 새 구현/실험 결과가 아니다. 로컬 앱·GPU·빌드 실행 중지를 유지한다.

공통 근거는 [[90_Research-Archive/Research-Notes-2026-10/20_Solver-Semantics/10_Forward-Model-and-Controls|forward 모델]], 문헌 출처는 [[90_Research-Archive/Research-Notes-2026-10/90_Reference/07_Related-Work|문헌 확인 수준]], 이후 연구는 [[90_Research-Archive/Research-Notes-2026-10/90_Reference/09_Analytical-Findings|분석 노트]]를 따른다.


## 1. 문제를 더 좁히기

사진 한 장에서 실제 물리 파라미터를 복원하는 문제로 시작하지 않는다. 현재 모델의 초기 상태/재질을 알고, 제작자가 원하는 시점별 지표와 후속 반응을 지정하는 **설계 문제**로 둔다. 유일한 진실의 State를 복원한다고 주장하지 않는다.

예: 3초의 잔존 Ice, 8초의 Waterfilm 도달 영역, 14초의 잔류 흔적을 맞추고, 이후 고정된 Heat pulse에 대한 반응 곡선도 지정한다. 시점/수치는 설명 예시이며 기존 AUTH-GOAL gate를 변경하는 실행 명세가 아니다.

허용 조작 a를 정하고 원래 forward rollout을 \(\Phi(a)\), 관측을 H, 후속 시험 입력 p에 대한 반응을 \(\Psi_p(a)\)라 하면 다음과 같다.

\[
\min_{a\in\mathcal U}\; L_{\mathrm{progress}}(H\Phi(a),y^*)
  +\sum_{p\in\mathcal P_{\rm train}} w_p L_{\mathrm{response}}(\Psi_p(a),r_p^*)
  +\lambda\Omega(a).
\]

이 목적함수와 regularization 자체는 표준적인 최적제어 형식이다. 새 기여로 세지 않는다. 실제 후보는 **관측에 비슷하게 맞는 여러 해 사이의 후속 거동 차이를, 제한된 제작 조작 아래 효율적으로 줄이는 방법**이어야 한다.

## 2. 먼저 고정할 조작 범위

1. **U-input:** 재질/반응 inventory·초기 State를 고정하고, 정한 source 영역과 시간 basis의 비음수 Heat/Waterfilm 입력만 조절. source별 총량·세기·시간·공간 support에 bounds를 둔다. 잔류 State 직접 칠하기는 허용하지 않는다.
2. **U-profile:** 별도 과제로 제한된 2–6개 Profile 계수까지 허용. 반응 삭제·계수 0으로 무력화·장면별 새 Rule 삽입으로 목표를 우회하지 않도록 범위를 미리 정한다.

두 범위의 결과를 섞지 않는다. 모든 texel·채널에 자유로운 양/음의 source를 주는 방법은 별도 강한 상한 대조가 될 수 있지만 U-input 과제의 공정한 주 비교군으로 두지 않는다.

## 3. 핵심 가설과 이미 알려진 부분

[H] 비슷한 외관/진행 목표를 만족하는 두 허용 rollout이 후속 입력에서 서로 다른 결과를 낼 수 있고, 이 차이가 제작상 중요할 수 있다. **현재 U-input의 실제 rollout 쌍을 확보한 것은 아니다.**

[C,D] 후속 분석에서는 Ice=4a/8a가 같은 표시 포화도·capped 형상을 만들지만 후속 융해 request는 다른 조건부 State 쌍을 유도했다. 이는 저장량→관측의 비단사성이다. 초기 Ice 고정인 U-input의 두 해로 간주하지 않는다. 초기 Ice seed strength를 허용하는 별도 U-seed 진단과 실제 외관 확인은 미실행이다. 식·가정·조작 범위의 제한은 [[90_Research-Archive/Research-Notes-2026-10/90_Reference/09_Analytical-Findings#3. 방향 1: 같은 포화 외관·형상, 다른 후속 반응|후속 분석 §3]]을 따른다.

[D] 선형화한 관측 Jacobian \(J_y\)에 대해 \(J_y\delta a\simeq0\)이나 후속 반응의 \(J_\Psi\delta a\)는 큰 방향이 있다면, 관측만의 적합도는 그 방향을 충분히 제어하지 못한다. 이는 표준적인 관측/식별성의 국소 설명이며, 비선형 전체 공간의 비식별성 증명이 아니다.

[P] Bosch 2011은 사진에서 flow parameters/detail maps를 추출해 새 target에 적용한다. Mordvintsev 2021은 RD update의 파라미터를 texture loss로 학습하고 mesh/해상도 전이도 보여준다. 따라서 ‘풍화 파라미터 자동 탐색’, ‘RD를 미분해 학습’, ‘다른 mesh에 적용’은 빈 영역이 아니다. 관련 출처 [R1–R3].

## 4. 최소 진단과 Baseline

| 진단 | 수행할 내용 | 필요한 해석 |
|---|---|---|
| Q1-A 관측 모호성 | 같은 허용 조작 범위에서 관측 오차가 ε 이내인 여러 해를 찾고 고정 후속 pulse 결과를 비교 | 차이가 관측/수치 반복 오차보다 작으면 이 문제 설정의 필요성 약함 |
| Q1-B 추가 제약의 효과 | 관측-only, 관측+시점별 State 지표, 관측+후속 반응을 같은 optimizer로 비교 | loss 추가의 유용성과 새 알고리즘의 우위를 구분 |
| Q1-C 일반화 | fit에 쓴 pulse와 크기/위치/시간이 다른 미사용 pulse에서 평가 | train pulse에 맞춘 해를 모든 미래의 보장으로 확대하지 않음 |

기본 대조는 bounded CMA-ES 또는 다른 derivative-free 방법과 finite-difference+SQP/trust-region이다. 미분 가능한 경로를 만들 경우 full-coupling AD/adjoint를 강한 기준으로 포함한다. 평가는 같은 target/허용 조작/초기화 seed/rollout budget에서 한다. derivative-free 평가 호출 비용을 누락하지 않는다. optimizer를 임의로 약하게 설정해 새 방법을 유리하게 만들지 않는다.

## 5. 추가 연구가 필요한 경우의 해법 후보

[H] 관측과 후속 반응 민감도를 분리한 control basis, 반응 threshold 근처의 단계적 최적화, surrogate 제안 후 실제 forward 검증을 결합할 수 있다. 각각 기존 개념이며 **MDSSP 결합 구조에서 standard baseline이 실패하는 이유와 해결 효과**가 있어야 새 방법이 된다.

지금 바로 전체 renderer/solver를 미분 가능한 새 엔진으로 재작성하지 않는다. 첫 진단은 적은 수의 입력 basis와 state-space 목표로 가능하다. 실제 구현/실행은 별도 재개 지시 전 하지 않는다.

**지표:** 진행 오차, 미사용 pulse 응답의 평균/최악 오차, 목표 동시 충족률, 입력 총량/공간·시간 복잡도, 실패율, forward 호출 수. 완성된 rendered 과제에서는 고정 camera/lighting의 외관도 확인한다. State 지표만 맞춘 결과를 예술적 품질로 대체하지 않는다.

**중단 기준:** 모호성이 중요하지 않음 / 단순 다중 목적 최적화가 충분함 / 추가 이점이 큰 모델 변경이나 목표 편향에 의존함. 이 경우 독립 논문 Contribution 주장은 중단하고 2의 평가 과제로만 사용한다.

후속 [[90_Research-Archive/Research-Notes-2026-10/30_Deep-Analysis/11_Contribution-Proof-Obligations#7. 방향 1: 후속 probe가 줄 수 있는 것과 줄 수 없는 것|심화 추론 §7]]에서 복제한 한 texel의 두 초기 probe로 i,h를 구별하는 조건과, 유한 probe의 보장 한계를 유도했다. 내부 State는 이미 알려져 있으므로 이를 미지의 물리 State 복원으로 포장하지 않는다. 참조 State 거리 제약도 강한 Baseline에 포함한다.

