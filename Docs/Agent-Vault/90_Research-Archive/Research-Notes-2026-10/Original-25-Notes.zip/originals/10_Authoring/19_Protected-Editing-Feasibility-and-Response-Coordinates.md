# 보호 편집의 가능 범위와 반응 진행 좌표

작성: **2026-10-28 / Asia/Seoul**. [[90_Research-Archive/Research-Notes-2026-10/18_Research-Landscape-and-Selection|18]]의 A를 심화한다. 제목의 보호는 지정 관측의 허용오차를 뜻하며 전체 시뮬레이션 불변을 뜻하지 않는다.

**문헌·코드·기호 유도만 수행했다. 새 구현·실험·실행 가능 입력 witness는 없다.** 제품 코드는 변경하지 않았다. 기존 수식에 대한 새 알고리즘의 우위도 입증하지 않았다.

## 1. 이번 분석의 결론

보호 편집의 첫 문제는 optimizer 선택보다 **어떤 보호 요구가 편집 자유도를 남기는가**다. 현재 IceReactionLab에서는 다음 구분이 중요하다.

1. 같은 위치의 Heat 전 과정을 고정하면, 제한된 조건에서 Ice 전 과정도 결정된다. 이때 Ice를 바꾸라는 요구를 못 푸는 것은 optimizer 결함이 아니다.
2. Ice의 최종량만 보호한다면, Heat 전 과정보다 훨씬 약한 ‘누적 유효 반응량’을 보호하면 된다. 중간 융해 시점과 Geometry 경로를 바꿀 자유도가 남을 수 있다.
3. 이 자유도가 실제 Heat contact 입력으로 도달 가능한지, 그리고 다른 보호 관측과 동시에 만족되는지는 별도 문제다. 자유도가 남는다는 말만으로 feasible task라고 판정하지 않는다.

따라서 더 구체적인 연구 질문은 다음이다.

> 제작자가 보호하려는 결과를 반응 진행·경계 응답 등의 필요한 조건으로 표현해, 불필요한 고정을 피하면서 결합된 현상을 수정할 수 있는가?

‘보호 loss를 추가한다’보다 과제는 명확해졌다. 그러나 반응 진행 좌표·제약 최적화·nullspace 자체는 기존 도구다.

## 2. 코드에서 쓰는 제한 모델

[IceReactionLab.SRProfile](../../../../../Assets/SurfaceProfiles/IceReactionLab.SRProfile)의 Ice는 수송·Decay가 0이며, `ice_melting`에서만 소비된다. 초기 입력 이후 Ice 추가/제거가 없다고 한정한다. 면적당 Ice·Heat를 i,H라 하고 `k=0.5`, `τ=0.25`다.

[reactionRequest](../../../../../Shaders/Simulation/Solver/SurfaceReaction.comp)의 continuous request는 이 Profile에서 `k i (H−τ)+`에 해당한다. 같은 파일의 `main`은 반응들을 동일 snapshot에서 평가하고 공급량 비율과 적응 substep을 적용한다. 다음 연속식은 **공급 제한과 시간 이산 오차를 제거한 이상 모델**이다.

$$
\dot i=-k\,i\,(H-\tau)_+.
$$

다른 위치의 수송·Geometry가 H를 바꿀 수 있지만, 주어진 H에 대한 이 국소 반응식은 그대로다. 새로운 Ice 반응, 추가 입력, 이동하는 Ice를 허용하면 아래 식을 그대로 사용할 수 없다.

## 3. 보호 요구가 편집을 막는 조건

### 3.1 Heat 전 과정 보호 → Ice 진행 고정

i(0)>0이면

$$
Z(t)=k\int_0^t(H(s)-\tau)_+\,ds,
\qquad i(t)=i(0)e^{-Z(t)}.
$$

같은 초기 Ice와 같은 H(t)를 유지하면 i(t)도 같다. 따라서 **동일 texel의 전체 Heat 진행과 초기 Ice를 고정하면서 융해 진행만 바꾸기**는 이 제한 모델에서 불가능하다. 전체 공간에서 Heat를 보호하지 않더라도 편집하려는 texel에서 같은 조건이면 해당 결론이 성립한다.

이는 초기 총량 보존식보다 더 구체적인 ‘동작 종속성’이다. 표준 선형 1차 ODE 해의 적용이며 새 정리가 아니다. 실제 GPU에서는 공급 비율·substep이 달라질 수 있으므로 ‘Heat가 같으면 항상 Ice가 bitwise 동일’이라는 주장으로 확대하지 않는다.

### 3.2 거의 같은 Heat가 허용하는 Ice 변화

positive-part는 1-Lipschitz이므로 같은 초기량을 가진 두 연속 실행에 대해

$$
\left|\log\frac{\hat i(T)}{i(T)}\right|
\le k\int_0^T|\hat H-H|\,dt.
$$

예를 들어 Heat 보호가 `sup_t |δH|≤ε_H`라면 Ice 비율은 `exp(−kTε_H)`와 `exp(kTε_H)` 사이에 있어야 한다. 목표 Ice 비율이 이 범위를 벗어나면 이 모델의 해당 보호 요구와 양립하지 않는다.

시간 평균 Heat 또는 최종 Heat만 보호하는 경우에는 이 상한을 그대로 적용할 수 없다. threshold 아래/위의 노출 분포가 다를 수 있기 때문이다. Heat의 공간 총량만 같은 경우에도 texel별 융해는 달라질 수 있다.

## 4. 실제 이산 반응식에 맞춘 좌표

### 4.1 공급 경쟁·적응 substep을 포함한 항등식

각 실제 반응 substep에서 melting rule의 공급 비율을 λ_j, 길이를 δ_j라 두면, 수학적 실수 연산에서

$$
a_j=\delta_j\lambda_j k(H_j-\tau)_+,
\qquad i_{j+1}=i_j(1-a_j).
$$

Ice가 이 rule에서만 소비되고 다른 연산으로 변하지 않는 조건에서 0≤a_j≤1이다. 모든 a_j<1이면

$$
Z_{\rm discrete}=-\sum_j\log(1-a_j),
\qquad i_N=i_0e^{-Z_{\rm discrete}}.
$$

이 식은 반응별 공급 비율과 실제 substep을 포함하므로 연속식보다 production 계약에 가깝다. 두 실행의 substep 개수가 같을 필요도 없다. a_j=1이면 완전 소진으로 별도 처리하며 Z는 무한대다. 부동소수점 clamp/오차나 arithmetic-failure fallback까지 정확히 표현한다고 주장하지 않는다.

**현재 코드가 이 Z를 별도로 계산·저장한다는 뜻은 아니다.** 상태와 반응 장부에서 유도되는 분석 좌표다. 최종 Ice가 이미 알려져 있으면 Z는 그 값을 다시 쓴 것이므로 정보 압축이나 속도 향상이 자동으로 생기지 않는다.

### 4.2 단순 누적률을 쓸 때의 차이

0≤a_j≤a_max<1일 때

$$
0\le Z_{\rm discrete}-\sum_j a_j
\le\frac{\sum_j a_j^2}{2(1-a_{\max})}.
$$

이는 `−log(1−a)`의 급수에서 얻는 표준 상한이다. 연속 exposure를 이산 보호 조건의 대용으로 쓸 때, 반응 분할 오차를 무시하면 안 된다는 점을 보여준다. 코드가 일반 continuous substep을 10% depletion 이하로 제한하려 하지만 마지막 budget 소진 fallback 등에서는 이를 무조건 가정할 수 없다.

## 5. 무엇을 보호하고 무엇을 풀어줄 것인가

| 제작자가 지정한 보호 | 이 제한 모델에서 필요한 조건 | 남을 수 있는 자유도 / 한계 |
|---|---|---|
| 모든 시점의 Ice | 모든 prefix의 Z 유지 | Ice 변화로 생기는 Geometry 경로 수정은 사실상 막힘 |
| 최종 Ice만 | 최종 Z 유지 | 융해 시점 재배치 가능성. 중간 Geometry·Water는 바뀔 수 있음 |
| 최종 Heat만 | H(T) 유지 | 융해량도 지켜진다고 말할 수 없음 |
| 최종 Ice와 Heat | Z(T), H(T) 유지 | 조작 수·민감도에 따라 유용한 자유도 존재 여부 달라짐 |
| 최종 Height만 | capped State 조합 유지 | 숨은 저장량과 미래 반응은 보호되지 않음 |
| 후속 입력에 대한 Water 경로 | 해당 rollout 관측/경계 응답 유지 | 위 국소 Z 하나로 대체 불가. 전체 결합 평가 필요 |

**유망한 초기 과제:** 지정 영역의 최종 Ice·Heat를 유지하면서 중간 물의 배출 시점 또는 다른 영역의 잔류 분포를 바꾼다. 이때 중간 Geometry 변화는 허용한다. 제작 목적이 모든 순간의 형상 보존이라면 이 과제로 바꾸면 안 된다.

단지 같은 exposure를 갖는 두 Heat 곡선을 그리는 것은 실제 허용 입력 witness가 아니다. Heat를 임의로 내리는 조작, 직접 State 덮어쓰기, 음의 입력을 몰래 허용하지 않는다. production contact의 입력 범위를 통과한 witness는 여전히 미확인이다.

## 6. 실제 입력에서 자유도를 판별하는 표준 검사

입력 basis 계수를 u∈R^m, 보호 관측을 P(u)∈R^r, 수정 관측을 E(u)라 하자. branch가 고정되어 P,E가 매끄럽고 u가 허용 집합 내부이며 DP의 rank가 r이면, 음함수 정리에 의해 국소 보호 집합의 차원은 m−r이다.

그 안에서 수정 가능한 1차 방향이 있으려면

$$
\exists v:\quad DP(u)v=0,\qquad DE(u)v\ne0
$$

가 필요하다. orthonormal nullspace basis N을 쓰면 `DE·N`을 확인하는 검사다. 방향이 있어도 크기·입력 비용·event까지의 거리 때문에 실제 편집 폭이 작을 수 있다. bound 위 입력에서는 nullspace와 허용 tangent cone의 교집합을 써야 한다.

`DE·N=0`은 국소 1차 판정일 뿐 전역 불가능 증명이 아니다. cap/threshold 너머나 2차 방향에 해가 있을 수 있다. rank가 수치적으로 작다는 판단도 Jacobian 오차·tolerance와 함께 정해야 한다. 이번에는 Jacobian을 계산하거나 이 검사를 실행하지 않았다.

이 절차는 일반 SQP·nullspace method가 이미 이용하는 구조다. 새 방법에도 대조군에도 동일하게 허용해야 한다.

## 7. 실제 알고리즘 후보와 기존 방법의 경계

제안은 다음처럼 제한한다. 모두 **미구현**이다.

1. Profile의 특정 rule에서 유도 가능한 반응 진행 조건을 찾아 보호 요구의 종속성·불가능 조건을 검사한다. 일반 반응망의 자동 해석을 달성했다고 주장하지 않는다.
2. 실제 입력의 국소 민감도로 목표를 바꾸는 보호 방향을 찾는다. 내부 bound·branch에서는 표준 constrained optimizer를 쓴다.
3. local gain이 부족하면 목표/보호 영향이 있는 cap·threshold만 유한 변화 후보로 고려한다. 선택한 후보가 전체 forward에서 보호되는지 다시 평가한다.
4. 불가능 증명, 조건부 feasible witness, 탐색 실패를 서로 다른 결과로 돌려준다. 실패를 ‘해 없음’으로 출력하지 않는다.

**남은 연구 공백:** 많은 texel×time event 중 어떤 것만 봐도 중요한 편집을 놓치지 않는지, 반응 진행 조건이 forward 횟수를 실제로 줄이는지, 보호 관측을 과하게 약화하지 않는지다. 아직 이에 대한 새 선택법·보장·비용 이점은 없다.

R53의 hybrid sensitivity와 R54의 사전 event gradient/정확 forward 분리 선례 때문에 ‘0 gradient를 피하기 위한 smoothing’ 자체는 신규 기여가 아니다. 특히 현 `rampAbove`, min/cap은 연속이지만 미분 불가능한 branch가 많다. 이를 모두 연속시간 reset event로 간주해 saltation matrix를 그대로 붙이면 안 된다. 고정 discrete GPU Step과 제안 surrogate의 차이를 명시해야 한다.

## 8. 향후 판별 과제와 강한 대조

| 과제 | 확인할 것 | 실패 시 해석 |
|---|---|---|
| A0: Heat 전 과정 보호 + 다른 Ice 진행 요구 | §3의 불가능 조건을 정확히 구분 | 이를 성공시키면 허용 입력/보호/모델이 달라졌는지 감사 |
| A1: 최종 Ice·Heat 보호 + 중간 진행 수정 | 동일 U-input에서 feasible witness와 국소 자유도 | witness가 없으면 알고리즘 성능 과제로 쓰지 않음 |
| A2: threshold/cap 전환이 필요한 같은 보호 과제 | 표준 multi-start·continuation보다 적은 비용의 개선 여부 | 기존법이 충분하면 특화 알고리즘 중단 |
| A3: 실제 Geometry 경로가 중요한 과제 | Geometry를 생략한 민감도와 full coupling의 차이 | 차이가 수치 floor 수준이면 MDSSP 특수성 주장 약화 |

대조는 **같은 보호 관측·입력 bounds·반응 좌표 정보를 받는 SQP/FD·AD, multi-start/continuation, derivative-free**다. 새 방법에는 Z 보호를 주고 대조에는 과도한 Heat 전 과정 보호를 주는 비교는 불공정하다. 공급 제한/step 변화가 없는 부드러운 과제와 있는 과제를 분리한다.

지표는 목표–보호 Pareto, 실제 forward 호출·총 비용, 허용 입력 witness, 미사용 후속 입력의 분포 오차다. false infeasibility는 별도 집계한다. 예쁜 결과나 한 substep의 대수적 사례만으로 제작 도구의 우수성을 주장하지 않는다.

## 9. 판정

A는 **보호 대상을 반응 진행에 맞게 정하고, 실제 입력의 자유도를 찾아 편집하는 문제**로 더 좁혀졌다. 목적 적합성은 여전히 높다. 반면 ‘모든 Heat를 유지하면서 같은 위치 Ice를 바꾼다’ 같은 과제는 일부 조건에서 기각해야 한다.

이번 유도는 잘못된 과제를 제거하고 비교 기준을 강화했다. 새 optimizer의 필요성이나 SIGGRAPH 수준의 기여를 입증한 것은 아니다. R2/R4/R5의 기존 편집과 R53/R54의 hybrid optimization을 넘어서는 차이를 아직 확보하지 못했다.

## 후속: 필요한 Heat 입력까지 구성

[[90_Research-Archive/Research-Notes-2026-10/10_Authoring/21_Constructive-Controls-and-Reaction-Contracts|21]]은 반응 진행 z에서 필요한 양수 Heat 입력을 복원한다. 입력 여유가 있는 제한 연속 모델에서 동일 endpoint·동일 총 입력과 다른 중간 진행의 국소 해가 존재함을 유도했다. 실제 event/contact 입력과 공간 Geometry 결합의 성공은 아직 확인하지 않았다. Heat decay는 실제 코드에 맞춰 비례 감쇠가 아닌 상수 양 감소로 대응했다.
