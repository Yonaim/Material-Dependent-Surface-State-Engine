# MDSSP 연구 안내

마지막 정리: **2026-11-03 / Asia/Seoul**. 이 문서는 연구 폴더의 **읽는 순서와 현재 판정**이다. 자세한 유도와 이전 판단은 아래 주제 폴더에 보존했다.

## 현재 판정

MDSSP는 다중 Surface State·Reaction·State-Driven Geometry Coupling을 구현한 현상학적 표면 시뮬레이션 시스템이다. 지금 확인된 것은 결합 기전과 구현 범위이며, **SIGGRAPH Technical Paper 수준의 새로운 Contribution은 아직 입증되지 않았다.** 기존 범용 연구 및 합리적인 모듈식 비교군에 대한 우위가 확인되지 않아 현 학술 판정은 **③ 시스템 통합에 가까움**이다. 물리적 부피 Solver로 바꾸는 것을 합격 조건으로 삼지 않는다.

사용자가 제외한 **축적 순서/층 표현 방향4는 다시 추진하지 않는다.** 로컬 앱·GPU·빌드·벤치마크·학습 실행은 명시적 재개 요청 전까지 중지한다. 현재 이 폴더의 후속 작업은 코드·기록·문헌 읽기와 수식/문서 분석이다.

## 꼭 읽을 문서

| 우선순위 | 문서 | 무엇을 얻는가 | 필요한 읽기 범위 |
|---|---|---|---|
| **필독 1** | **이 문서** | 현재 결론·방향·문서 지도 | 전체 |
| **필독 2** | [[90_Research-Archive/Research-Notes-2026-10/02_Evidence-and-Current-Judgment|확보한 증거와 현 판정]] | 실제 구현·실험·미검증을 구분 | §1–5 |
| **필독 3** | [[90_Research-Archive/Research-Notes-2026-10/03_Contribution-Candidates|Contribution 후보 장부]] | 현재 후보와 강한 심사 반론 | 맨 앞 **현재 후보 표**. 자세한 반론은 §1–4, 후속 판단은 §10–14 |

다음 실험/판정 순서가 필요하면 [[90_Research-Archive/Research-Notes-2026-10/08_Research-Agenda|연구 과제]]를 본다. 여러 방향을 다시 비교할 때만 [[90_Research-Archive/Research-Notes-2026-10/18_Research-Landscape-and-Selection|방향 확장 비교]]를 읽는다. 출처를 확인할 때는 [[90_Research-Archive/Research-Notes-2026-10/90_Reference/07_Related-Work|문헌 장부]]에서 해당 주제의 ID와 실제 열람 범위를 확인한다.

## 현재 연구 우선순위

| 순위 | 방향 | 지금까지 얻은 것 | 아직 없는 것 | 다음 판정 질문 |
|---|---|---|---|---|
| **1** | **A — 보호 편집·목표 진행 역설계** | 제한 연속 모델의 조건부 입력 해, 현 자산에서 동일 stamp Heat 사건 48개와 예산 중립의 입력 조정 방향 | 실제 contact로 최종 State/후속 효과를 보호한 사례, 표준 optimizer 대비 필요한 새 방법 | 제한된 접촉 입력으로 원하는 변화와 보호를 함께 달성할 수 있는가? 공유 형상이 그 가능 범위를 바꾸는가? |
| **2** | **B — 반응·수송 규칙의 의미 일관성** | 신규 유입 기반 요청과 전체 보유량 소비의 차이, 순수송/양방향 유입·방향/분할 의존성의 제한 모델 반례 | 표준 배분·kinetics·이산화로 해결되지 않는 실제 문제와 새 해법 | 현 규칙의 의미를 고정했을 때 장면·해상도 변경에도 예측 가능한가? |
| **3** | **E — 미래 반응을 고려한 계산 축소** | 제한 모델의 공동 오차 상한과 계산 생략 충분조건 | 열린 경계·다중 반응·동적 Geometry에서 유용한 저비용 방법 | fine Solver 및 기존 sparse/LOD보다 실질적 품질–비용 이점이 있는가? |
| 보류 | 공통 시스템 자체, Meso 복원 강건성 | 구현·제한 실험은 있음 | 강한 기존법 대비 학술적 차이 | 중요한 새 실패/이점이 확인될 때 재평가 |

위 순위는 **연구 탐색 우선순위**이며 채택 가능성의 확률이 아니다. A/B/E 모두 새 알고리즘·SIGGRAPH 기여로 확정되지 않았다. 기능을 많이 구현했거나 기존 코드가 빨라졌다는 사실을 신규성으로 세지 않는다.

## 폴더별 문서 지도

루트에는 현재 판단을 확인하는 **5개 문서**만 둔다. 기존 연구 문서 24개의 내용을 보존했고, 이전 긴 개요를 별도 보존해 총 25개다. 심화 문서는 목적별로 나눴다. 번호는 작성 순서를 보존하므로 같은 폴더에서 연속하지 않을 수 있다.

| 위치 | 들어 있는 것 | 읽는 경우 |
|---|---|---|
| **루트** | 이 문서, 증거, 후보, 연구 과제, 방향 비교 | 현재 결론·우선순위가 궁금할 때 |
| **`10_Authoring/`** | [[90_Research-Archive/Research-Notes-2026-10/10_Authoring/04_Inverse-Authoring|목표 역설계]], [[90_Research-Archive/Research-Notes-2026-10/10_Authoring/05_Protected-Editing|보호 편집]], 19·21·22·23의 가능성·입력 감사 | **A를 연구할 때**. 05→22→23을 먼저 읽고 필요한 수식은 19·21 참조 |
| **`20_Solver-Semantics/`** | [[90_Research-Archive/Research-Notes-2026-10/20_Solver-Semantics/10_Forward-Model-and-Controls|실제 forward 계약]], [[90_Research-Archive/Research-Notes-2026-10/20_Solver-Semantics/20_Transport-Reaction-Semantics-and-Refinement|수송/반응 의미]] | **B를 연구하거나 구현 의미를 확인할 때** |
| **`30_Deep-Analysis/`** | [[90_Research-Archive/Research-Notes-2026-10/30_Deep-Analysis/06_Coarse-Reactive-Transport|coarse 문제]]와 11–17의 최소 모델·오차·경계·방법 검토 | **E의 수학적 근거와 실패 조건을 검토할 때**. 06→12→16→17 순서 추천 |
| **`90_Reference/`** | [[90_Research-Archive/Research-Notes-2026-10/90_Reference/07_Related-Work|문헌 장부]], 대화 이력, 초기 분석, 이전 긴 개요 보존본 | 원래 주장·출처·판단 변경을 추적할 때 |

## 증거를 읽는 방법

- **[C]** 코드를 직접 확인한 현재 구현, **[E]** 실행된 실험, **[P]** 문헌에서 확인한 범위, **[D]** 조건부 수식 유도, **[H]** 제안 또는 미검증 가설로 구분한다.
- 2026-10-27 이전 완료된 실험의 정본은 [[04_Experiments/02_Performance-Measurements|Performance Measurements]]와 [[04_Experiments/01_Validation-and-Tests|Validation]]이다. 연구 폴더에는 해석과 링크만 둔다.
- 이전 문서의 ‘1순위’는 **그 시점의 판단**이다. 현재 우선순위는 이 문서와 후보 장부의 최신 절을 따른다.
- 제품의 현행 계산 계약은 [[02_Architecture/00_Overview|Architecture]], 진행 중인 일은 [[03_Development/01_Current-Work|Current Work]]를 따른다. 긴 이전 개요는 [[90_Research-Archive/Research-Notes-2026-10/90_Reference/00_Overview-Historical-Notes|보존본]]에 있다.
