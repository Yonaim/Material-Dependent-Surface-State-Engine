# 후속 분석 — 관측 모호성·임계값 편집·coarse 정보 손실

작성: **2026-10-27 / Asia/Seoul**. 제목의 후속 분석은 `05_Research` 정리 후 수행한 코드·문헌·수식 연구를 뜻한다. **새 앱/GPU/빌드/학습/수치 실험은 실행하지 않았다.** 아래 수치는 현 코드 식에 대입한 유리수·산술 결과이며 PERF 실측이 아니다. 코드 버전은 HEAD `880af1ebcffe601f0bac27413cad94055ce92812`와 기존 미커밋 작업 트리다. 이번 작업에서 제품 코드는 바꾸지 않았다.

증거 표시는 [[90_Research-Archive/Research-Notes-2026-10/00_Overview|Research 기록 원칙]]을 따른다. [D] 반례는 문제를 구체화하지만, 관측성·비매끄러운 최적화·moment closure의 일반 성질을 새 Contribution으로 주장하지 않는다.

## 1. 이번 분석으로 달라진 판단

| 방향 | 새로 좁힌 문제 | 확인 수준 | 아직 성립하지 않는 주장 |
|---|---|---|---|
| 1 역설계 | Capacity 이상 Ice의 저장량은 외관/형상에서 숨겨지지만 후속 융해 request에는 남음 | 코드 경로 + 조건부 State 쌍의 대수적 반례 | 같은 초기 상태·U-input의 서로 다른 허용 rollout을 확보했다는 주장, 실제 화면 비트 일치 |
| 2 보호 편집 | Heat 임계값 아래에서는 융해 민감도가 0이어도 유한 입력으로 반응을 켤 수 있음 | local request의 정확한 식 분석 | 작은 Jacobian의 rank 부족으로 전역 불가능을 인증하거나, 새 optimizer가 필요하다는 주장 |
| 3 coarse | 평균뿐 아니라 모든 이차 State 모멘트가 같아도 threshold 반응률이 달라질 수 있음. 형상 clamp도 평균화와 교환되지 않음 | 현재 식에 대응한 두 반례 | 두 모멘트보다 모든 기존 closure가 부족하다는 주장, 새 compact 모델의 정확성·속도 |

**현재 판단:** 문제 존재의 근거는 더 구체화됐다. 해법의 신규성은 여전히 미확보다. 방향 3은 최소 반응 연산부터 분리해 분석하기 좋고, 방향 1은 방향 2의 목표/후속 검증으로 묶는다. 세 방향을 모두 구현하는 계획으로 확대하지 않는다.

## 2. 공통 단위와 코드 근거

유효 texel i의 기준 면적 배율을 \(a_i=A_i/(1/256^2)=65536A_i>0\), 저장 State 총량을 \(q_i\), 면적당 양을 \(s_i=q_i/a_i\), Profile Capacity 계수를 c라 둔다. 저장량의 포화 기준은 \(C_i=ca_i\)다. 여기서 Heat의 면적당 양은 온도라는 물리 단위를 가정하지 않는다.

| 코드 | 이번에 확인한 계산 |
|---|---|
| [IceReactionLab.SRProfile](C:/Users/yonai/Documents/MDSS_Engine/Assets/SurfaceProfiles/IceReactionLab.SRProfile:6) | Ice c=4, spread/gravity/decay=0, accumulationFactor=1, cavityFillFactor=0, thickness=0.035. 융해 k=0.5, Heat ramp threshold=0.25, Heat 소비 계수=0.45 |
| [StateMath.glsl::accumulationHeight](C:/Users/yonai/Documents/MDSS_Engine/Shaders/Simulation/Solver/StateMath.glsl:48) | 형상에 쓰는 State를 `min(State, Capacity)`로 제한. `saturation`의 수송용 비율은 상한 없이 저장량/Capacity |
| [SurfaceReaction.comp::reactionRequest](C:/Users/yonai/Documents/MDSS_Engine/Shaders/Simulation/Solver/SurfaceReaction.comp:18) | stateProportional은 저장량을 읽고 modifier는 State/면적으로 정규화. rampAbove는 `max(0,(X-Threshold)/Scale)` |
| [StateSampling.glsl::StateSaturationForProfile](C:/Users/yonai/Documents/MDSS_Engine/Shaders/Rendering/Surface/StateTexture/StateSampling.glsl:39) | 표시량 `clamp(Amount/Capacity,0,1)` |
| [SurfaceLit.glsl](C:/Users/yonai/Documents/MDSS_Engine/Shaders/Rendering/Surface/Lighting/SurfaceLit.glsl:141) | Ice 색/roughness에 위 포화 sampling 사용 |
| [TexelGeometry.comp::DisplayAccumulationHeight](C:/Users/yonai/Documents/MDSS_Engine/Shaders/Rendering/Overlay/Geometry/TexelGeometry.comp:118) | 표시 형상도 채널별 `min(State,Capacity)` 사용 |
| [OverlayStateSampling.glsl::OverlayStateSaturation](C:/Users/yonai/Documents/MDSS_Engine/Shaders/Rendering/Overlay/Coverage/OverlayStateSampling.glsl:55), [OverlaySurface.glsl](C:/Users/yonai/Documents/MDSS_Engine/Shaders/Rendering/Overlay/Shading/OverlaySurface.glsl:233) | Overlay coverage의 포화 비율 및 IceCoverage 제한. Ice shader는 별도 `Ice.glsl`이 아니라 이 경로에 있음 |
| [SurfaceContactApplication.cpp](C:/Users/yonai/Documents/MDSS_Engine/Source/SurfaceState/Contact/SurfaceContactApplication.cpp:356) | Falloff=0이면 support 내 가중치 1. 입력은 Strength×InputFactor×a. 저장량 상한과 동일시하지 않음 |

각 식은 연산의 해당 부분을 분석한다. 생산 Solver의 Transport→Decay→Reaction 순서, 공급량 경쟁·내부 시간 분할·Geometry 갱신을 생략한 request 분석을 전체 Step 실행 결과라고 쓰지 않는다.

## 3. 방향 1: 같은 포화 외관·형상, 다른 후속 반응

### 3.1 저장량과 표시량의 비단사성

[C,D] 고정된 동일 평면·Profile·재질·camera·lighting, 다른 State=0인 두 상태를 생각한다. 비교하는 모든 유효 texel에서

\[
I_i^{(x)}=4a_i,\qquad I_i^{(y)}=8a_i.
\]

Ice 표시 포화도는 두 상태 모두 1이다. Ice의 cavity 기여가 0이므로 world 기준 요청 축적 두께도 두 상태 모두

\[
g_i=0.035\min(I_i/a_i,4)=0.14
\]

다. 동일 변환/normal에서 local 높이 변환도 같다. 모든 관련 이웃의 capped 값이 같으므로 그 값에서 만드는 smoothing·형상 gradient도 같다. 초과 Ice는 immobile이고 decay=0이며, Heat=0이면 두 반응의 request는 0이다.

따라서 위 조건의 **clamped State 관측과 형상 관측은 저장량 차이를 식별하지 못한다.** 실제 최종 framebuffer의 완전한 동일성은 아직 실행 확인하지 않았다. overflow inspector·총량 지표를 관측에 포함하면 당연히 두 상태를 구별한다. 일반적인 모든 관측에 대한 비식별성 주장이 아니다.

### 3.2 같은 Heat probe가 차이를 드러내는 이유

Heat 면적당 양을 \(h_i=H_i/a_i\)라 하면 현재 초기 융해 request는

\[
r_i=0.5I_i(h_i-0.25)_+.
\]

같은 probe로 h=0.5를 준 순간, 두 request는 각각 \(0.5a_i\), \(1.0a_i\)다. 이는 **초기 requested extent/time**이며 유한 GPU Step의 실측값이 아니다. 충분히 짧은 시간에는 Heat 소비 0.45와 Ice 공급량이 이를 제한하지 않는 조건을 만들 수 있다. 새 Waterfilm 냉각·수송·Heat Decay 때문에 이후 곡선은 이 고정률을 그대로 적분한 값이 아니다.

원래 4a인 Ice는 소량 융해 뒤 Capacity 아래로 내려가고 8a인 Ice는 한동안 포화 상태에 남는다. 이 때문에 후속 물막 생성뿐 아니라 이후 Geometry에도 차이가 생길 가능성이 있다. 전체 장면에서 유의미한 차이인지는 미검증이다.

### 3.3 중요한 허용 조작 범위의 제한

이 쌍은 **State→관측의 비단사성**을 보인다. [[90_Research-Archive/Research-Notes-2026-10/10_Authoring/04_Inverse-Authoring|U-input]]은 초기 Ice를 고정하고 Heat/Waterfilm 입력만 조정하므로, 위 초기 Ice 쌍을 그 과제의 두 해라고 부를 수 없다.

별도 **U-seed 진단**으로 초기 Ice contact strength만 4와 8로 바꾸는 구성은 기존 입력 식과 양립한다. 균일 Profile에서 support 전체를 덮는 Falloff=0 contact가 그 후보이며 실제 파일/장면은 아직 만들지 않았다. 이것은 고정 초기 상태 과제에서의 허용 범위를 사후 바꾸는 대조가 아니다. U-seed와 기존 U-input 결과를 별도로 보고한다.

따라서 다음 두 검증을 분리해야 한다.

1. U-seed에서 이 코드 기반 반례를 실제 State/형상/외관/probe 계측으로 확인한다.
2. 원래 U-input에서도 관측 목표를 비슷하게 맞춘 서로 다른 admissible rollout이 생기고 그 차이가 제작상 중요한지 찾는다. 없다면 U-input 역설계의 핵심 동기로 쓰지 않는다.

**연구적 의미와 한계:** 외관 목표만 맞춰 향후 거동까지 맞는다고 간주할 수 없다는 구체적 예다. 숨은 저장량·관측 모호성 자체는 새 연구가 아니며, probe loss를 더한 표준 constrained optimization으로 충분하면 방향 1의 독립 기여는 약하다.

## 4. 방향 2: 0 민감도와 유한 편집의 실행 가능성은 다르다

[D] request 하나를 분리해 Ice 면적당 양 i>0, \(h_0=0.20\)라 두면

\[
\rho(i,h)=0.5i(h-0.25)_+=0,\qquad
\partial_h\rho(i,h_0)=0.
\]

\(|\delta h|<0.05\)의 작은 차분도 융해 request 변화 0만 본다. 그러나 허용 bounds가 \(\delta h=0.10\)을 포함하면 새 request는 \(0.025i>0\)다. 한 request의 예이며 전체 보호 제약을 만족하는 rollout witness는 아니다.

이 ramp는 threshold에서 연속이나 미분 불가능하고, 아래쪽에는 평평한 구간이 있다. TeG가 다루는 parametric discontinuity와 완전히 같은 문제라고 하지 않는다. 작은 AD/차분의 0 gradient가 틀린 것도 아니다. **그 gradient로 전역 도달 가능성까지 판단하는 해석이 틀릴 수 있다.**

### 4.1 수정한 알고리즘 탐색 명세 — 전부 미구현

1. 현재 active regime 안에서는 표준 bounded SQP/trust-region과 full-coupling 민감도로 편집/보호를 맞춘다.
2. 진전이 없으면 선언된 ramp/step threshold와 Capacity clamp까지의 margin을 검사한다. 입력 basis가 바꿀 수 없는 margin을 건너도록 무리하게 제안하지 않는다.
3. 허용 조작으로 event를 넘는 유한 trial을 검토하고, 원래 forward로 보호·수지·bounds를 검증한다. 이때의 추가 rollout 비용도 포함한다.
4. 성공한 regime에서 다시 국소 탐색한다. 실패하면 국소 탐색 실패/예산 소진으로 보고한다. 전역 불가능은 별도 보존식 등 인증이 있을 때만 말한다.

[H] 의미 있는 후보는 반응·형상 event의 구조를 이용해 불필요한 전역 trial을 줄이면서 보호 제약을 유지하는 방법이다. **event-aware 최적화 자체가 새롭다는 주장은 하지 않는다.**

강한 Baseline은 작은 차분 하나만 쓰는 gradient descent가 아니다. 다중 크기 차분+SQP, multi-start, 동일 budget의 derivative-free 방법을 포함한다. 이들이 충분하면 event 특화 알고리즘의 기여 주장을 중단한다. 현재는 전체 보호 과제의 필요성·성공률·비용 우위 모두 미확인이다.

## 5. 방향 3A: 모든 이차 State 모멘트도 ramp 반응에는 부족한 반례

### 5.1 여섯 개의 동일 면적 미세 셀

[C,D] Transport/Decay/Geometry 변화와 다른 반응의 영향을 분리해 `ice_melting`의 초기 request만 비교한다. 각 셀의 Ice 면적당 양 i=1, Waterfilm=0, Heat h는 다음과 같다.

| 분포 | 6개 셀의 h | 평균 h | 평균 h² | 분산 h | 평균 \((h-0.25)_+\) | 평균 융해 request/면적/시간 |
|---|---|---|---|---|---|---|
| X | 0, 0, 0, 0.5, 0.5, 0.5 | 1/4 | 1/8 | 1/16 | 1/8 | **1/16** |
| Y | 0, 0, 0.25, 0.25, 0.25, 0.75 | 1/4 | 1/8 | 1/16 | 1/12 | **1/24** |

Ice가 상수이므로 Ice–Heat 공분산은 모두 0이고, 나머지 채널도 같아서 **전체 State 벡터의 평균과 이차 모멘트가 일치**한다. 하지만 \(0.5\overline{i(h-0.25)_+}\)는 다르다. 동일한 이차 통계만 받는 모델은 두 초기 request를 동시에 정확히 재현할 수 없다.

이 반례는 threshold가 포함된 비다항 반응에서 covariance 한 항만 더하면 충분하다는 기대를 배제한다. 두 분포의 max와 활성 비율은 다르므로 min/max·histogram·quadrature까지 같은 정보라고 주장하지 않는다. 실제 공급량 제한·내부 시간 분할을 포함한 유한 Step 결과는 별도다. 이 반례 역시 일반적인 moment 문제의 한 사례이며 새 정리가 아니다.

### 5.2 필요한 feature를 반응식에서 선택할 수 있는가?

초기 rate만 맞추려면 \(M_{\rm melt}=\overline{i(h-\tau)_+}\), 냉각에는 \(M_{\rm cool}=\overline{hw}\)처럼 실제 선언 rule의 request를 보존하는 feature가 직접적이다. 그러나 fine 정보를 매 Step 읽어 이를 다시 계산하면 compact coarse 방법이 아니라 oracle이다.

고정 면적·반응 rate의 연속시간 해석에서도 거의 모든 시점에서

\[
\frac{d}{dt}M_{\rm melt}=
\overline{\dot i(h-\tau)_+ + i\mathbf1_{h>\tau}\dot h}
\]

다. 여기에 현재 반응을 대입하면 활성 영역의 다른 곱/고차 정보가 필요하다. 수송까지 켜면 경계 상태와 공간 연결도 필요하다. feature를 하나 추가한 것만으로 닫힌 진화식을 얻은 것은 아니다.

[H] **선언된 반응과 형상 식이 실제로 사용하는 비선형 feature를 우선 보존하는 소수 양수 quadrature/적응형 microcell 표현**을 검토할 수 있다. 특정 threshold 양쪽의 대표 상태를 두는 방법도 후보지만, 알려진 presumed-PDF/QMOM/DQMOM과 비교해야 한다.

## 6. 방향 3B 이전에 분리할 형상 clamp의 평균화 문제

[C,D] 평면·meso=0·cavity=0·한 축적 채널에서 \(g(s)=\kappa\min(s,c)\)다. \(\kappa\)는 accumulationFactor×thickness다. 두 동일 면적 셀을 합치면:

| 미세 State/면적 | 평균 s | 평균 fine 높이 | 평균 State에서 다시 만든 높이 |
|---|---|---|---|
| 0, 2c | c | κc/2 | κc |
| c, c | c | κc | κc |

같은 총 저장량이 같은 평균 축적 높이를 뜻하지 않는다. 이 차이는 Chart 최대 높이와 무관하고, 현 artistic occupancy의 Capacity clamp에서 직접 생긴다. concave clamp와 평균의 비가환성은 알려진 성질이다.

필요하다면 coarse 저장량 \(\bar s\)와 별도로 **capped occupancy** \(m_c=\overline{\min(s,c)}\)를 구별해야 한다. \(0\le m_c\le\min(\bar s,c)\)이며 초과 저장량을 버리라는 뜻이 아니다. \(m_c\)도 독립적인 시간 진화에는 cap 근처 분포 정보가 더 필요하다.

이 예는 평균 높이 관측만 분석한다. 같은 평균 높이라도 공간 배열/장벽 연결에 따라 Flux가 달라진다. 반응 feature와 capped occupancy를 저장한다고 수송 경로까지 해결되지는 않는다. 물리 부피 보존 문제로 이름을 바꾸지도 않는다.

## 7. 추가 문헌 확인과 독창성 제한

[P] Akroyd et al.의 Cambridge preprint(2009, 후속 CES 2010) 원문 서론은 joint composition PDF로 반응 source를 닫고, 저차 모멘트의 presumed PDF는 가정한 분포에 의존하며, DQMOM의 가중 대표 상태로 다중 scalar를 다루는 기존 방법을 설명한다. singularity/boundedness도 이미 논의한다. 따라서 **‘평균 대신 소수 대표 상태로 비선형 반응을 계산’은 새 아이디어가 아니다.** [R12, [기관 원문](https://como.ceb.cam.ac.uk/media/preprints/c4e-Preprint-76.pdf)]

[P] Marchisio & Fox의 QBMM 장 요약도 모멘트에서 node/weight를 복원하는 방식과 다변량 확장을 명시한다. 본문 전체를 읽지는 않았다. [R13, [출판사 요약](https://doi.org/10.1017/CBO9781139016599.004)]

확인 범위와 접근 실패는 [[90_Research-Archive/Research-Notes-2026-10/90_Reference/07_Related-Work|R12–R13 장부]]를 따른다. DQMOM이 MDSSP의 State-dependent transport/capped geometry에 그대로 가장 좋은 방법이라는 결론도 내리지 않는다. 남은 비교 질문은 **반응·점유·경로를 함께 다룰 때 표준 closure의 어떤 가정이 실제로 부족하며, 그 부족분을 작은 독립 갱신 상태로 해결할 수 있는가**다.

## 8. 최소 판별 과제 — 실행 재개 전 명세

| ID | 입력/관측을 고정할 내용 | 첫 강한 대조 | 기각/축소 조건 |
|---|---|---|---|
| ANA-1 | U-seed와 U-input 분리. 관측에 overflow 총량을 포함하는지 명시. 같은 probe 및 초기/후속 State·형상·화면 비교 | 외관/상태 목표 + 표준 probe loss 최적화 | 원래 U-input에서 모호성이 없거나 probe 차이가 제작상 중요하지 않음 |
| ANA-2 | 작은 request 예 → 보호가 있는 rollout 순으로 확대. 허용 basis/bounds와 threshold 거리 보관 | 다중 크기 FD+SQP, multi-start, 동일 budget derivative-free | 표준 탐색으로 충분하거나 Geometry 경로가 중요하지 않음 |
| ANA-3 | 2-cell 냉각, 6-cell 융해, 2-cell capped height를 각각 분리. request와 적분 결과를 구분 | 평균/단위 보정, covariance, 표준 2/4-node 양수 quadrature, microgrid | 기존 compact closure가 충분하거나 대부분 fine 유지가 필요함 |

ANA는 분석 질문 식별자이며 실행 번호/PERF 결과가 아니다. 다음 구현 후보를 정하기 전 표준법의 수식·갱신 조건과 실제 비용을 먼저 확정한다. 실측이 생기면 기존 Experiments와 Performance-Data 구조에 기록하고 이 파일에는 해석을 연결한다.

**아직 미해결:** U-input의 실제 허용 해 쌍, 보호 편집의 nontrivial feasible witness, 표준 optimizer의 실패, coarse closure의 장시간 독립 갱신·양수성·수지·경계 통과와 비용, 외관/제작상 중요성. 현재 결론을 Contribution 확보로 상향하지 않는다.

이후 사용자의 심화 추론 요청에 따라 [[90_Research-Archive/Research-Notes-2026-10/30_Deep-Analysis/11_Contribution-Proof-Obligations|입증 조건 문서]]에서 내부 이동량/inflowFraction의 공간 반례, hinge/cap 분석, 대표 상태의 존재와 갱신 한계, 보호 하한·도달 불가능 조건을 추가했다. 이 노트의 초기 반례와 새로운 내용을 구별해 보존한다.
