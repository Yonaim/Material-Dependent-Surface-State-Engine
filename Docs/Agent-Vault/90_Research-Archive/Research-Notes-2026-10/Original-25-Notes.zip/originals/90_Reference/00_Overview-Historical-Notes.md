# 이전 연구 개요 보존본

2026-10-28까지 누적된 긴 개요를 기록용으로 보존했다. 최신 판단과 읽는 순서는 [[90_Research-Archive/Research-Notes-2026-10/00_Overview|현재 연구 안내]]를 따른다.

# MDSSP Research

작성: **2026-10-27**, 마지막 갱신: **2026-10-28 / Asia/Seoul**

이 폴더는 MDSSP의 **연구 목적, 대화에서의 판단 변화, 기여 후보, 문헌 근거, 미검증 가설과 후속 연구**를 관리한다. 사용자의 ‘05번 리서치 폴더에 지금까지의 대화를 여러 문서로 기록한 뒤 연구를 진행’하라는 요청으로 만들었다.

## 현재 결론과 작업 범위

- 현 MDSSP의 학술적 판정은 **기존 연구의 시스템 통합에 가깝고, 새로운 Contribution은 아직 미입증**이다.
- 연구 목표는 물리적으로 정확한 부피 모델보다 **제어 가능한 현상학적·예술적 점유 모델**에 가깝다. 물리 Solver로 바꾸는 것을 논문 통과 조건으로 가정하지 않는다.
- 새 연구는 **1 목표 진행·후속 반응 역설계 + 2 다른 현상을 보존하는 편집**을 한 축으로, **3 혼합·경로 정보를 유지하는 coarse 표현**을 별도 축으로 검토한다.
- [[90_Research-Archive/Research-Notes-2026-10/18_Research-Landscape-and-Selection|18의 확장 비교]]는 일곱 연구 방향을 구분한다. 이후 19–22의 분석을 반영한 우선순위는 **보호 편집(A)**의 실제 입력 가능성, **재질 규칙(B)**의 의미 계약, 계산 축소(E)의 별도 제한 탐색이다. 기존 방향1·2·3의 분석을 폐기하는 것이 아니라 연구 목적별 우선순위를 넓혀 재평가한 것이다.
- 사용자가 **4 축적 순서/층 표현 방향은 제외**했다. 이를 후속 필수 기능으로 다시 넣지 않는다.
- **로컬 앱·GPU·빌드·벤치마크·학습 실행은 중지 상태**다. 이후의 ‘연구 진행’은 명시적 재개 지시 전까지 문헌·기존 코드/자료 읽기·수식 분석·문서 작성으로 수행한다.

## 문서 지도

| 문서 | 내용 |
|---|---|
| [[90_Research-Archive/Research-Notes-2026-10/90_Reference/01_Discussion-History|대화의 논점과 판단 변화]] | 최초 요청·평가 원칙, 물리/예술 모델 선택, 잘못된 전제의 수정, Baseline 중단, 아이디어 선택과 실행 중지 |
| [[90_Research-Archive/Research-Notes-2026-10/02_Evidence-and-Current-Judgment|확보한 증거와 현 판정]] | 완료 실험·한계·중단된 과제·구현/설계/제안 구분. 원자료의 정본 위치 |
| [[90_Research-Archive/Research-Notes-2026-10/03_Contribution-Candidates|Contribution 후보 장부]] | 후보별 실제 차이, 기대 기여, 반론, 현재 강도·추진 조건·제외 항목 |
| [[90_Research-Archive/Research-Notes-2026-10/10_Authoring/04_Inverse-Authoring|방향 1: 목표 진행·후속 반응 역설계]] | 조작 범위·관측 모호성·목적함수·대조·중단 기준 |
| [[90_Research-Archive/Research-Notes-2026-10/10_Authoring/05_Protected-Editing|방향 2: 다른 현상을 보존하는 편집]] | 제한된 조작·수정/보호 제약·Geometry 민감도·실행 가능성·범위 선택 |
| [[90_Research-Archive/Research-Notes-2026-10/30_Deep-Analysis/06_Coarse-Reactive-Transport|방향 3: 혼합·경로 coarse 표현]] | 코드에서 유도한 평균화 반례, closure 후보와 한계, 반응/수송/결합의 분리 |
| [[90_Research-Archive/Research-Notes-2026-10/90_Reference/07_Related-Work|후속 연구 문헌과 확인 수준]] | 역설계·편집·coarse 연구의 1차 출처, 실제 읽은 범위·접근 실패·미확인 사항 |
| [[90_Research-Archive/Research-Notes-2026-10/08_Research-Agenda|연구 질문·판정 순서]] | 현재 질문, 강한 Baseline, 최소 판별 과제, 진행/기각 조건, 실행 재개 전 필요한 고정 사항 |
| [[90_Research-Archive/Research-Notes-2026-10/90_Reference/09_Analytical-Findings|후속 수식·구조 분석 노트]] | 폴더 정리 이후 수행한 연구. 유도 결과·가정·반례·알고리즘 초안과 미검증 구분 |
| [[90_Research-Archive/Research-Notes-2026-10/20_Solver-Semantics/10_Forward-Model-and-Controls|공통 forward 모델·코드 근거]] | 세 방향이 공유하는 실제 연산 계약, 비매끄러운 지점, 재사용할 입력/계측과 기존 실행의 한계 |
| [[90_Research-Archive/Research-Notes-2026-10/30_Deep-Analysis/11_Contribution-Proof-Obligations|Contribution을 위한 심화 추론]] | 내부 총 이동·유입 반응의 coarse 반례, hinge/cap 구조, 대표 상태의 존재와 한계, 보호 오차 하한·불가능 판정, 방법 초안과 입증 조건 |
| [[90_Research-Archive/Research-Notes-2026-10/30_Deep-Analysis/12_Exact-Submodels-and-Limits|정확한 최소 모델과 불가능 조건]] | 두 texel의 독립 갱신·남은 잔류량 bound, memory 필요성, 정확 압축의 차원 하한, cap별 보호 제약·반응 단계 witness |
| [[90_Research-Archive/Research-Notes-2026-10/30_Deep-Analysis/13_Method-Blueprints-and-Decision|방법 초안·돌파 지점·중단 조건]] | 내부 mode 기반 block, 보호 목적별 편집/축소, 제한적 인증의 실제 공백·강한 대조·현재 우선순위 |
| [[90_Research-Archive/Research-Notes-2026-10/30_Deep-Analysis/14_Residual-Budget-Critical-Review|미래 반응 오차와 계산 생략의 고찰]] | 열린 경계·중력 flux의 potential, cycle에서의 한계, 유한시간 budget, 누적량/실행 오차/전체 품질의 구분 |
| [[90_Research-Archive/Research-Notes-2026-10/30_Deep-Analysis/15_Joint-State-Error-and-Geometry-Bounds|물·잔류 공동 오차와 형상 민감도]] | limiter 재분배를 포함한 edge 삭제 상한, 유입 반응의 오차 증폭 반례, 정적 LS 계수 기반 Normal bound, 중력/Concavity 조건·저비용 판정 초안 |
| [[90_Research-Archive/Research-Notes-2026-10/30_Deep-Analysis/16_Low-Cost-Certificates-and-Sleep-Horizons|저비용 판정과 계산 생략 기간]] | 공통 하한 기반 장기 공동 오차, 중력/limiter 포함 α 상한, 이동률 구간 질량·O(K) 기간 판정, 열린 경계/해상도 한계·기존 cap 최적화 확인 |
| [[90_Research-Archive/Research-Notes-2026-10/30_Deep-Analysis/17_Open-Boundary-Contracts-and-Composition|열린 경계 계약과 오차 합성]] | 공통 유입 cohort의 공동 오차·block 합성, 단순 합성의 열세, 내부 outgoing 합·Geometry 매개 경계 영향, branch별 충분조건 |
| [[90_Research-Archive/Research-Notes-2026-10/18_Research-Landscape-and-Selection|연구 방향 확장 비교와 선택]] | 보호 편집·규칙의 해상도 일관성·동작 retargeting·미래 상태 식별·LOD·진단·Meso 강건성의 일곱 방향, 코드 기반 경로 분할/정보 손실 분석, 강한 대조·기각 조건·우선순위 |
| [[90_Research-Archive/Research-Notes-2026-10/10_Authoring/19_Protected-Editing-Feasibility-and-Response-Coordinates|보호 편집 가능 범위]] | Heat 진행 보호의 불가능 조건, 반응 진행 좌표와 이산 공급 제한의 관계 |
| [[90_Research-Archive/Research-Notes-2026-10/20_Solver-Semantics/20_Transport-Reaction-Semantics-and-Refinement|수송·반응 의미]] | 유입과 순수송의 차이, 방향성, 경쟁 반응과 경로 분할의 제한 |
| [[90_Research-Archive/Research-Notes-2026-10/10_Authoring/21_Constructive-Controls-and-Reaction-Contracts|양수 입력·반응 계약]] | 제한 연속 모델의 입력 구성, 현재 inflowFraction의 요청·소비 계약 |
| [[90_Research-Archive/Research-Notes-2026-10/10_Authoring/22_Protected-Editability-and-Geometry-Mediation|편집 자유도·형상 매개 판정]] | 유한 접촉 입력의 가능 조건, 동일 예산의 한계, 시간별 Geometry 재생 대조 |
| [[90_Research-Archive/Research-Notes-2026-10/10_Authoring/23_Contact-Control-Space-Audit|실제 Contact 입력 공간 감사]] | 현 DemoAnim의 48개 Heat 사건, 예산 중립의 유한 입력 방향, Remove와 재배치의 의미 구분 |

12·13의 분석에서는 방향3의 **제한된 두 texel에서 독립 갱신과 미래 총 잔류 오차 상한**을 유도했다. 추가로 닫힌 graph의 saturation-only 수송·단일 전환·dt 조건에서는 동적 Geometry를 허용하는 미래 잔류/물 L1 bound도 유도했다. 외부 입력·다중 반응의 일반 해법과 실제 비용/신규성은 미검증이다. 방향2에는 cap별 보호 가능 범위와 반응 한 substep의 대수적 witness를 추가했다. 이것은 앱 실행이나 실제 U-input 실험 결과가 아니다. 세부 판단은 12·13을 따른다.

2026-10-28의 후속 고찰(14)은 외부 유입·중력/비대칭 flux를 허용하는 경로 potential과 유한시간 budget을 추가 유도했다. 무한시간에 양의 전환 cycle을 허용하면 bound가 전체 물량으로 퇴화한다. **잔류량 bound가 작다는 사실만으로 물/Geometry/다중 State의 계산 생략은 정당화되지 않는다.** 저비용 유지와 수송/경계 오차 보장이 남아 있으며 실행·신규성 검증은 추가되지 않았다.

같은 날 이어진 15의 분석은 **물·잔류의 공간 분포를 함께 제한하는 한 Step 오차**로 범위를 넓혔다. 일부 raw edge 삭제 시 limiter 재분배를 포함해 2V 상한을 유도했고, Incoming 전환은 총량 보존 상태에서도 실행 간 L1 오차를 키울 수 있음을 보였다. 현재 Normal 복원의 LS 행렬이 정적이라는 코드 근거로 사전 민감도 계산 가능성을 찾았다. 중력 정규화·동적 Concavity·다중 반응·오차 장부 비용은 별도 조건/미해결점이다. 기존 적응형 multiresolution/반응–확산 선례 R36–R38과 대조했으며 **신규성 평가는 상향하지 않았다.**

16의 후속 연구에서는 **공통으로 유지되는 물량 하한**을 이용해 매 Step 민감도를 다시 계산하지 않는 대안을 유도했다. 닫힌 saturation-only 영역은 기간에 무관한 2B, 중력/limiter를 허용하는 단일 유입 전환 영역은 초기 물량과 outgoing 비율 α로 유한 기간의 공동 오차를 제한한다. α 구간별 질량을 모으면 감사 이후 O(K) 기간 판정이 가능하다. 열린 block 경계·높은 해상도·다중 반응에서는 효과/보장이 제한되며, 현재 cap 위 높이 생략은 이미 구현돼 있어 새 기여에서 제외했다. **조건부 방법 구성의 진전이며 실행·신규성 입증은 아니다.**

17의 후속 연구는 공통 유입과 port-time 출력 이력을 포함하는 상한을 유도하고, 제한 모델에서 block 경계 오차 항을 상쇄했다. 그러나 **동일한 α/기간의 단순 block 합성은 전체 영역 상한보다 느슨해 주력안에서 보류**했다. 현재 코드에서 경계 Flux가 내부 outgoing 합의 영향을 받고, 물질 이동이 없어도 Geometry로 외부 수송이 변할 수 있음을 확인했다. 다음 후보는 이 두 의존성을 반영해 내부 갱신 생략의 충분조건을 판정하는 경계 계약이다. 미구현·미실험이며, R42–R44의 보존 장부/port reduction/compositional abstraction 선례 때문에 신규성은 아직 미입증이다.

## 기록 원칙

19·20에서는 A의 반응 진행 보호와 B의 순수송/교환·방향·경쟁 반응 의미를 구체화했다. [[90_Research-Archive/Research-Notes-2026-10/10_Authoring/21_Constructive-Controls-and-Reaction-Contracts|21]]은 제한 연속 모델에서 같은 최종 상태·총 입력을 유지하며 진행을 바꾸는 입력의 존재를 구성하고, 현 inflowFraction의 전체 보유량 제한을 확인했다. [[90_Research-Archive/Research-Notes-2026-10/10_Authoring/22_Protected-Editability-and-Geometry-Mediation|22]]는 양수 입력과 추가만 허용하는 편집을 구분하고, 유한 contact basis의 국소 자유도 및 시간별 Geometry 재생 대조를 제안했다. 최신 [[90_Research-Archive/Research-Notes-2026-10/10_Authoring/23_Contact-Control-Space-Audit|23]]은 현 `b_heated`의 48개 Heat 사건에서 예산 중립의 **명목상 입력 방향**을 코드·자산으로 확인했다. **최종 결과 보호·새 해법의 신규성 평가는 여전히 미입증**이다. 현재 Research는 24개 문서이며 실험·제품 코드 변경은 없다.

이것은 **대화 전체의 축어록이 아니라, 현재 대화와 연결된 저장소 증거를 재구성한 주제별 기록**이다. 전달된 다른 에이전트의 답변은 인용된 의견으로 취급하며, 실제 코드/문헌/실험으로 확인한 내용과 분리한다. 보이지 않는 과거 발언·정확한 발언 시각을 만들어내지 않는다.

판정 표시는 **[U] 사용자 요청/선택, [C] 코드 확인, [E] 실행 증거, [P] 문헌 확인, [D] 수식/구조 분석, [H] 제안/미검증 가설**로 구분한다. ‘좋아 보임’은 신규성의 증거가 아니며, 선행연구에 없는 것으로 확인하지 못한 기능을 불가능하다고 쓰지 않는다.

연구 정리는 이 폴더에서 갱신한다. 구현 계약은 [[02_Architecture/00_Overview|Architecture]], 실제 검증은 [[04_Experiments/01_Validation-and-Tests|Validation]], 성능 실험은 [[04_Experiments/02_Performance-Measurements|Performance]]가 정본이다. raw를 이 폴더로 복사하거나 실험마다 별도 결과 설명 문서를 만들지 않는다.

`03_Development/03–07`은 이전 시점의 명세·분석과 결과 연결을 보존한다. 특히 [[03_Development/07_Research-Directions-123|1·2·3 방향의 최초 통합 검토]]는 역사적 snapshot이며, 이 폴더의 분리 문서가 후속 연구의 정본이다.
