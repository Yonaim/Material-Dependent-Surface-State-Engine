# 공통 forward 모델과 코드 근거

마지막 갱신: 2026-10-27. [[03_Development/07_Research-Directions-123|최초 통합 검토]]에서 분리한 후속 연구 정본이다. 이 파일의 내용은 제안·수식 분석이며 새 구현/실험 결과가 아니다. 로컬 앱·GPU·빌드 실행 중지를 유지한다.

문헌 출처는 [[90_Research-Archive/Research-Notes-2026-10/90_Reference/07_Related-Work|문헌 확인 수준]], 이 계산 구조에서 이어진 연구는 [[90_Research-Archive/Research-Notes-2026-10/90_Reference/09_Analytical-Findings|분석 노트]]를 따른다.


표면 graph를 고정하고 State 총량을 q, Profile/재질 계수를 θ, 사건 입력을 u, 파생 형상을 G라 한다. Dense·고정 시간 간격 경로를 연구 기준으로 삼으면 개념적으로 다음과 같다.

\[
q_{n+1}=\mathcal R_\theta(\mathcal T_\theta(q_n,G_n,u_n),\;\text{positiveInput}_n,\text{incoming}_n),
\qquad G_{n+1}=\mathcal B_\theta(q_{n+1}).
\]

`T`에는 Input/Transport/Decay, `R`에는 유입 비율 전환과 연속 반응, `B`에는 Height/Normal/Concavity/Weights가 포함된다. 실제 cache·scheduling의 의미는 동일 forward 경로로 검증해야 한다. 모든 GPU scratch가 수학적 물질 상태인 것은 아니다.

| 기능 | [C] 근거 | 1·2·3에 주는 조건 |
|---|---|---|
| 포화도·형상 기반 국소 flux | `Shaders/Simulation/Solver/Transport.glsl::rawFlux` | 양의 부분, cavity 저항 clamp, source/target 의존성이 존재 |
| outgoing 공급량 제한 | `SurfaceSolverPass1.comp::main` | `min`/분기에서 미분 불연속 또는 미분 불능 가능 |
| 실제 incoming·입력 장부 | `SurfaceSolverPass2.comp::main`, ReactionScratch plane | Reaction 생성물과 이웃 유입은 의미가 다름 |
| 선언 반응·경쟁·시간 세분화 | `SurfaceReaction.comp::reactionRequest/main` | threshold, supply limiter, 내부 반복 횟수 변화까지 forward 의미에 포함 |
| State→형상 | `StateMath.glsl::accumulationHeight/effectiveLocalPosition/effectiveLocalNormal` | 형상 기여의 Capacity clamp와 저장 State의 무상한 계약을 구분 |
| 형상→다음 수송 | `SurfaceDynamicGeometryUpdate.comp::main`, `SurfaceDynamicWeightsUpdate.comp::buildTransferWeight` | 목표 State를 수정하면 다른 채널의 전파도 달라질 수 있음 |
| 전체 기록 순서 | `Source/SurfaceState/Solver/SurfaceStateSolver.cpp::RecordSteps` | 다중 State·Reaction·Geometry 연산의 전/후 순서를 보존해야 함 |
| 화면 관측 | `Shaders/Rendering/Surface/Lighting/SurfaceLit.glsl`, `StateTexture/StateSampling.glsl` | 표시 clamp·재질 합성 때문에 관측이 State를 유일하게 정하지 않을 가능성. 실제 장면 반례는 미검증 |
| 입력·최소 계측 | `Contact/SurfaceContactApplication.cpp::ApplyPendingContacts`, `Rendering/Profiling/RendererBenchmark.cpp::WriteAuthoringCheckpoint` | 접촉 입력·같은 Step readback 재사용 가능. 미분·역문제용 자동 반복 인터페이스는 구현한 바 없음 |

[E] PERF-041의 한 판에서 Geometry D/E가 분포를 바꾼 것은 결합 경로가 작동한다는 증거다. 그 값이 gradient에서 중요하거나 역설계를 어렵게 한다는 증거는 아니다. PERF-042는 동일 수치 모델 내부 조정 구조의 확장 부담 우위를 지지하지 않았다. 이 결과를 새 최적화 방법의 Baseline 성능으로 재사용하지 않는다.

