# 연구 질문과 판정 순서

마지막 갱신: 2026-10-28. [[03_Development/07_Research-Directions-123|최초 통합 검토]]에서 분리한 후속 연구 정본이다. 이 파일의 내용은 제안·수식 분석이며 새 구현/실험 결과가 아니다. 로컬 앱·GPU·빌드 실행 중지를 유지한다.

## 최신의 넓은 연구 선택

[[90_Research-Archive/Research-Notes-2026-10/18_Research-Landscape-and-Selection|18]]에서 일곱 방향을 비교했다. 다음 비실행 판별은 **보호 편집의 작은 과제**와 **재질 규칙의 사건·거리·시간 의미 및 해상도 일관성**을 우선한다. 계산 축소는 제한된 별도 탐색으로 남기며, 단순 α-bin block 합성은 보류한다.

새 방향 B는 기존 fine 모델을 유지하는 최적화가 아니라 필요하면 규칙 의미를 바꾸는 연구다. 먼저 표준 거리 보정·가중 Incoming gather·continuous reaction으로 충분한지를 분석한다. 후보 A–G 문자는 18의 연구 방향 구분이며, 아래 과거 순서표 A–E와 별개다. 기존 방향4인 층/순서 모델은 제외한다.

이후 재사용 C는 보호 편집의 미사용 자산 평가로, 진단 F는 실패 해석으로 먼저 좁힌다. 상태 식별 D는 불완전 관측의 사용 시나리오가 있을 때만, Meso 강건성 G는 중요한 실제 영향의 근거가 생길 때만 추진한다. 아래 기록은 각 시점의 분석을 보존한다.

## 기존 방향1·2·3의 판별 절차

**A/B 심화 이후의 구체화:** [[90_Research-Archive/Research-Notes-2026-10/10_Authoring/19_Protected-Editing-Feasibility-and-Response-Coordinates|19]]의 A0–A3와 [[90_Research-Archive/Research-Notes-2026-10/20_Solver-Semantics/20_Transport-Reaction-Semantics-and-Refinement|20]]의 B0–B4를 후속 명세로 사용한다. A는 보호 요구가 편집 자체를 막는 조건과 실제 입력의 자유도를 먼저 구분한다. B는 거리·방향·경쟁의 표준 해법을 먼저 검토하고 Geometry 결합에서 남는 공백을 찾는다. 둘 다 미실행 명세이며, 성능/제작 효과/신규 알고리즘 성공 기록이 아니다.

공통 근거는 [[90_Research-Archive/Research-Notes-2026-10/20_Solver-Semantics/10_Forward-Model-and-Controls|forward 모델]], 문헌 출처는 [[90_Research-Archive/Research-Notes-2026-10/90_Reference/07_Related-Work|문헌 확인 수준]], 이후 연구는 [[90_Research-Archive/Research-Notes-2026-10/90_Reference/09_Analytical-Findings|분석 노트]]를 따른다.


| 순서 | 산출물 | 계속할 조건 | 중단/축소할 조건 |
|---|---|---|---|
| A | 방향 1의 관측-후속 반응 모호성 진단, 방향 2의 허용 조작/보호 지표·실행 가능한 단위 과제 | 제작상 중요한 trade-off가 실제 있음 | 목표가 수치 floor 안의 차이이거나 UI 문제뿐임 |
| B | 작은 차원의 **전역 표준 constrained optimizer** 결과 | 같은 의미·예산에서 해결 안 되는 정확한 이유가 남음 | 표준 방법으로 충분하면 새 특화 알고리즘 보류 |
| C | 방향 2의 coupling-aware 수정 초안·gradient/범위 Ablation | forward 검증과 보호 오차를 맞추며 유용한 품질–비용 차이 | 단순 loss/기본 최적화 조합 이상 차이 없음 |
| D | 방향 3의 reaction-only 최소 반례·표준 closure/microgrid 대조 | 정보 손실이 실제 진행/외관에서 중요하고 기존 closure의 한계가 있음 | 단위 보정/표준 mixing correction으로 충분 |
| E | 한 연구 축만 선택해 사례/미사용 입력/mesh 확대 | 중요한 모델 차이와 해결 방법을 설명 가능 | 세 문제를 통합했다는 이유만으로 범위 확대하지 않음 |

A/B와 D는 독립적인 문제 탐색이지만 실행 자동화나 동시 GPU 부하를 지금 시작하지 않는다. 사람의 제작 시간 연구, UI 제작, 모든 GLSL의 differentiable rewrite, 대규모 학습 데이터 생성은 초기에 필요하지 않다. 1+2의 forward가 지나치게 비싸면 먼저 짧은 headless 상태 목표 진단을 고려하되, production과 일치한 범위·renderer/접촉 생략을 명시한다.

**최종 연구 권고:** 1은 2의 목표·평가 층으로 통합한다. 2는 ‘제약된 조작으로 결합 결과를 선택적으로 수정’하는 방법이 표준 최적화보다 필요한지를 먼저 확인한다. 3은 반응 평균화의 코드 기반 반례에서 출발하되 기존 closure를 반드시 상대한다. 지금 확정할 것은 문제/기각 조건이며, 확정 Contribution이나 채택 확률이 아니다.

## 이번 분석 이후 구체화된 최소 질문

[[90_Research-Archive/Research-Notes-2026-10/90_Reference/09_Analytical-Findings|분석 노트]]에서 ANA-1/2/3의 가정·강한 대조·기각 조건을 정리했다. 이 식별자는 실험 실행 번호가 아니다.

- **ANA-1:** Ice의 숨은 초과 저장량 반례를 U-seed 진단과 초기 고정 U-input 과제로 구분한다. 후자에서 실제 허용 rollout 쌍이 생기는지는 미확인이다.
- **ANA-2:** threshold 아래의 작은 gradient만으로 불가능을 판정하지 않는다. event margin 기반 초안보다 먼저 다중 크기 FD+SQP·multi-start·derivative-free의 능력을 확인한다.
- **ANA-3:** 평균의 곱 반례에 더해 동일 이차 모멘트/상이한 ramp request, capped height의 평균화 반례를 분리한다. 표준 2/4-node 양수 quadrature와 microgrid가 첫 강한 대조다. compact feature의 독립 갱신이 없으면 아직 해법이 아니다.

새 문헌 R12–R13은 대표 상태/분포 closure의 기존성을 강화한다. 따라서 연구 질문은 ‘어떤 통계를 추가할까’에서 **현재 반응·점유·경로에 필요한 정보를 어떤 저비용 갱신으로 유지할까, 표준법보다 왜 필요한가**로 좁힌다. 로컬 실행은 계속 중지한다.

## 심화 추론 이후의 우선 판별

[[90_Research-Archive/Research-Notes-2026-10/30_Deep-Analysis/11_Contribution-Proof-Obligations|심화 추론 §9]]의 H3-E/H3-C/H2-P를 따른다. 방향3은 histogram만으로 빠지는 **내부 이동에 따른 유입 전환**을 추가로 다룬다. 먼저 고정 fine 규칙을 보존할 제작 필요와, 표준 microgrid/graph/fine Sparse로 충분하지 않은 이유가 있어야 한다. 방향2는 보존량/수지로 불가능한 요구를 제외한 뒤, 유한 event를 넘는 보호 편집을 표준 optimizer와 비교한다. 세 방향 모두 실행 증거는 추가되지 않았다.

## 실행 없는 연구에서 확보한 다음 출발점

[[90_Research-Archive/Research-Notes-2026-10/30_Deep-Analysis/12_Exact-Submodels-and-Limits|최소 모델]]의 두 texel exact closure를 **실험 재개 이후의 첫 sanity reference**로 쓸 수 있다. 아직 실행/구현하지 않는다. 범용화를 위해서는 외부 입력을 받을 signed 내부 상태, port별 장부, 잔류의 위치와 Geometry 재구성, 폐기한 정보의 복원 비용이 필요하다. 잃어버린 fine 정보를 refinement만으로 복구할 수 있다고 가정하지 않는다.

‘모든 미래를 보존하는 작은 모델’은 path observability 예제에서 반박된다. 대신 관측·입력 범위·시간·허용오차를 먼저 고정한다. 후보 A/B/C의 알고리즘 공백·강한 Baseline·기각 조건은 [[90_Research-Archive/Research-Notes-2026-10/30_Deep-Analysis/13_Method-Blueprints-and-Decision|방법 명세]] §6–8을 따른다. 현재 실행 허가는 없고, 새 PERF 결과도 없다.

## 공동 오차 분석 이후의 다음 이론 과제

[[90_Research-Archive/Research-Notes-2026-10/30_Deep-Analysis/15_Joint-State-Error-and-Geometry-Bounds|15]]에서 한 Step의 물·잔류 공동 오차와 고정 계수 전파 상한을 유도하고, 정적 LS 계수로 Normal 민감도를 사전 계산하는 가능성을 확인했다. 다음은 cavity/Decay OFF·단일 Incoming 전환·제한된 거리/중력 margin 조건에서 **State 범위→높이/Normal 범위→계수 차이→오차 장부**를 끝까지 연결하는 일이다.

원래 fine flux를 먼저 계산하지 않고 상한을 얻어야 한다. block 범위가 너무 넓어 생략을 거의 허용하지 않거나, 판정이 fine 계산만큼 비싸면 이 설계는 중단/수정한다. 기준은 잔류 총량만이 아니라 물/잔류 공간 분포와 필요한 경계 관측이다. 고정 주기·높이 threshold뿐 아니라 같은 오차 정보와 사전 계수를 허용한 기존 적응형 대조를 상대한다. **문헌·수식 연구의 다음 단계이며 실행 재개 지시가 아니다.**

16에서 [[90_Research-Archive/Research-Notes-2026-10/30_Deep-Analysis/16_Low-Cost-Certificates-and-Sleep-Horizons|공통 하한·α-bin 기간 판정]]이라는 대안을 구성했다. 제한 모델에서는 Geometry의 미분 상수 Γ 대신 전체 형상/이동량 범위로 충분조건을 만들 수 있다. 다음 비실행 질문은 **그 범위가 너무 넓어지는 조건을 얼마나 줄일 수 있는가**이다. 특히 열린 경계의 gross 유출입, 높은 해상도에서 α=1로 퇴화하는 조건, 기존 cap 생략과 중복하지 않는 실제 절감 대상을 구분한다. 유용한 기간이 0–1 Step뿐이거나 범위 유지에 fine 갱신만큼의 계산이 들면 추진하지 않는다. 기존 self-triggered/적응형 방법에도 같은 사전 정보와 요약을 허용해야 한다.

## 열린 경계 분석 이후의 범위 축소

[[90_Research-Archive/Research-Notes-2026-10/30_Deep-Analysis/17_Open-Boundary-Contracts-and-Composition|17]]의 단순 α-bin block 합성은 같은 조건의 전체 영역 bound보다 느슨해 주력 구현안에서 보류한다. 다음 이론 과제는 **근사 때문에 달라진 경계 응답만 제한하면서, 내부 fine 갱신을 피하는 충분조건**이다.

먼저 같은 boundary State/raw에서 내부 outgoing 합 범위 [L,U]가 source limiter와 실제 경계 Flux에 미치는 영향을 사용한다. limiter 비활성 인증 M≥S+U일 때 내부 합의 정확한 값은 불필요하다. 이어서 물질 port와 별개인 Geometry stencil 영향을 포함해야 한다. 외부에서 필요한 높이/Normal/Concavity 범위와 계산 시점, 내부 합 범위를 fine 계산보다 싸게 유지할 수 없으면 이 후보도 중단/축소한다. 표준 microgrid·port reduction·적응형 오차법에 같은 정보/branch 판정을 허용하는 대조가 필요하다. **실행 재개 지시는 없으며 새 PERF 결과도 없다.**

## 최신 A/B 과제 — 제한 모델의 가능성에서 실제 조작 범위로

[[90_Research-Archive/Research-Notes-2026-10/10_Authoring/21_Constructive-Controls-and-Reaction-Contracts|21]]에서 A의 양수 입력·동일 endpoint·조건부 동일 총 입력의 해를 구성했다. 다음 비실행 질문은 **그 연속 입력을 현재 contact 위치·event 시점·양으로 표현할 수 있는가**, 그리고 공간 수송/Geometry를 복원하면 보호 조건이 무엇을 더 요구하는가다. analytic seed+표준 constrained optimizer를 강한 대조로 삼는다. 국소 모델에서 만든 해를 production 성공으로 집계하지 않는다.

B에서는 현재의 ‘유입에 비례한 요청’과 제안된 ‘신규분만 소비’를 구분했다. 비교할 모델 의미를 먼저 고정하고 표준 자원 배분·경쟁 kinetics·순 flux 상쇄가 해결하는 범위를 제외한다. rule 추가 후 모든 기존 결과가 그대로여야 한다는 불가능한 조건 대신, 공유 자원의 경쟁과 결과 변화가 예측 가능한지 평가한다. **실험 재개나 제품 모델 변경을 지시하는 문서가 아니다.**

## 편집 가능 영역과 Geometry 경로의 판별

[[90_Research-Archive/Research-Notes-2026-10/10_Authoring/22_Protected-Editability-and-Geometry-Mediation|22]]에 따라 실제 contact 조작이 추가만 허용하는지 기존 사건의 양·시간·위치를 재배치할 수 있는지, 독립 입력 수와 보호 조건 수를 먼저 고정한다. 같은 총 입력·항상 빠른 융해·형상 경로 완전 보호 같은 조건이 국소 모델에서 충돌할 수 있으므로, 최적화 실패 사례로 만들기 전에 배제한다.

실험 재개 시에는 기준 입력에서 같은 궤적을 갖는 **시간별 Geometry 재생 대조**를 고려한다. 기존의 한 시점 Geometry 고정 E와 목적을 구분한다. full coupling이 보호 편집의 가능 범위를 넓히는지, 좁히는지, 변화시키지 않는지 검사한다. 이 대조와 같은 입력·초기값·계산 예산의 표준 최적화 비교가 없으면 A의 새로운 방법 기여를 인정하지 않는다. 현재는 설계/추론이며 실행 허가가 아니다.

## 실제 입력 basis에 맞춘 A의 최소 과제

[[90_Research-Archive/Research-Notes-2026-10/10_Authoring/23_Contact-Control-Space-Audit|23]]의 `b_heated` Heat Add 48개를 기준 입력으로 삼을 수 있다. 우선 두 사건의 strength를 `±ε`로 바꾸어 명목상 texel별 총 요청 입력을 보존하는 **입력 공간 대조**를 정의한다. 이것이 최종 Ice/Heat/Water 또는 후속 수송을 보존한다는 가설은 세우지 않는다. 다음은 event strength의 제한된 집합만 조정해 중간 목표와 최종/이웃 보호 지표를 동시에 만족하는지 판정하는 과제다. 다른 instance의 사건을 보상 변수로 섞어 쉬운 성공을 만들지 않는다. 필요하면 이후에 위치·시간 조정까지 허용하되 변경된 조작 범위를 명시한다. 현재 실험 실행은 중지 상태다.
